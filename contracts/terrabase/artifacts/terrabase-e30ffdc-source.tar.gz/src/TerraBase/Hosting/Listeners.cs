using System.Net;
using System.Net.Sockets;
using Microsoft.AspNetCore.Connections.Features;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.OpenApi;
using TerraBase.Configuration;
using TerraBase.Engine.Cluster;
using TerraBase.Features.Management;
using TerraBase.Features.Pressure;

namespace TerraBase.Hosting;

/// <summary>The listeners TerraBase serves.</summary>
public enum TerraBaseListener
{
    /// <summary>
    /// Fly's private network only (<c>fly-local-6pn</c>), HTTP/2 without TLS: inter-node gRPC, administration and the
    /// platform operator's API. The network is the trust boundary; no service credential is presented.
    /// </summary>
    Internal,

    /// <summary>Public API, plain HTTP behind Fly Proxy (TLS ends at the edge), authorized by scoped API keys and ts-auth tokens.</summary>
    Client,

    /// <summary>The Prometheus scrape Fly's metrics collector reads (<c>[[metrics]]</c>); every interface, no Fly Proxy service.</summary>
    Metrics,
}

/// <summary>
/// Endpoint metadata naming the listeners that serve an endpoint. Endpoints without it belong to
/// <see cref="TerraBaseListener.Internal"/>. Add it with <c>Metadata(ListenerMetadata.Client)</c>.
/// Requests on a connection that no TerraBase listener accepted are never served.
/// </summary>
/// <param name="Listeners">The serving listeners.</param>
public sealed record ListenerMetadata(params IReadOnlyList<TerraBaseListener> Listeners)
{
    /// <summary>The listener of endpoints without metadata: inter-node services and administration.</summary>
    public static ListenerMetadata Internal { get; } = new(TerraBaseListener.Internal);

    /// <summary>Metadata for the client API: the public listener, and the internal listener for the platform operator.</summary>
    public static ListenerMetadata Client { get; } = new(TerraBaseListener.Client, TerraBaseListener.Internal);

    /// <summary>
    /// Metadata for unauthenticated health probes, served on the internal listener and, for Fly's health checks, on the
    /// public listener. They never answer with tenant data.
    /// </summary>
    public static ListenerMetadata Probe { get; } = new(TerraBaseListener.Internal, TerraBaseListener.Client);

    /// <summary>
    /// Metadata for the Management API: ts-auth access tokens on the public listener, and the platform operator on the
    /// internal listener.
    /// </summary>
    public static ListenerMetadata Management { get; } = new(TerraBaseListener.Internal, TerraBaseListener.Client);

    /// <summary>Metadata for the Prometheus scrape: the internal listener and the metrics listener.</summary>
    public static ListenerMetadata Metrics { get; } = new(TerraBaseListener.Internal, TerraBaseListener.Metrics);
}

/// <summary>Request feature: the request is answered as a node of <paramref name="Region"/> (see <see cref="Listeners.RegionOf"/>).</summary>
/// <param name="Region">The answering node's region.</param>
public sealed record AnsweringRegion(string Region);

/// <summary>Binds listeners and keeps each endpoint on its own listener.</summary>
public static class Listeners
{
    private static readonly object ListenerKey = typeof(TerraBaseListener);

    /// <summary>The actual listener that accepted the connection, or null for an untagged connection.</summary>
    public static TerraBaseListener? ArrivedOn(HttpContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        return context.Features.Get<IConnectionItemsFeature>()?.Items.TryGetValue(ListenerKey, out var tag) == true
            ? tag as TerraBaseListener?
            : null;
    }

    /// <summary>Connection items for a request served in process as if <paramref name="listener"/> accepted it.</summary>
    internal static IConnectionItemsFeature AcceptedBy(TerraBaseListener listener) => new AcceptedConnection(listener);

    /// <summary>
    /// The region of the node that answers the request (docs/region-identity.md): this node's, or for a request a catalog
    /// follower forwarded, the follower's (<see cref="AnsweringRegion"/>).
    /// </summary>
    public static string RegionOf(HttpContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        return context.Features.Get<AnsweringRegion>()?.Region ?? context.RequestServices.GetRequiredService<TerraBaseOptions>().Region;
    }

    // <region>.api.terrascale.tech: the host that pins a region (docs/terrabase/region-identity.md); api.terrascale.tech
    // itself goes to the nearest region.
    private const string RegionalHostSuffix = ".api.terrascale.tech";

    // Whether host is <label>.api.terrascale.tech, and the region the label names (null when it names none).
    // Case-insensitive; Kestrel's Host.Host has no port.
    private static bool IsRegionalHost(string host, out string? region)
    {
        region = null;
        if (!host.EndsWith(RegionalHostSuffix, StringComparison.OrdinalIgnoreCase) || host.Length == RegionalHostSuffix.Length)
        {
            return false;
        }

        var label = host[..^RegionalHostSuffix.Length].ToLowerInvariant();
        region = TerraBaseOptions.IsRegion(label) ? label : null;
        return true;
    }

    private static string RegionalHosts(IEnumerable<string> regions) => string.Join(", ", regions.Select(name => name + RegionalHostSuffix));

    // The regions with a started machine of this app, this one's included, in order.
    private static async Task<SortedSet<string>> ServedRegionsAsync(HttpContext context)
    {
        var view = await context.RequestServices.GetRequiredService<IMembership>().RefreshAsync(context.RequestAborted).ConfigureAwait(false);
        return [.. view.Members.Concat(view.Elsewhere.IsDefault ? [] : view.Elsewhere).Select(member => member.Region).Append(RegionOf(context))];
    }

    /// <summary>
    /// Asks Fly Proxy to replay a client-listener request in <paramref name="region"/> (<c>fly-replay</c>), unless Fly replayed
    /// it already: a replayed request is answered where it landed, so a disagreement between regions never loops. Callers
    /// still write their 421, which a caller outside Fly Proxy receives. With <paramref name="fallback"/> (<c>prefer_self</c>),
    /// a replay that finds no machine there comes back here with <c>fly-replay-failed</c> instead of a proxy error.
    /// </summary>
    public static void ReplayIn(HttpContext context, string region, string? fallback = null)
    {
        ArgumentNullException.ThrowIfNull(context);
        if (ArrivedOn(context) == TerraBaseListener.Client && !context.Request.Headers.ContainsKey("Fly-Replay-Src"))
        {
            context.Response.Headers["fly-replay"] = fallback is null ? $"region={region}" : $"region={region};fallback={fallback}";
        }
    }

    /// <summary>Documents the client listener's region headers and pin rejection in OpenAPI.</summary>
    public static IServiceCollection AddTerraBaseRegionOpenApi(this IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);
        services.AddOpenApi("v1", options => options.AddOperationTransformer(async (operation, context, cancellationToken) =>
        {
            if (context.Description.ActionDescriptor.EndpointMetadata.OfType<ListenerMetadata>()
                .Any(metadata => metadata.Listeners.Contains(TerraBaseListener.Client)))
            {
                operation.Parameters ??= [];
                operation.Parameters.Add(new OpenApiParameter
                {
                    Name = "X-TerraScale-Region-Pin",
                    In = ParameterLocation.Header,
                    Description = "Optional single raw region ID. An empty, duplicate or mismatched pin returns 421 before execution; behind Fly Proxy a mismatched pin also answers fly-replay: region=<pin>.",
                    Schema = new OpenApiSchema { Type = JsonSchemaType.String },
                });
                operation.Responses ??= [];
                operation.Responses["421"] = new OpenApiResponse
                {
                    Description = "Misdirected Request; X-TerraBase-Region identifies the serving node.",
                    Content = new Dictionary<string, IOpenApiMediaType>(StringComparer.Ordinal)
                    {
                        ["application/json"] = new OpenApiMediaType { Schema = await context.GetOrCreateSchemaAsync(typeof(ErrorBody), cancellationToken: cancellationToken) },
                    },
                };
                foreach (var response in operation.Responses.Values.OfType<OpenApiResponse>())
                {
                    response.Headers ??= new Dictionary<string, IOpenApiHeader>(StringComparer.Ordinal);
                    response.Headers["X-TerraBase-Region"] = new OpenApiHeader
                    {
                        Description = "Region of the serving TerraBase node (client listener only).",
                        Schema = new OpenApiSchema { Type = JsonSchemaType.String },
                    };
                    response.Headers["X-TerraBase-Machine"] = new OpenApiHeader
                    {
                        Description = "Machine of the serving TerraBase node (FLY_MACHINE_ID; local off Fly; client listener only).",
                        Schema = new OpenApiSchema { Type = JsonSchemaType.String },
                    };
                }
            }
        }));
        return services;
    }

    /// <summary>Tags every connection accepted by <paramref name="listen"/> with its listener.</summary>
    public static ListenOptions UseTerraBaseListener(this ListenOptions listen, TerraBaseListener listener)
    {
        ArgumentNullException.ThrowIfNull(listen);
        listen.Use(next => async connection =>
        {
            connection.Items[ListenerKey] = listener;
            var pressure = listener == TerraBaseListener.Client ? listen.ApplicationServices.GetRequiredService<IPressureSignals>() : null;
            pressure?.ConnectionOpened();
            try
            {
                await next(connection).ConfigureAwait(false);
            }
            finally
            {
                pressure?.ConnectionClosed();
            }
        });
        return listen;
    }

    /// <summary>
    /// The address of the internal listener: the machine's private address on Fly, which Fly lists as <c>fly-local-6pn</c>
    /// in <c>/etc/hosts</c>; loopback off Fly.
    /// </summary>
    public static IPAddress InternalAddress(TerraBaseOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);
        try
        {
            return options.App is null ? IPAddress.Loopback
                : Dns.GetHostAddresses("fly-local-6pn").First(address => address.AddressFamily == AddressFamily.InterNetworkV6);
        }
        catch (Exception error) when (error is SocketException or InvalidOperationException)
        {
            throw new TerraBaseConfigurationException("fly-local-6pn must resolve to the machine's private IPv6 address");
        }
    }

    /// <summary>
    /// Binds the internal listener on <paramref name="internalAddress"/>, then the public and the metrics listeners, in that
    /// order. Those two bind every interface, except in local development (Development off Fly), where nothing but this
    /// machine may reach them: loopback only.
    /// </summary>
    public static void AddTerraBaseListeners(this KestrelServerOptions kestrel, TerraBaseOptions options, IPAddress internalAddress, string environmentName)
    {
        ArgumentNullException.ThrowIfNull(kestrel);
        ArgumentNullException.ThrowIfNull(options);
        var local = options.App is null && environmentName == Environments.Development;
        // HTTP/2 only: without TLS there is no ALPN, and gRPC needs HTTP/2 prior knowledge.
        kestrel.Listen(internalAddress, options.InternalPort, listen =>
        {
            listen.Protocols = HttpProtocols.Http2;
            listen.UseTerraBaseListener(TerraBaseListener.Internal);
        });
        Bind(options.Port, TerraBaseListener.Client);
        Bind(options.MetricsPort, TerraBaseListener.Metrics);

        void Bind(int port, TerraBaseListener listener)
        {
            void Configure(ListenOptions listen)
            {
                listen.Protocols = HttpProtocols.Http1;
                listen.UseTerraBaseListener(listener);
            }

            // Not ListenLocalhost: it refuses port 0, which tests use.
            if (local)
            {
                kestrel.Listen(IPAddress.Loopback, port, Configure);
            }
            else
            {
                kestrel.ListenAnyIP(port, Configure);
            }
        }
    }

    /// <summary>
    /// Answers 404 when a request reaches an endpoint through a listener that does not serve it, or
    /// arrives on a connection without a TerraBase listener tag.
    /// </summary>
    public static WebApplication UseTerraBaseListeners(this WebApplication app)
    {
        ArgumentNullException.ThrowIfNull(app);
        app.Use(async (context, next) =>
        {
            var arrivedOn = ArrivedOn(context);
            if (arrivedOn == TerraBaseListener.Client)
            {
                var region = RegionOf(context);
                var machine = context.RequestServices.GetRequiredService<TerraBaseOptions>().MachineId;
                // OnStarting survives Response.Clear() in the error middleware.
                context.Response.OnStarting(() =>
                {
                    context.Response.Headers["X-TerraBase-Region"] = region;
                    context.Response.Headers["X-TerraBase-Machine"] = machine;
                    return Task.CompletedTask;
                });
                var hasPin = context.Request.Headers.TryGetValue("X-TerraScale-Region-Pin", out var pin);
                if (IsRegionalHost(context.Request.Host.Host, out var host))
                {
                    // An explicit regional host fails closed: it is answered in its region or refused, never served by
                    // another region (docs/terrabase/region-identity.md).
                    if (host is null)
                    {
                        await BadRequests.WriteAsync(context, StatusCodes.Status421MisdirectedRequest, "misdirected_request",
                            $"that host names no region; the regional hosts are {RegionalHosts(await ServedRegionsAsync(context))}", op: null);
                        return;
                    }

                    // A header naming another region contradicts the host.
                    if (hasPin && (pin.Count != 1 || !string.Equals(pin[0], host, StringComparison.Ordinal)))
                    {
                        context.Response.StatusCode = StatusCodes.Status421MisdirectedRequest;
                        return;
                    }

                    if (!string.Equals(host, region, StringComparison.Ordinal))
                    {
                        // Fly already replayed it (it landed in the wrong region), Fly's replay found no machine there
                        // (fly-replay-failed), or no machine of the region is started: the region is unavailable.
                        var served = await ServedRegionsAsync(context);
                        if (context.Request.Headers.ContainsKey("Fly-Replay-Src") || context.Request.Headers.ContainsKey("fly-replay-failed") || !served.Contains(host))
                        {
                            await BadRequests.WriteAsync(context, StatusCodes.Status503ServiceUnavailable, "region_unavailable",
                                $"region {host} has no machine to answer; the regional hosts are {RegionalHosts(served)}", op: null);
                            return;
                        }

                        // Without a machine there, Fly sends the request back here with fly-replay-failed instead of an error.
                        ReplayIn(context, host, fallback: "prefer_self");
                        context.Response.StatusCode = StatusCodes.Status421MisdirectedRequest;
                        return;
                    }
                }
                else if (hasPin && (pin.Count != 1 || !string.Equals(pin[0], region, StringComparison.Ordinal)))
                {
                    if (pin.Count == 1 && TerraBaseOptions.IsRegion(pin[0]))
                    {
                        ReplayIn(context, pin[0]!);
                    }

                    context.Response.StatusCode = StatusCodes.Status421MisdirectedRequest;
                    return;
                }
            }

            var servedBy = context.GetEndpoint()?.Metadata.GetMetadata<ListenerMetadata>()?.Listeners ?? ListenerMetadata.Internal.Listeners;
            if (arrivedOn == TerraBaseListener.Internal
                && context.GetEndpoint()?.Metadata.GetMetadata<ProjectManagementRoute>() is not null
                && context.Features.Get<LegacyManagementRoute>() is null)
            {
                context.Response.StatusCode = StatusCodes.Status404NotFound;
                return;
            }

            if (arrivedOn is not { } listener || !servedBy.Contains(listener))
            {
                context.Response.StatusCode = StatusCodes.Status404NotFound;
                return;
            }

            await next(context);
        });
        return app;
    }

    private sealed class AcceptedConnection(TerraBaseListener listener) : IConnectionItemsFeature
    {
        public IDictionary<object, object?> Items { get; set; } = new Dictionary<object, object?> { [ListenerKey] = listener };
    }
}

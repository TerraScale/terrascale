# Turso qualification: existing TerraBase integration suites

0.8.3 builds with TerraScale's native and managed patch queues and passes three
credentialed Slow repeats, but its Fast exits are **0 / 2 / 0**: one HTTP 429
failure prevents clean required-Fast qualification. The exact baseline passes
Fast and credentialed Slow three times each. 0.9.0-pre.2 requires native and
managed patch ports before it can be built or tested. Keep the production pin.

Measured 2026-10-29 on beta (NixOS 26.05, linux-x64), through the assigned
`ts-heavy-any` branch `feat/turso-qualification-integration`. Repository baseline:
`4bacd8a818cff3fab76f3f0558bdc4585361e617`. SDK:
`11.0.100-rc.1.26425.128`. The initial sibling ts-dotnet source was
`df852e3b4d3a4df324452d46792b20566eea5136`. Corrected Slow qualification uses
CI's exact SDK pin `2dda37f08abe7497b35dc431895960e70f3c3611`, exported with
`git archive` into isolated scratch; archive SHA-256
`a37fb17f89513a557bd294c92917933736e33de876f9263e19ddd5e7b228fd8e`.
The sibling checkout is not modified. Baseline Fast does not reference that SDK.

## Provenance

The baseline is TerraScale's exact vendored source and patched combined native
artifact, not an unmodified upstream package. Annotated tag objects were peeled
before downloading source. GitHub's latest stable release query returned v0.8.3.

| Source | Tag object | Peeled source commit | Source archive SHA-256 |
|---|---|---|---|
| Baseline v0.8.2 | `5d68fe09c36149d395cbf870bf5c25b2e5970157` | `5c168be5ef6a32ac966daf5983502a4f694b37ad` | `7ea83d5e28577cf9d8655b77705902379e06b82fb29424f6ea328b5f26f17ecb` |
| v0.8.3 | `29ab7747f979722eedde051301cdf2cacb53a8b4` | `607bff9fd0e547a25a97b3bf06e83bcc5d99d53c` | `51892d80f56671ae268aef80b92f29e005594e7f897551ecef57dac2b9de8fea` |
| v0.9.0-pre.2 | `d12d3b0f8a7072f1e5a5010342422b83b972fb0a` | `725781518e8d2063046a8894aeec95ffa493f88b` | `4ec44b8ccb86d47a2314c3377ef5abc9edd66554a7469f38a4919ff1828fd7e5` |

Baseline native x64 SHA-256:
`7464a29f3fc9bce603a1e0881720b309a276455a778937d6a9ffc2ed680bd76d`.
The downloader also verified ARM64 SHA-256
`5b20e109146c1c1665e73cea1db407d9ec7b1cc34271474490a402796bd8e697`;
this run does not execute ARM64 tests.

## Candidate patch and ABI checks

Each repeat starts with pristine candidate source. The native queue checks and
applies storage-error contract1, runtime C AEGIS selection, then FTS budgeting.
The separate AEGIS dependency patch belongs to the subsequent native build.
Managed patches use the existing updater's alphabetical order and
`git apply --3way --whitespace=nowarn --directory=src/vendor/Turso.Data.Sqlite`.

| Candidate | Native source queue exits, repeats 1/2/3 | Managed queue exits, repeats 1/2/3 | Result |
|---|---|---|---|
| 0.8.3 | 0 / 0 / 0 | 0 / 0 / 0 | All 3 native source patches and 16 managed patches apply |
| 0.9.0-pre.2 | 1 / 1 / 1 | 1 / 1 / 1 | Native and managed ports required; suites not executed |

On 0.9.0-pre.2, `scripts/vendor/turso-native-budget.patch` rejects
`core/index_method/fts/mod.rs:456` and `core/index_method/fts/tests.rs:401`.
Managed replay first conflicts at
`0006-fix-turso-read-declared-types-from-native-column-met.patch`, in
`src/Turso.Data.Sqlite/SqliteDataReader.cs`. Later patches are not qualified.
These are measured source-application failures, not failed integration tests.

Both candidate C headers equal their exact-baseline counterparts byte for byte:

| Header | SHA-256 for all three source commits |
|---|---|
| `sdk-kit/turso.h` | `4e68f1979e239c675cfb39975e2f5120f481d6fb91f3777fd06b80a7872280a6` |
| `sync/sdk-kit/turso_sync.h` | `f9de9cb7eab356e59fd7efdbc02c6a35598588202297535436ecfeaa8ad7bda1` |

Header equality does not establish runtime ABI compatibility or preserve
TerraScale's added native exports. Official packages are not substituted for the
custom FTS, authenticated-damage, AEGIS and budget contract.
The qualified 0.8.3 x64 library and a hash-verified baseline library each expose
the same 79 `turso_*` C symbols, with zero additions or removals. The running
baseline and candidate Fast and Slow processes map their exact recorded hashes. The evidence also
records driver assembly hashes and a manifest of the patched binding sources.

## Existing suites

The unchanged `terrabase-test-fast` target builds and runs the vendor regressions
before Fast. `terrabase-test-slow` builds the existing TerraBase solution filter
and runs Slow independently. Release configuration, locked restore, warnings as
errors and existing parallelism are retained. Fast remains required and blocking;
Slow remains independent and non-blocking.
The harness continues collecting evidence after an individual target fails;
its completion exit is not a suite pass. The target exits below are the gates.

| Input | Suite | Repeat | Target exit | Total / passed / failed / skipped | Target wall time (s) |
|---|---|---|---|---|---|
| Baseline | Vendor + Fast | 1 | 0 | Vendor 44 / 44 / 0 / 0; Fast 3192 / 3192 / 0 / 0 | 544.806 |
| Baseline | Vendor + Fast | 2 | 0 | Vendor 44 / 44 / 0 / 0; Fast 3192 / 3192 / 0 / 0 | 478.711 |
| Baseline | Vendor + Fast | 3 | 0 | Vendor 44 / 44 / 0 / 0; Fast 3192 / 3192 / 0 / 0 | 477.458 |
| 0.8.3, CI SDK | Vendor + Fast | 1 | 0 | Vendor 44 / 44 / 0 / 0; Fast 3192 / 3192 / 0 / 0 | 481.490 |
| 0.8.3, CI SDK | Vendor + Fast | 2 | 2 | Vendor 44 / 44 / 0 / 0; Fast 3192 / 3191 / 1 / 0 | 479.177 |
| 0.8.3, CI SDK | Vendor + Fast | 3 | 0 | Vendor 44 / 44 / 0 / 0; Fast 3192 / 3192 / 0 / 0 | 473.043 |
| Initial SDK mismatch | Slow | 1 | 2 | 0 tests started; build blocked | 17.451 |
| Initial SDK mismatch | Slow | 2 | 2 | 0 tests started; build blocked | 5.113 |
| Initial SDK mismatch | Slow | 3 | 2 | 0 tests started; build blocked | 5.138 |
| 0.8.3, CI SDK, missing storage credentials | Slow | 1 | 2 | 90 / 86 / 3 / 1 | 164.097 |
| 0.8.3, CI SDK, missing storage credentials | Slow | 2 | 2 | 90 / 86 / 3 / 1 | 112.718 |
| 0.8.3, CI SDK, missing storage credentials | Slow | 3 | 2 | 90 / 86 / 3 / 1 | 111.330 |
| Baseline, CI SDK, missing storage credentials | Slow | 1 | 2 | 90 / 86 / 3 / 1 | 113.543 |
| Baseline, CI SDK, missing storage credentials | Slow | 2 | 2 | 90 / 86 / 3 / 1 | 114.349 |
| Baseline, CI SDK, missing storage credentials | Slow | 3 | 2 | 90 / 86 / 3 / 1 | 109.504 |
| 0.8.3, CI SDK and storage credentials | Slow | 1 | 0 | 90 / 89 / 0 / 1 | 250.804 |
| 0.8.3, CI SDK and storage credentials | Slow | 2 | 0 | 90 / 89 / 0 / 1 | 123.871 |
| 0.8.3, CI SDK and storage credentials | Slow | 3 | 0 | 90 / 89 / 0 / 1 | 110.420 |
| Baseline, CI SDK and storage credentials | Slow | 1 | 0 | 90 / 89 / 0 / 1 | 126.032 |
| Baseline, CI SDK and storage credentials | Slow | 2 | 0 | 90 / 89 / 0 / 1 | 118.635 |
| Baseline, CI SDK and storage credentials | Slow | 3 | 0 | 90 / 89 / 0 / 1 | 122.201 |

The initial Slow attempts cannot establish a Turso regression: they used the
wrong sibling SDK and failed at `AuthStore.cs:199`, CS0246 for
`TerraBaseClosureCancellation`. CI's pinned SDK contains the missing type.
The original attempts and SDK correction are preserved in
[issue #891](https://github.com/TerraScale/terrascale/issues/891).

0.8.3 Fast repeat 2 fails
`A_tenant_reaches_nothing_of_another_tenant_through_any_client_route`:
`SnapshotAsync` receives HTTP 429 at `TenantIsolationTests.cs:441`, called from
line 142. Baseline passes that test in all three full-suite repeats. This run
fails the final own-tenant document snapshot after the cross-tenant denial
assertions; it does not establish a security breach.
The evidence does not establish whether the failure is caused by the engine
change or test timing; it prevents a clean three-repeat Fast qualification. No test, limiter or
production code is changed to hide it.

The six missing-storage-credential runs all fail the same three Tigris tests.
They are preserved in [#899](https://github.com/TerraScale/terrascale/issues/899),
[#900](https://github.com/TerraScale/terrascale/issues/900) and
[#901](https://github.com/TerraScale/terrascale/issues/901). The corrected reruns
passed all three tests in all six full-suite repeats; those reports and #891 are
closed with the environment correction and successful evidence preserved.
They use `ts-dev-secret get dev-tigris-ci-env` piped directly to the test consumer;
credential values are not written into the checkout or report. The one skipped
Slow entry is the existing fault-soak child-host helper, which requires the
parent fault-soak test's launch environment; no new skip is introduced.

## Native build setup

The first 0.8.3 attempt exited 2 in 18.457 s because Podman's default OCI image
format ignores the recipe's Bash `SHELL` directive. The Docker-format retry
compiled Rust successfully but exited 134 in 149.561 s at the smoke's literal
version assertion, which still expected 0.8.2. The next attempt preserves the
exact version check with expected value 0.8.3 in both disposable smoke inputs.
All behavioral assertions remain; the source changes and attempt logs are kept.

The corrected native attempt passed in 145.620 s. Qualified x64 artifact SHA-256:
`15d7541e62ddaf99cd821e2780e0bdbed0858b2ec7e8db96a299249d744f5a5d`.
The build retained Rust 1.88.0 and the pinned container digest, locked Cargo
dependencies, FTS budgeting and runtime-dispatched C AEGIS. FTS and contract1
smokes passed, including persisted encrypted FTS, spoofed SQL remaining a
constraint, and real page tampering returning `TURSO_CORRUPT`. Crypto auditing
confirmed hardware instructions, runtime dispatch and portable fallback, with
`HAS_HW_AES` undefined. This is one x64 build, not two-architecture release or
byte-for-byte reproducibility qualification.

The measured integration qualification is complete. This does not qualify ARM64
execution, two-build artifact reproducibility, or the eventual PR head's CI gate.
The shared vendor pins, production source and CI guards remain unchanged.

## Evidence package

The directly inspectable [summary JSON](../turso-qualification/integration/summary.json)
contains source/artifact hashes, patch gates, build exits and every suite repeat.
[evidence.tar.gz](../turso-qualification/integration/evidence.tar.gz) contains the
verbose logs, headers, full receipt, executed harness snapshots, process mappings,
redaction audit and an internal SHA-256 manifest. Source archives and dependency
blobs are excluded; their provenance receipts remain. The package and concise
files are hashed in [SHA256SUMS](../turso-qualification/integration/SHA256SUMS).

Archive SHA-256: `38b4b0f998cd1edecd8bf14ad4764c8075d53dd77c13cc8561d0f4a8dae8e88f`.

## Reproduction

Transfer `qualify.py` and `with-ci-storage.sh` from
`benchmark/turso-qualification/integration/` into the same path in the assigned
managed workspace, then run:

```sh
nice -n 19 env TS_HEAVY_HOST=beta ts-heavy-any bash benchmark/turso-qualification/integration/with-ci-storage.sh --repo terrascale --branch feat/turso-qualification-integration
```

The runner refuses a shared checkout, imports candidates only in the disposable
workspace, exports the CI SDK without modifying its checkout, builds the custom
native artifact and invokes unchanged Release Make targets. The archive preserves
the exact source of each executed harness, including the historical setup
attempts. `--native-only` resumes native qualification from an existing receipt
and performs the corrected baseline Slow repeats afterward. Add `--slow-only`
to the wrapper command to rerun three Slow repeats for the retained custom
candidate and baseline, using the existing receipt and its hash-verified artifact.
The wrapper obtains the CI storage environment through the approved secret
pipeline. Generated build output stays in managed scratch.

Package and verify collected evidence locally:

```sh
nice -n 19 python3 benchmark/turso-qualification/integration/archive_evidence.py
cd benchmark/turso-qualification/integration
sha256sum --check SHA256SUMS
```

# Turso spike qualification, 2026-10-29

This is official Linux x64 CLI + official Node sync-client qualification, with three fresh repeats per version. It does not qualify TerraScale’s patched .NET/native binding, ARM64, production capacity or power-loss durability. No vendor pin or production code changed. All SQL uses WAL; the isolated MVCC bootstrap probe grants no production permission.

## Artifact and source identity

Every CLI archive passed its published release `.sha256` check. npm installed matching exact `sync`, `sync-common`, `database-common` and `sync-linux-x64-gnu` versions; package locks retain npm integrity values. Annotated tag IDs in the older spikes are tag objects, not source commits.

| Release | Annotated tag object | Dereferenced source commit |
|---|---|---|
| 0.8.2 | `5d68fe09c36149d395cbf870bf5c25b2e5970157` | `5c168be5ef6a32ac966daf5983502a4f694b37ad` |
| 0.8.3 | `29ab7747f979722eedde051301cdf2cacb53a8b4` | `607bff9fd0e547a25a97b3bf06e83bcc5d99d53c` |
| 0.9.0-pre.2 | `d12d3b0f8a7072f1e5a5010342422b83b972fb0a` | `725781518e8d2063046a8894aeec95ffa493f88b` |

| Release | CLI archive SHA-256 | Extracted executable SHA-256 |
|---|---|---|
| 0.8.2 | `1a12393fdb1fc36ef4c0339609b2652d6a0f7bb4a5f6c08da4afe1d364422d18` | `e973cccf573ca6cc44a2f7b0db36c47ef319c6d2c29b17d1eec9aba37c1e95fb` |
| 0.8.3 | `4475c4df29f744fb3b2fdeef622d9297bbb80698039eec57d1b3ba7e048b5e31` | `8125a4aa4bdf7deb316498e24d2610f1ac4ea084421273a7965bad9e91437841` |
| 0.9.0-pre.2 | `36e389020df944d00314ab9f06f54e29dffd51cf064e34814bcfa05ff28286e3` | `c86d8a1faf547bb6df19e65ef8144cc8a9238d12779a7005655d33429b4108f1` |

## SQL pull and recovery

`sql.mjs` transcribes the original SQL spike’s exact 100k-row workload into the matching official client: 100 parents, 100k inserts, 10k updates, 5k deletes, committed multi-statement transaction, rollback, rejected UNIQUE/FK rows, additive ALTER/default and CREATE INDEX. Hashes cover ordered complete rows of both tables, with normalized integer values. Each table cell counts independently completed repeats, not process exit status.

| Check | 0.8.2 | 0.8.3 | 0.9.0-pre.2 |
|---|---|---|---|
| Initial 100k hash equals original spike | PASS 3/3 | PASS 3/3 | PASS 3/3 |
| DML parity: 95,001 items, 101 parents | PASS 3/3 | PASS 3/3 | PASS 3/3 |
| UNIQUE/FK invalid writes rejected | PASS 3/3 | PASS 3/3 | PASS 3/3 |
| ALTER/default, index and full-row parity | PASS 3/3 | PASS 3/3 | PASS 3/3 |
| Existing client sees post-TRUNCATE-checkpoint insert | FAIL 3/3 | FAIL 3/3 | FAIL 3/3 |
| Reopen same client file repairs checkpoint mismatch | FAIL 3/3 | FAIL 3/3 | FAIL 3/3 |
| SIGKILL replica during pull, reopen same files, parity | PASS 3/3 | PASS 3/3 | PASS 3/3 |
| SIGKILL home after acknowledged write, restart, new write, parity | PASS 3/3 | PASS 3/3 | PASS 3/3 |

Initial SHA-256: `8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd`; final DML: `9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22`; after DDL: `565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d`.

Checkpoint sequence is successful `PRAGMA wal_checkpoint(TRUNCATE)`, an acknowledged insert of item 100004, pull, compare, close/reopen existing client file, pull, compare again. Crash tests use independent fresh home/replica files after that sequence. Replica termination is coordinated by the worker’s `/pull-updates` request event, without a sleep; all nine workers report `pull-request` then SIGKILL. The recovery workload contains 10,002 rows after replica recovery and 10,004 after home recovery. This is process-crash evidence only.

## Multiwriter semantic reproducers

The extracted original `cases.mjs` and supplemental cases run unchanged semantically, with unique files, ephemeral ports, matching-version paths and removed comments. Each observation below occurred in all three repeats of every listed release unless separately stated. Conflict rejection is expected when stated; committing part of the rejected local transaction is the defect.

| Case and observed outcome | 0.8.2 | 0.8.3 | 0.9.0-pre.2 |
|---|---|---|---|
| Disjoint-column updates merge | 3/3 | 3/3 | 3/3 |
| Stale same-column update overwrites newer value | 3/3 | 3/3 | 3/3 |
| UNIQUE push rejects, commits before/after rows, retry succeeds, pull drops losing row | 3/3 | 3/3 | 3/3 |
| FK parent-delete-first rejects child; reverse order rejects delete | 3/3 | 3/3 | 3/3 |
| Default home FK setting is off; orphan push accepted | 3/3 | 3/3 | 3/3 |
| Two approved 80 debits from 100 leave balance 20 and ledger 160 | 3/3 | 3/3 | 3/3 |
| AUTOINCREMENT/integer-PK collide to one row; implicit rowid, distinct UUID/ULID retain two | 3/3 | 3/3 | 3/3 |
| Additive local DDL + other region’s update converge | 3/3 | 3/3 | 3/3 |
| Local INSERT trigger: local audit 1, home audit count after push | 2 / 2 / 2 | 2 / 2 / 2 | 1 / 1 / 1 |
| Pull replay UNIQUE conflict blocks until explicit skip policy | 3/3 | 3/3 | 3/3 |
| Transform absolute updates into +2/+3 delta, final value 5 | 3/3 | 3/3 | 3/3 |
| 60-second R3 transport partition, 601 writes/client, all 1,803 rows/hash converge | 3/3 | 3/3 | 3/3 |

Trigger duplication is **absent for this reproducer** on pre.2; [#10147](https://github.com/tursodatabase/turso/issues/10147) remains open. Both base and audit images remain captured and pushed: 0.8.x orders audit→base; pre.2 orders base→audit. In this sample, the home trigger creates audit key 1 before the pushed audit upsert reaches it. This is evidence of changed order, not a general trigger correctness guarantee or missing capture. Wire requests, responses and transform images are retained for all nine runs.

Stale writes, lost arithmetic intent and integer-key collisions expose the asynchronous model’s limitations, not newly introduced regressions. FK-off acceptance reflects the CLI’s default. No new cross-version semantic regression has been observed in these cases. Page pull from a single authoritative writer remains distinct from these unsupported production push paths; D14 still excludes all Turso push/apply.

Partition catch-up milliseconds, repeats 1/2/3: 0.8.2 `278.9 / 259.0 / 292.4`; 0.8.3 `260.7 / 242.9 / 254.3`; pre.2 `320.3 / 330.9 / 284.2`. All hashes equal `d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba`. This is the original application transport refusal, not a whole-host outage.

## Isolated upstream issue probes

| Original reproducer | 0.8.2 | 0.8.3 | 0.9.0-pre.2 |
|---|---|---|---|
| [#8725](https://github.com/tursodatabase/turso/issues/8725): fresh MVCC bootstrap, home has row, pull false, client has no table | FAIL 3/3 | FAIL 3/3 | FAIL 3/3 |
| [#10178](https://github.com/tursodatabase/turso/issues/10178): table rebuild, first push syntax error, retry succeeds, home/client lose table | FAIL 3/3 | FAIL 3/3 | FAIL 3/3 |

These are the original embedded reproducers with matching-client paths and ephemeral ports. All 18 emitted complete result records without runner errors. MVCC is confined to new scratch files; it remains excluded from production. No claim covers other MVCC/OPFS/protocol-upgrade variants. Both upstream reports remain open as checked on 2026-10-29.

## Lag

The original `lag.mjs` measures 100 rows/s in single-row commits; `lag-batch.mjs` measures 1,000 rows/s in ten-row commits. These are separate transaction shapes, not proof of 1,000 individual commits/s. Every run has six nominal seconds of commits, drops the first nominal second’s rows as warmup and allows drain. p50/p99 are nearest-rank local-ACK→first successful R3 query visibility. Clients request 5-second long polling, but empty pulls return promptly; these are continuous pull measurements, not qualification of a long-poll authority. Each client–home leg receives the named RTT via private user/network-namespace loopback netem; ping and batch-run qdisc counters are retained.

| Release | Offered rows/s | Rows/commit | Per-leg RTT ms | p50 ms, R1 / R2 / R3 | p99 ms, R1 / R2 / R3 | Achieved rows/s, R1 / R2 / R3 |
|---|---:|---:|---:|---|---|---|
| 0.8.2 | 100 | 1 | 0 | 43.9 / 40.6 / 47.1 | 99.7 / 72.6 / 76.6 | 100.2 / 100.1 / 100.1 |
| 0.8.2 | 100 | 1 | 70 | 395.1 / 388.2 / 384.9 | 592.3 / 587.9 / 588.5 | 100.2 / 100.2 / 100.1 |
| 0.8.2 | 100 | 1 | 150 | 693.6 / 646.9 / 669.6 | 1180.9 / 957.3 / 1129.0 | 100.1 / 100.2 / 100.2 |
| 0.8.2 | 1000 | 10 | 0 | 44.3 / 46.1 / 53.6 | 72.2 / 74.0 / 112.0 | 1001.3 / 1001.3 / 1001.4 |
| 0.8.2 | 1000 | 10 | 70 | 1212.1 / 745.5 / 714.5 | 2159.0 / 1146.3 / 1073.9 | 1000.5 / 1001.4 / 1001.3 |
| 0.8.2 | 1000 | 10 | 150 | 3200.3 / 3295.9 / 3266.0 | 4899.4 / 4634.6 / 4555.7 | 1001.6 / 1001.3 / 1001.5 |
| 0.8.3 | 100 | 1 | 0 | 44.6 / 43.6 / 41.5 | 67.4 / 84.2 / 74.5 | 100.1 / 100.2 / 100.1 |
| 0.8.3 | 100 | 1 | 70 | 397.9 / 406.8 / 393.8 | 597.8 / 613.4 / 589.0 | 100.1 / 100.2 / 100.2 |
| 0.8.3 | 100 | 1 | 150 | 648.1 / 697.6 / 690.2 | 960.5 / 1163.3 / 1028.5 | 100.2 / 100.2 / 100.1 |
| 0.8.3 | 1000 | 10 | 0 | 47.3 / 51.7 / 46.5 | 72.0 / 158.9 / 104.2 | 1001.2 / 1001.4 / 1001.6 |
| 0.8.3 | 1000 | 10 | 70 | 611.3 / 698.7 / 625.3 | 1051.5 / 1055.7 / 1048.5 | 1001.4 / 1001.3 / 1001.6 |
| 0.8.3 | 1000 | 10 | 150 | 3307.0 / 3264.5 / 3189.4 | 4587.4 / 4565.2 / 4922.2 | 1001.6 / 1001.6 / 1001.5 |
| 0.9.0-pre.2 | 100 | 1 | 0 | 42.2 / 48.3 / 45.0 | 73.8 / 81.5 / 692.1 | 100.2 / 100.1 / 99.9 |
| 0.9.0-pre.2 | 100 | 1 | 70 | 3378.6 / 782.8 / 994.1 | 5600.1 / 2568.1 / 3027.7 | 88.5 / 100.0 / 81.8 |
| 0.9.0-pre.2 | 100 | 1 | 150 | 766.1 / 692.6 / 662.6 | 1085.4 / 1002.6 / 976.8 | 100.1 / 100.1 / 100.2 |
| 0.9.0-pre.2 | 1000 | 10 | 0 | 42.8 / 45.4 / 45.8 | 62.3 / 77.1 / 96.6 | 1001.4 / 1001.3 / 1001.4 |
| 0.9.0-pre.2 | 1000 | 10 | 70 | 612.6 / 681.9 / 707.1 | 1062.8 / 1066.5 / 1071.4 | 1001.5 / 1001.6 / 1001.2 |
| 0.9.0-pre.2 | 1000 | 10 | 150 | 3272.6 / 3339.4 / 3350.0 | 4602.3 / 4642.5 / 5100.6 | 1001.6 / 1001.6 / 1001.5 |

All 54 runs observed every measured row: 178,200 committed, 148,500 after warmup, zero missing. All 27 batch-run netem records report zero dropped packets. RTT was measured by ping, not inferred from geography. One writer pushes to home and R3 pulls/queries; R2 is connected and idle. These short shared-host runs do not qualify simultaneous three-writer or production capacity.

**Failed offered-load target:** pre.2 at 70 ms, 100 single-row commits/s, repeats 1 and 3 achieved only **88.5 and 81.8/s**, with p99 **5,600.1 and 3,027.7 ms**. Repeat 2 achieved approximately 100/s with p99 2,568.1 ms. Preserve these as target failures/outliers, not successful p99 values at sustained target load. They are a measured deterioration versus this 0.8.x run set; engine/client versus shared-host causation is unresolved. No favorable reruns replaced them. The 0.9 baseline repeat 3 also has p99 692.1 ms. At 150 ms/leg, batch p99 reaches 4.6–5.1 seconds across versions, so no cross-region sub-200 ms SLO follows.

## Evidence and reproduction

Execution host: mariogk-dev, shared Xeon E5-2660 v4, 46 visible CPUs, NixOS/Linux 7.3.0, Node 24.22.2, npm 11.19.1. Managed checkout baseline: `4bacd8a818cff3fab76f3f0558bdc4585361e617`. Heavy jobs use only `feat/turso-qualification-spikes`. Semantic repeats own their files and run concurrently; lag runs follow without overlapping this child’s correctness workloads. No production regions, credentials or network interfaces are touched. Raw host identity, baseline, published release metadata, checksums, exact npm locks, original markdown, extracted harness hashes, wire images, databases and samples remain at `/home/mariogk/spikes/turso-qualification-spikes-20261029` on mariogk-dev.

Source markdown SHA-256: multiwriter `14f0376099f9e75f10bf37dbeb051a4ab053325bac2fffda4c6ceaf0d0580fbd`; SQL spike `d706ad1987f936919b96f3d388835ad7d0deb18c7548bee5c01b13918967110f`. The extraction manifest hashes each original embedded source before path substitutions. `sql.mjs` is a separate Node transcription of the SQL/recovery workloads, not the original patched-.NET harness.

For reproduction, use a fresh scratch root, copy the four scripts in `benchmark/turso-qualification/spikes/` there, and extract from the two archived spike markdown files:

```bash
python3 benchmark/turso-qualification/spikes/extract.py /home/mariogk/Projects/TerraScale/.cos/spike-turso-multiwriter-2026-10-29.md /home/mariogk/Projects/TerraScale/.cos/spike-sql-repl-2026-10-29.md "$scratch/harness"
```

Copy the prepared scratch tree safely to the chosen dev host through SSH stdin, then run `nice -n 19 ts-heavy-any nice -n 19 bash <scratch>/prepare.sh <scratch> --repo terrascale --branch feat/turso-qualification-spikes`, followed by `nice -n 19 ts-heavy-any nice -n 19 bash -c 'exec bash <scratch>/run.sh <scratch> "$PWD"' --repo terrascale --branch feat/turso-qualification-spikes`. Select the same host for both via `TS_HEAVY_HOST`; delta uses direct paths. The first managed job verifies/releases dependencies; the second executes the workload. Namespace netem touches only its own loopback. Source archives and locks permit inspection without duplicating thousands of raw lines in the PR.

Published [compact evidence archive](../turso-qualification/spikes/evidence.tar.gz) (2.2 MiB), SHA-256 `cee81645ccd6d7ea02492d74c8b41fc799a566d682cce8f9832464a71058a3ee`. Its `evidence-manifest.sha256` covers 552 files; extract it and run `sha256sum --quiet -c evidence-manifest.sha256` from the extracted root. Databases and installed packages remain on mariogk-dev rather than in this compact archive. Evidence paths: `sql/<version>/<repeat>/result.json`, `semantic/<version>/<repeat>/{cases,supplemental}.jsonl`, per-case `run<version>/*/wire.json`, `issues/<version>-<issue>-<repeat>.jsonl`, `lag[-batch]-<version>.jsonl`, and per-run `lag<version>/*/samples.json`. `reproduction/` stores the final checked-in scripts; root `run.sh` and `issues.sh` retain the two actual measurement invocations.

Verification performed: all nine SQL records checked against original hashes, counts, constraint failures, index presence, checkpoint mismatches and SIGKILL/recovery parity; all 117 semantic records and 18 issue records retained; all 54 lag records checked for expected repeat identities, committed/observed counts, missing rows and error fields. `nice -n 19 bash -n` passed for both shell scripts, `nice -n 19 node --check` passed for `sql.mjs`, and extraction reproduced identical semantic/lag/issue sources.

No Fast/Slow service suite ran in this child. Existing service-suite and CDC qualification belong to the parent’s separate evidence. No version passes every SQL gate here; these upstream-client results alone do not justify changing the production pin.

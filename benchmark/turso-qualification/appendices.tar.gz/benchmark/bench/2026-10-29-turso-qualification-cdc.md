# CDC full qualification and growth — 2026-10-29

W0-3/W0-5, TerraScale baseline `4bacd8a818cff3fab76f3f0558bdc4585361e617`. Measurements use official upstream Node/native engines on beta (Linux x86_64, AMD Ryzen 5 PRO 6650H, 12 logical CPUs, Node v24.22.2). They do not qualify TerraScale's patched vendored .NET runtime, OCI ARM, replication/replay, MVCC, power loss, or retention. No vendor pin or production code changed.

## Provenance

`@tursodatabase/database`, `database-common`, and `database-linux-x64-gnu` are pinned to the same exact candidate version. npm `gitHead` matches these upstream release source commits. [Artifact metadata](../turso-qualification/cdc/artifacts.json) records package URLs/integrities and SHA-256 of installed JS/native files; [locked manifests](../turso-qualification/cdc/dependency-locks.tar.gz) permit `npm ci` reproduction.

| Version | Upstream source commit | Native `.node` SHA-256 |
|---|---|---|
| 0.8.2 | `5c168be5ef6a32ac966daf5983502a4f694b37ad` | `b6df8f940f2a901998be85b4ee5983357c358537ce4cf266665cab71e40be8fe` |
| 0.8.3 | `607bff9fd0e547a25a97b3bf06e83bcc5d99d53c` | `927ddb19494c622734c72aff87ed2126f020d6e3c80f544b8576efafa30ed6a2` |
| 0.9.0-pre.2 | `725781518e8d2063046a8894aeec95ffa493f88b` | `3dd5f06ad386715a1739cd943746d5c33f7c3decff63c72625fec0265e668bb6` |

## Correctness

| Check | 0.8.2 R1/R2/R3 | 0.8.3 R1/R2/R3 | 0.9.0-pre.2 R1/R2/R3 |
|---|---|---|---|
| INSERT/UPDATE/DELETE, NULL/blob and AFTER UPDATE audit images | PASS / PASS / PASS | PASS / PASS / PASS | PASS / PASS / PASS |
| Explicit commit and rollback | PASS / PASS / PASS | PASS / PASS / PASS | PASS / PASS / PASS |
| TRUNCATE retains old images; fresh post-checkpoint image | PASS / PASS / PASS | PASS / PASS / PASS | PASS / PASS / PASS |
| ADD COLUMN default and new five-column images | PASS / PASS / PASS | PASS / PASS / PASS | PASS / PASS / PASS |
| CREATE INDEX and unchanged old CDC prefix through both DDLs | PASS / PASS / PASS | PASS / PASS / PASS | PASS / PASS / PASS |
| SIGKILL, retained images and complete five-column continued CDC | PASS / PASS / PASS | PASS / PASS / PASS | PASS / PASS / PASS |

Every final probe observed `journal_mode=wal`, checkpoint `{busy:0,log:0,checkpointed:0}`, and crash exit `-9`. [Final raw records](../turso-qualification/cdc/results.json) and [source/log archive](../turso-qualification/cdc/correctness-final.tar.gz) contain the nine strengthened runs; all passed. Growth was preserved and was not rerun for these assertion changes.

The writer uses exactly `PRAGMA capture_data_changes_conn('full')`. The assertions decode SQLite-record images for INSERT/UPDATE/DELETE, NULL, empty and nonempty binary blobs, negative integers and UTF-8. One `AFTER UPDATE` trigger produces exactly one audit INSERT, with its CDC before=NULL and exact after image. This does not qualify other trigger variants or replay behavior. Explicit two-statement commit checks two row records plus one shared-transaction commit marker; rollback checks unchanged CDC and table rows.

`wal_checkpoint(TRUNCATE)` must preserve old records; a new post-checkpoint INSERT must have its exact full image. ADD COLUMN's existing-row default and changed five-column image are checked. The old CDC prefix must remain byte-identical through ALTER and CREATE INDEX. After an acknowledged write and SIGKILL, a fresh Node process reopens the same file, re-enables full capture, decodes retained images, and checks a continued UPDATE's complete five-column before/after images and increasing change ID.

The earlier SQL-replication spike deliberately refused ALTER in its CDC replay prototype. That differs from this source-capture test: it does not establish that engine CDC capture itself refuses ALTER, nor does successful capture make arbitrary schema replay safe.

## Growth method

Each version/rate has three fresh repeats, each pairing a full-capture database with a separate no-capture control. Different pairs run sequentially to limit disk interference; every case owns its file and process. A 30-second offered-load window schedules one INSERT/autocommit at 1, 10, or 100 writes/s: 30, 300, or 3,000 writes. Each row contains a deterministic synthetic 26-character Crockford ULID, 1,024 ASCII text bytes and a 32-byte blob. Short samples bound this storage-cost experiment; they are not throughput qualification or a 24-hour soak. Actual elapsed time and worst submission lateness remain evidence, including missed rate targets.

After schema/capture initialization, an explicit TRUNCATE checkpoint establishes baseline allocation. The harness records database and WAL file lengths before the final explicit checkpoint and again afterwards. Engine automatic checkpoint behavior remains in effect: `PRAGMA wal_autocheckpoint` returns no rows, so no unsupported claim of configured or disabled automatic checkpointing is made. WAL file length is current allocation, not total bytes written; reusing/resetting WAL prevents linear extrapolation to a required WAL capacity. No CDC trimming, deletion, VACUUM or retention runs.

Allocation comes from a read-only walk of the checkpointed SQLite-format file, using actual `sqlite_schema.rootpage` values. It counts table/index B-tree and overflow pages, not `dbstat`. These are owned file pages, not filesystem block allocation or disk-write volume. Logical CDC record payload sums stored SQLite record bytes, including commit records and metadata; image bytes separately sum `length(before)+length(after)+length(updates)`. Neither includes B-tree cell headers or unused page space. Allocated CDC bytes are the `turso_cdc` B-tree page delta from baseline. Application bytes include `items` and its primary-key index; internal CDC metadata roots remain separate in raw evidence. Small samples have 4 KiB page quantization.

For each measured bytes/write value B at offered rate s, daily extrapolation is **B × s × 86,400**; GiB divides by 1,073,741,824. This assumes this insert-only payload and one-row commits, sustained offered throughput, no retention, and comparable allocation efficiency. UPDATE commonly carries two images and DELETE a before image; this experiment makes no cost claim for a mixed workload.

## Measured growth and daily extrapolation

For each rate, allocation, logical bytes, WAL lengths and counts below were identical in all nine runs (three versions × R1/R2/R3). Each run was independently measured; timings differ in the following table. Insert-image bytes are **1,087/write**. The CDC record column additionally includes metadata and one commit marker per write.

| Writes/s | Row / commit records per repeat | CDC record B/write | CDC allocated B/write | CDC record GiB/day | CDC allocated GiB/day |
|---:|---:|---:|---:|---:|---:|
| 1 | 30 / 30 | 1,124.900 | 1,365.333 | 0.090517 | 0.109863 |
| 10 | 300 / 300 | 1,127.140 | 1,365.333 | 0.906968 | 1.098633 |
| 100 | 3,000 / 3,000 | 1,127.914 | 1,368.064 | 9.075903 | 11.008301 |

Full-mode baselines were 32,768 B versus 12,288 B for controls. Every final checkpoint returned busy=0/log=0/checkpointed=0 and reduced WAL length to 0. Application allocation below includes its primary-key index and was identical with/without capture. Total database deltas subtract each file’s own baseline.

| Writes/s | Application page Δ B | CDC page Δ B | Full DB Δ B | Control DB Δ B | Full WAL before B | Control WAL before B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 40,960 | 40,960 | 81,920 | 40,960 | 556,232 | 358,472 |
| 10 | 421,888 | 409,600 | 831,488 | 421,888 | 1,689,232 | 3,761,592 |
| 100 | 4,218,880 | 4,104,192 | 8,323,072 | 4,218,880 | 1,957,032 | 2,068,272 |

**Rate misses are preserved.** All scheduled rows eventually committed, but some 100/s runs overran 30 seconds or temporarily accumulated seconds of scheduling lag. These are not passes for sustained 100/s delivery. Shared-host/disk interference is not separated from engine cost. Daily columns are conditional on sustaining the offered rate; they are not measured daily production growth.

| Version | Offered writes/s | Full elapsed seconds R1/R2/R3 | Full achieved writes/s R1/R2/R3 | Control seconds R1/R2/R3 | Full max lateness ms R1/R2/R3 |
|---|---:|---|---|---|---|
| 0.8.2 | 1 | 30.004 / 30.005 / 30.005 | 1.000 / 1.000 / 1.000 | 30.005 / 30.005 / 30.005 | 7.053 / 5.464 / 7.178 |
| 0.8.2 | 10 | 30.000 / 30.000 / 30.001 | 10.000 / 10.000 / 10.000 | 30.000 / 30.002 / 30.001 | 3.713 / 3.861 / 111.119 |
| 0.8.2 | 100 | 30.001 / 31.819 / 30.001 | 99.997 / 94.283 / 99.997 | 30.000 / 31.931 / 30.000 | 52.872 / 2061.640 / 19.876 |
| 0.8.3 | 1 | 30.004 / 30.004 / 30.005 | 1.000 / 1.000 / 1.000 | 30.003 / 30.001 / 30.004 | 5.130 / 4.826 / 4.671 |
| 0.8.3 | 10 | 30.000 / 30.001 / 30.000 | 10.000 / 10.000 / 10.000 | 30.001 / 30.002 / 30.001 | 3.829 / 3.593 / 20.202 |
| 0.8.3 | 100 | 30.817 / 34.237 / 30.000 | 97.350 / 87.625 / 100.000 | 30.786 / 34.100 / 30.001 | 915.502 / 4233.802 / 102.206 |
| 0.9.0-pre.2 | 1 | 30.005 / 30.005 / 30.005 | 1.000 / 1.000 / 1.000 | 30.005 / 30.005 / 30.004 | 5.653 / 5.064 / 4.883 |
| 0.9.0-pre.2 | 10 | 30.001 / 30.001 / 30.001 | 10.000 / 10.000 / 10.000 | 30.002 / 30.000 / 30.001 | 45.421 / 434.663 / 155.460 |
| 0.9.0-pre.2 | 100 | 39.634 / 30.000 / 30.001 | 75.693 / 100.000 / 99.998 | 39.385 / 30.000 / 30.000 | 9650.016 / 6172.141 / 28.751 |

Growth used `run.py` SHA-256 `d3c0a5cdaed3b3434bb653dd1cce700bf7221d28e27b3a9c7893f21ca6025f04`; strengthened correctness used `e28169b52e1d017c4ba6686f2dc906e0c7493aea7ecb8505310f05d569f3463f`. Both source revisions are in their corresponding archives; `worker.mjs` was unchanged (`df19df8566942266a568dc84eaa643918bfd0f323bbdbff7c0940f5afe1978f6`). [Combined machine-readable results](../turso-qualification/cdc/results.json), [paired growth source/logs](../turso-qualification/cdc/paired-growth.tar.gz), and [checksums](../turso-qualification/cdc/SHA256SUMS) preserve exact evidence.

## Exploratory batch and reproduction

The first batch ran 18 growth workers per version concurrently. It is preserved, including source and logs, in [exploratory evidence](../turso-qualification/cdc/exploratory-concurrent.tar.gz). Several 100/s cases fell behind schedule. These remain measured rate misses, not successful sustained 100/s observations. The later paired batch changes measurement concurrency and uses Crockford synthetic keys; it does not erase those outcomes. The exploratory attempt to set `wal_autocheckpoint=0` had no validated readback and is not a supported configuration claim.

Harness: [run.py](../turso-qualification/cdc/run.py), [worker.mjs](../turso-qualification/cdc/worker.mjs). Run under the assigned managed branch; files are transiently staged on beta, never committed or pushed by this child:

```bash
ssh beta mkdir -p /tmp/turso-qualification-cdc
scp benchmark/turso-qualification/cdc/{run.py,worker.mjs,dependency-locks.tar.gz} beta:/tmp/turso-qualification-cdc/
TS_HEAVY_HOST=beta nice -n 19 ts-heavy-any bash -c '
set -e
cd /tmp/turso-qualification-cdc
tar -xzf dependency-locks.tar.gz
for v in 0.8.2 0.8.3 0.9.0-pre.2; do
  npm ci --ignore-scripts --no-audit --no-fund --prefix "$v"
done
python3 run.py "$PWD" "$PWD/reproduction"
' --repo terrascale --branch feat/turso-qualification-cdc
```

Appending `correctness-only` to the Python invocation selects the nine correctness probes without rerunning growth. Raw results preserve individual assertions, SQL checkpoint replies, images, counts, timings and source hashes. No service Fast/Slow suite or CI ran in this child; these upstream benchmark probes are not a substitute for those gates.

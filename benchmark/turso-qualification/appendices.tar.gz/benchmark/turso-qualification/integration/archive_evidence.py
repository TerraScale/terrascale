import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

folder = Path(__file__).parent
out = folder / "evidence"
receipt = json.loads((out / "receipt.json").read_text())
summaries = []
for step in receipt["steps"]:
    if not re.search(r"-(?:fast|slow)-r[123]$", step["name"]):
        continue
    text = re.sub(r"\x1b\[[0-9;]*m", "", (out / (step["name"] + ".log")).read_text())
    runs = []
    for line in text.splitlines():
        if line.startswith("Test run summary:"):
            runs.append({"summary": line})
        match = re.fullmatch(r"  (total|failed|succeeded|skipped|duration): (.+)", line)
        if match and runs:
            key, value = match.groups()
            runs[-1][key] = value if key == "duration" else int(value)
    failures = re.findall(r"^failed (.+) \([^\n]*\)$", text, re.MULTILINE)
    summaries.append({"name": step["name"], "exit": step["exit"], "seconds": step["seconds"], "runs": runs, "failed_tests": failures})
(out / "test-summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
compact = {"repository_sha": receipt["repository_sha"], "host": receipt["host"], "ci_sdk": receipt.get("ci_sdk"), "source_commits": receipt["source_commits"], "source_archive_sha256": receipt["archive_sha256"], "candidate_native_sha256": receipt.get("native_sha256", {}), "builds": [{key: step[key] for key in ("name", "exit", "seconds")} for step in receipt["steps"] if "-native-build" in step["name"]]}
compact["historical_sdk_mismatch"] = {"sdk_commit": "df852e3b4d3a4df324452d46792b20566eea5136", "attempts": ["baseline-slow-r1", "baseline-slow-r2", "baseline-slow-r3"], "issue": "https://github.com/TerraScale/terrascale/issues/891"}
compact["slow_reports"] = json.loads((out / "slow-issues.json").read_text()) if (out / "slow-issues.json").exists() else []
compact["ci_storage"] = receipt.get("ci_storage")
compact["qualification"] = {"0.8.3": "Blocked: Fast repeat 2 HTTP 429; Slow passes three credentialed repeats", "0.9.0-pre.2": "Blocked: native and managed patch queues; no build or suites executed", "baseline": "Fast and credentialed Slow pass three repeats each", "production_pin_changed": False, "scope": "linux-x64; one successful custom native build; no ARM64 or two-build reproducibility qualification"}
compact["baseline_native_sha256"] = sorted(set(json.loads((out / "baseline-loaded-native.json").read_text())["sha256"].values()))
binding = out / "0.8.3-loaded-native-and-bindings.json"
if binding.exists():
    loaded = json.loads(binding.read_text())
    compact["candidate_binding_assembly_sha256"] = loaded["assembly_sha256"]
    compact["patched_binding_source_sha256"] = loaded["patched_binding_source_sha256"]
gates = [{key: value for key, value in gate.items() if key != "suite_tests_executed"} for gate in receipt["candidate_gates"]]
short_runs = [{**{key: row[key] for key in ("name", "exit", "seconds", "failed_tests")}, "tests": [{**{key: value for key, value in run.items() if key != "summary"}, "project": run["summary"].rsplit("/", 1)[-1].split(".dll", 1)[0]} for run in row["runs"]]} for row in summaries]
lines = ["{"] + ["  " + json.dumps(key) + ": " + json.dumps(value) + "," for key, value in compact.items()]
lines += ["  \"candidate_gates\": [", ",\n".join("    " + json.dumps(row) for row in gates), "  ],", "  \"runs\": [", ",\n".join("    " + json.dumps(row) for row in short_runs), "  ]", "}"]
(folder / "summary.json").write_text("\n".join(lines) + "\n")
files = [p for p in sorted(out.rglob("*")) if p.is_file() and not p.name.endswith((".tar.gz", ".crate")) and p.name != "manifest.json"]
manifest = {str(p.relative_to(out)): {"sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "bytes": p.stat().st_size} for p in files}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
files.append(out / "manifest.json")
with (folder / "evidence.tar.gz").open("wb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for path in sorted(files):
                data = path.read_bytes()
                entry = tarfile.TarInfo("evidence/" + str(path.relative_to(out)))
                entry.size = len(data)
                entry.mode = 0o644
                archive.addfile(entry, io.BytesIO(data))
lines.insert(1, "  \"evidence_archive_sha256\": " + json.dumps(hashlib.sha256((folder / "evidence.tar.gz").read_bytes()).hexdigest()) + ",")
(folder / "summary.json").write_text("\n".join(lines) + "\n")
(folder / "SHA256SUMS").write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.name + "\n" for p in sorted(folder.iterdir()) if p.is_file() and p.name != "SHA256SUMS"))
print(json.dumps(summaries, indent=2))

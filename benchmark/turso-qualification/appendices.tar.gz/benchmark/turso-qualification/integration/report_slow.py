import json
from pathlib import Path
import re
import subprocess

out = Path(__file__).parent / "evidence"
receipt = json.loads((out / "receipt.json").read_text())
previous = json.loads((out / "slow-issues.json").read_text()) if (out / "slow-issues.json").exists() else []
reported = {step for item in previous for step in item.get("reported_steps", [])}
failures = {}
for step in receipt["steps"]:
    if "-slow-r" not in step["name"] or step["exit"] == 0 or step["name"] in reported:
        continue
    log = (out / (step["name"] + ".log")).read_text()
    log = re.sub(r"\x1b\[[0-9;]*m", "", log)
    tests = re.findall(r"^failed (.+) \([^\n]*\)$", log, re.MULTILINE)
    for test in tests or ["TerraBase qualification build or runner failure"]:
        excerpt = log[-9000:]
        if tests:
            start = log.index("failed " + test + " ")
            excerpt = log[start:].split("  Standard output", 1)[0][:9000]
        else:
            excerpt = "\n".join(line for line in log.splitlines() if ": error " in line or line.startswith("make:"))[:9000]
        excerpt = re.sub(r"(Bearer|Basic) [^ \"\n]+", r"\1 [redacted]", excerpt)
        excerpt = re.sub(r"((?:api[_-]?key|token|secret|password)[\"=: ]+)[^ \"\n,]+", r"\1[redacted]", excerpt, flags=re.IGNORECASE)
        excerpt = re.sub(r"((?:AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|X-Amz-Credential|X-Amz-Signature|X-Amz-Security-Token)[\"=: ]+)[^& \"\n,]+", r"\1[redacted]", excerpt, flags=re.IGNORECASE)
        failures.setdefault(test, []).append((step, excerpt))
existing = json.loads(subprocess.check_output(["gh", "issue", "list", "--repo", "TerraScale/terrascale", "--state", "open", "--limit", "500", "--json", "number,title,url"], text=True))
reports = previous.copy()
for index, (test, occurrences) in enumerate(failures.items(), 1):
    title = "Slow: " + test
    body = "\n".join([
        "TerraBase Turso qualification at repository SHA `" + receipt["repository_sha"] + "`.",
        "Environment: " + receipt["host"] + ", NixOS linux-x64, .NET 11.0.100-rc.1.26425.128, Release, managed ts-heavy-any workspace.",
        "Native baseline: exact upstream `5c168be5ef6a32ac966daf5983502a4f694b37ad` plus TerraScale patches; source/artifact identities and per-repeat results are in `benchmark/bench/2026-10-29-turso-qualification-integration.md`.",
        "CI run URL: none; this is a managed developer-host qualification run.",
        "Reproduce: transfer `benchmark/turso-qualification/integration/qualify.py` into the assigned managed workspace and run `nice -n 19 ts-heavy-any python3 benchmark/turso-qualification/integration/qualify.py --repo terrascale --branch feat/turso-qualification-integration`. The harness records each native build and source patch command in `receipt.json` and invokes `make terrabase-test-slow CONFIGURATION=Release` without changing test parallelism.",
        "Expected: the existing Slow suite builds and every integration test passes for the recorded input. Actual: the failures below occurred. Slow remains non-blocking; the required Fast gate is separate.",
        "Failed test or runner: " + test,
        "\n".join("- " + step["name"] + ": exit " + str(step["exit"]) + ", " + str(step["seconds"]) + " s" for step, _ in occurrences),
        "Redacted logs:",
        "```text",
        occurrences[0][1],
        "```",
    ]) + "\n"
    path = out / ("slow-issue-" + str(index) + ".md")
    path.write_text(body)
    match = next((issue for issue in existing if issue["title"] == title), None)
    if match:
        command = ["gh", "issue", "comment", str(match["number"]), "--repo", "TerraScale/terrascale", "--body-file", str(path)]
    else:
        command = ["gh", "issue", "create", "--repo", "TerraScale/terrascale", "--title", title, "--body-file", str(path)]
    result = subprocess.check_output(command, text=True).strip()
    prior = next((item for item in reports if item["test"] == test), None)
    steps = (prior.get("reported_steps", []) if prior else []) + [step["name"] for step, _ in occurrences]
    if prior:
        reports.remove(prior)
    reports.append({"test": test, "url": match["url"] if match else result, "title": title, "reported_steps": steps})
    print(result)
(out / "slow-issues.json").write_text(json.dumps(reports, indent=2) + "\n")

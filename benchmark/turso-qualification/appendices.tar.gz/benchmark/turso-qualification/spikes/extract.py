import hashlib
import json
import re
import sys
from pathlib import Path

multi, sql, target = map(Path, sys.argv[1:])
target.mkdir(parents=True, exist_ok=True)
manifest = {}
for source, names in [(multi, ['cases.mjs', 'supplemental.mjs', 'lag.mjs', 'lag-batch.mjs']), (sql, ['run.py', 'recovery.py', 'repro.mjs'])]:
    text = source.read_text()
    manifest[source.name] = hashlib.sha256(source.read_bytes()).hexdigest()
    for name in names:
        marker = f'<summary>{name}</summary>' if source == multi else f'### `{name}`'
        section = text.split(marker, 1)[1]
        code = re.search(r'```\w+\n(.*?)\n```', section, re.S)[1]
        manifest[name] = hashlib.sha256((code + '\n').encode()).hexdigest()
        if name.endswith('.mjs') and source == multi:
            code = code.replace("'/home/mariogk/spikes/turso-mw-20261029'", 'process.env.SPIKE_ROOT')
            code = code.replace('bin0.8.${ver.slice(-1)}', 'bin${ver}')
            code = '\n'.join(line.split(' // empty push')[0] for line in code.splitlines() if not line.lstrip().startswith('//'))
        if name == 'repro.mjs':
            code = code.replace("'/home/mariogk/spikes/sql-repl-20261029'", 'process.env.SPIKE_ROOT')
            code = code.replace("v==='0.8.2'?`${root}/npm082/node_modules/@tursodatabase/sync`:'sync083'", '`${root}/js${v}/node_modules/@tursodatabase/sync`')
            code = code.replace('cli-${v}', 'bin${v}')
            code = re.sub(r'const port=19400.*?;const url=', "const net=await import('node:net');const sock=net.createServer();sock.listen(0,'127.0.0.1');await new Promise(r=>sock.once('listening',r));const port=sock.address().port;await new Promise(r=>sock.close(r));const url=", code)
        (target / name).write_text(code + '\n')
(target / 'extraction.json').write_text(json.dumps(manifest, indent=2) + '\n')

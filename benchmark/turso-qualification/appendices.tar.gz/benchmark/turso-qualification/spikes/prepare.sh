set -euo pipefail
cd "${1:?scratch root}"
mkdir -p artifacts
for version in 0.8.2 0.8.3 0.9.0-pre.2; do
  mkdir -p "artifacts/$version" "bin$version" "js$version"
  gh api "repos/tursodatabase/turso/releases/tags/v$version" > "artifacts/$version/release.json"
  gh api "repos/tursodatabase/turso/git/ref/tags/v$version" > "artifacts/$version/ref.json"
  tag=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["object"]["sha"])' "artifacts/$version/ref.json")
  gh api "repos/tursodatabase/turso/git/tags/$tag" > "artifacts/$version/tag.json"
  gh release download "v$version" --repo tursodatabase/turso --dir "artifacts/$version" --pattern 'turso_cli-x86_64-unknown-linux-gnu.tar.xz*' --clobber
  (cd "artifacts/$version"; sha256sum -c turso_cli-x86_64-unknown-linux-gnu.tar.xz.sha256) > "artifacts/$version/hash-check.txt"
  tar -xJf "artifacts/$version/turso_cli-x86_64-unknown-linux-gnu.tar.xz" -C "bin$version"
  sha256sum "bin$version/turso_cli-x86_64-unknown-linux-gnu/tursodb" > "artifacts/$version/executable.sha256"
  "bin$version/turso_cli-x86_64-unknown-linux-gnu/tursodb" --version > "artifacts/$version/version.txt"
  (cd "js$version"; npm init -y >/dev/null; npm install --save-exact "@tursodatabase/sync@$version" "@tursodatabase/sync-common@$version" "@tursodatabase/database-common@$version" "@tursodatabase/sync-linux-x64-gnu@$version"; npm ls --all) > "artifacts/$version/npm.txt" 2>&1
  cp "js$version/package-lock.json" "artifacts/$version/package-lock.json"
done
uname -a > artifacts/host.txt
node --version >> artifacts/host.txt
npm --version >> artifacts/host.txt
lscpu >> artifacts/host.txt

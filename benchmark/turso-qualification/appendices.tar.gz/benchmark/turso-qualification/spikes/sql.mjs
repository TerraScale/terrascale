import {spawn} from 'node:child_process';
import {mkdir,open,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createInterface} from 'node:readline';
import {once} from 'node:events';
import net from 'node:net';
const [version,repeat,mode,path,url]=process.argv.slice(2),root=process.env.SPIKE_ROOT;
const {connect}=await import(`${root}/js${version}/node_modules/@tursodatabase/sync/dist/promise.js`);
const plain=x=>JSON.parse(JSON.stringify(x,(_,v)=>typeof v==='bigint'?Number(v):v));
const query=async(db,sql)=>plain(await(await db.prepare(sql)).all());
if(mode==='worker'){
 let active=false;
 const db=await connect({path,url,fetch:async(u,init)=>{if(active&&u.endsWith('/pull-updates'))process.stdout.write('pull-request\n');return fetch(u,init)}});
 process.stdout.write('ready\n');
 for await(const line of createInterface({input:process.stdin})){active=true;await db.pull();process.stdout.write('completed\n');active=false}
 await db.close();
}else{
 const dir=`${root}/sql/${version}/${repeat}`;await mkdir(dir,{recursive:true});
 const socket=net.createServer();socket.listen(0,'127.0.0.1');await once(socket,'listening');const port=socket.address().port;await new Promise(r=>socket.close(r));
 const base=`http://127.0.0.1:${port}`,log=await open(`${dir}/server.log`,'a');let server,db,worker,homePath=`${dir}/H.db`;
 const result={version,repeat,dir};
 async function home(sql){const j=await(await fetch(base+'/v2/pipeline',{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql,want_rows:true}}]})})).json();const x=j.results[0];if(x.type!=='ok')throw Error(JSON.stringify(x));return x.response.result.rows.map(row=>row.map(c=>c.type==='integer'?Number(c.value):c.value??null))}
 async function start(){server=spawn(`${root}/bin${version}/turso_cli-x86_64-unknown-linux-gnu/tursodb`,[homePath,'--sync-server',`127.0.0.1:${port}`],{stdio:['ignore',log.fd,log.fd]});const deadline=Date.now()+10000;while(true){try{await home('SELECT 1');break}catch(e){if(server.exitCode!==null||Date.now()>deadline)throw e;await new Promise(r=>setTimeout(r,10))}}}
 async function digest(sql,tables=['items','parent']){const h=createHash('sha256'),counts={};for(const t of tables){const rows=await sql(`SELECT * FROM ${t} ORDER BY id`);counts[t]=rows.length;h.update(JSON.stringify([t,rows]))}return {sha256:h.digest('hex'),counts}}
 const replica=sql=>query(db,sql).then(rows=>rows.map(Object.values));
 async function parity(label,tables){const h=await digest(home,tables),r=await digest(replica,tables);result[label]={home:h,replica:r,match:JSON.stringify(h)===JSON.stringify(r)}}
 async function stop(signal='SIGINT'){const exited=once(server,'exit');server.kill(signal);await exited}
 try{
  try{
  await start();db=await connect({path:`${dir}/R.db`,url:base});await home('PRAGMA foreign_keys=ON');
  for(const sql of ['CREATE TABLE parent(id INTEGER PRIMARY KEY, name TEXT UNIQUE)','CREATE TABLE items(id INTEGER PRIMARY KEY, parent_id INTEGER REFERENCES parent(id), name TEXT UNIQUE, val INTEGER)','INSERT INTO parent VALUES '+Array.from({length:100},(_,k)=>`(${k+1},'p${k+1}')`).join(',')])await home(sql);
  for(let start=1;start<=100000;start+=1000)await home('INSERT INTO items VALUES '+Array.from({length:1000},(_,k)=>{let i=start+k;return `(${i},${(i-1)%100+1},'i${i}',${i*3})`}).join(','));
  result.initial=await digest(home);result.constraints={};
  for(const [name,sql] of [['unique',"INSERT INTO items VALUES(100001,1,'i1',0)"],['fk',"INSERT INTO items VALUES(100001,999,'bad-fk',0)"]]){try{await home(sql);result.constraints[name]='ACCEPTED INVALID'}catch(e){result.constraints[name]=String(e)}}
  for(const sql of ['UPDATE items SET val=val+1 WHERE id%10=0','DELETE FROM items WHERE id%20=1','BEGIN IMMEDIATE',"INSERT INTO parent VALUES(101,'txn-parent')","INSERT INTO items VALUES(100002,101,'txn-child',42)",'UPDATE items SET val=77 WHERE id=2','COMMIT','BEGIN IMMEDIATE',"INSERT INTO items VALUES(100003,1,'rollback',0)",'ROLLBACK'])await home(sql);
  await db.pull();await parity('dml');await home("ALTER TABLE items ADD COLUMN extra TEXT DEFAULT 'added'");await home('CREATE INDEX idx_items_val ON items(val)');await db.pull();await parity('ddl');result.index=await replica("SELECT name FROM sqlite_schema WHERE name='idx_items_val'");
  await home('PRAGMA wal_checkpoint(TRUNCATE)');await home("INSERT INTO items VALUES(100004,1,'post-checkpoint',1,'cp')");result.checkpointPull=await db.pull();await parity('checkpoint');
  await db.close();db=await connect({path:`${dir}/R.db`,url:base});await db.pull();await parity('clientRestart');
  }catch(e){result.correctnessError=String(e)}
  if(db){await db.close();db=null}if(server&&server.exitCode===null&&server.signalCode===null)await stop();homePath=`${dir}/recovery-H.db`;await start();
  await home('CREATE TABLE t(id INTEGER PRIMARY KEY,val TEXT)');await home("INSERT INTO t VALUES(1,'base')");
  worker=spawn(process.execPath,[import.meta.filename,version,repeat,'worker',`${dir}/crash.db`,base],{stdio:['pipe','pipe',log.fd]});
  const lines=createInterface({input:worker.stdout});const iterator=lines[Symbol.asyncIterator]();if((await iterator.next()).value!=='ready')throw Error('worker bootstrap failed');
  for(let start=2;start<10002;start+=1000)await home('INSERT INTO t VALUES '+Array.from({length:1000},(_,k)=>`(${start+k},'v${start+k}')`).join(','));
  worker.stdin.write('pull\n');const marker=(await iterator.next()).value;const exited=once(worker,'exit');worker.kill('SIGKILL');const [code,signal]=await exited;result.replicaKill={marker,code,signal};worker=null;
  await home("INSERT INTO t VALUES(20000,'offline')");db=await connect({path:`${dir}/crash.db`,url:base});await db.pull();await parity('replicaCrash',['t']);
  await home("INSERT INTO t VALUES(20001,'before-home-kill')");await stop('SIGKILL');await start();await home("INSERT INTO t VALUES(20002,'after-home-kill')");await db.pull();await parity('homeCrash',['t']);
 }catch(e){result.error=String(e);result.stack=e.stack}
 finally{if(worker){worker.kill('SIGKILL');await once(worker,'exit')}if(db)try{await db.close()}catch{}if(server&&server.exitCode===null&&server.signalCode===null)await stop();await log.close();await writeFile(`${dir}/result.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result))}
}

set -euo pipefail
root=${1:?scratch root}
pids=()
failure=0
join() { for child in "${pids[@]}"; do wait "$child" || failure=1; done; pids=(); }
cd "$root"
(cd harness; node supplemental.mjs)
git -C "${2:?managed checkout}" rev-parse HEAD > artifacts/baseline.txt
for version in 0.8.2 0.8.3 0.9.0-pre.2; do
  for repeat in 1 2 3; do
    run="$root/semantic/$version/$repeat"
    mkdir -p "$run"
    ln -sfn "$root/js$version" "$run/js$version"
    ln -sfn "$root/bin$version" "$run/bin$version"
    (
      export SPIKE_ROOT="$run"
      timeout -k 5 300 node "$root/harness/cases.mjs" "$version" > "$run/cases.jsonl" 2> "$run/cases.stderr"
      timeout -k 5 180 node "$root/harness/supplemental-run.mjs" "$version" pullConflict,fkDefault,fkReverse > "$run/supplemental.jsonl" 2> "$run/supplemental.stderr"
    ) &
    pids+=("$!")
  done
done
join
export SPIKE_ROOT="$root"
for version in 0.8.2 0.8.3 0.9.0-pre.2; do
  for repeat in 1 2 3; do
    (timeout -k 5 240 node "$root/sql.mjs" "$version" "$repeat" > "$root/sql-$version-$repeat.jsonl" 2> "$root/sql-$version-$repeat.stderr") &
    pids+=("$!")
  done
done
join
mkdir -p "$root/issues"
for version in 0.8.2 0.8.3 0.9.0-pre.2; do
  for repeat in 1 2 3; do
    for issue in 8725 10178; do
      (timeout -k 5 45 node "$root/harness/repro.mjs" "$version" "$issue" "$repeat" > "$root/issues/$version-$issue-$repeat.jsonl" 2> "$root/issues/$version-$issue-$repeat.stderr") &
      pids+=("$!")
    done
  done
done
join
for version in 0.8.2 0.8.3 0.9.0-pre.2; do
  for rtt in 0 70 150; do
    timeout -k 5 180 unshare -Urn bash -c 'ip link set lo up; node "$1/harness/lag.mjs" "$2" "$3-100-"' _ "$root" "$version" "$rtt" >> "$root/lag-$version.jsonl" 2>> "$root/lag-$version.stderr" || failure=1
  done
  timeout -k 5 600 unshare -Urn bash -c 'ip link set lo up; node "$1/harness/lag-batch.mjs" "$2"' _ "$root" "$version" > "$root/lag-batch-$version.jsonl" 2> "$root/lag-batch-$version.stderr" || failure=1
done
exit "$failure"

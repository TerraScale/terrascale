import concurrent.futures as cf
import hashlib
import json
import os
from pathlib import Path
import platform
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
PACKAGES = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
VERSIONS = ('0.8.2', '0.8.3', '0.9.0-pre.2')


def varint(b, p):
    v = 0
    for i in range(9):
        c = b[p]
        p += 1
        v = (v << (8 if i == 8 else 7)) | (c if i == 8 else c & 127)
        if c < 128 or i == 8:
            return v, p
    raise ValueError('bad varint')


def decode(hexstr):
    if hexstr is None:
        return None
    b = bytes.fromhex(hexstr)
    end, p = varint(b, 0)
    body, out = end, []
    while p < end:
        t, p = varint(b, p)
        size = (0, 1, 2, 3, 4, 6, 8, 8, 0, 0)[t] if t < 10 else (t - 12) // 2
        assert t not in (10, 11) and body + size <= len(b)
        v = b[body:body + size]
        out.append(None if t == 0 else t - 8 if t in (8, 9) else struct.unpack('>d', v)[0] if t == 7 else int.from_bytes(v, 'big', signed=True) if t < 7 else {'hex': v.hex()} if t % 2 == 0 else v.decode())
        body += size
    assert body == len(b)
    return out


def allocation(file, roots):
    b = file.read_bytes()
    assert b[:16] == b'SQLite format 3\0'
    size = int.from_bytes(b[16:18], 'big')
    size = 65536 if size == 1 else size
    usable = size - b[20]
    result = {}
    for name, root in roots.items():
        seen, payloads, todo = set(), 0, [root]
        while todo:
            page = todo.pop()
            assert page not in seen and page > 0
            seen.add(page)
            base = (page - 1) * size
            h = base + (100 if page == 1 else 0)
            kind = b[h]
            assert kind in (2, 5, 10, 13)
            interior = kind in (2, 5)
            if interior:
                todo.append(int.from_bytes(b[h + 8:h + 12], 'big'))
            count = int.from_bytes(b[h + 3:h + 5], 'big')
            for i in range(count):
                ptr = h + (12 if interior else 8) + 2 * i
                p = base + int.from_bytes(b[ptr:ptr + 2], 'big')
                if interior:
                    todo.append(int.from_bytes(b[p:p + 4], 'big'))
                    p += 4
                if kind == 5:
                    continue
                n, p = varint(b, p)
                payloads += n
                if kind == 13:
                    _, p = varint(b, p)
                maximum = usable - 35 if kind == 13 else (usable - 12) * 64 // 255 - 23
                minimum = (usable - 12) * 32 // 255 - 23
                local = n if n <= maximum else minimum + (n - minimum) % (usable - 4)
                if local > maximum:
                    local = minimum
                if local < n:
                    overflow = int.from_bytes(b[p + local:p + local + 4], 'big')
                    while overflow:
                        assert overflow not in seen
                        seen.add(overflow)
                        p2 = (overflow - 1) * size
                        overflow = int.from_bytes(b[p2:p2 + 4], 'big')
        result[name] = {'allocated': len(seen) * size, 'recordPayload': payloads}
    return result


class Engine:
    def __init__(self, version, file, log):
        module = PACKAGES / version / 'node_modules/@tursodatabase/database/dist/promise.js'
        self.log = log
        self.p = subprocess.Popen(['node', str(ROOT / 'worker.mjs'), str(module), str(file)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True)

    def call(self, **request):
        self.p.stdin.write(json.dumps(request) + '\n')
        self.p.stdin.flush()
        line = self.p.stdout.readline()
        if not line:
            raise RuntimeError(f'engine exited {self.p.poll()}')
        response = json.loads(line)
        if not response['ok']:
            raise RuntimeError(response['error'])
        return response['result']

    def sql(self, q):
        return self.call(sql=q)

    def stop(self, crash=False):
        if self.p.poll() is None:
            if crash:
                self.p.kill()
            else:
                self.p.stdin.close()
            self.p.wait(timeout=15)


def records(e):
    return e.sql('SELECT change_id,change_type,table_name,id,change_txn_id,CASE WHEN before IS NULL THEN NULL ELSE hex(before) END AS b,CASE WHEN after IS NULL THEN NULL ELSE hex(after) END AS a FROM turso_cdc ORDER BY change_id')


def qualification(e, version, file, log):
    result = {}
    e.sql('CREATE TABLE items(k TEXT PRIMARY KEY,v INTEGER,n TEXT,b BLOB)')
    e.sql('CREATE TABLE audit(k TEXT,v INTEGER)')
    e.sql('CREATE TRIGGER changed AFTER UPDATE ON items BEGIN INSERT INTO audit VALUES(new.k,new.v); END')
    e.sql("PRAGMA capture_data_changes_conn('full')")
    before = ["00000000000000000000000001", -42, None, {'hex': '00ff0080'}]
    after = [before[0], 257, 'text-λ', {'hex': 'ff00'}]
    e.sql(f"INSERT INTO items VALUES('{before[0]}',-42,NULL,x'00ff0080')")
    e.sql(f"UPDATE items SET v=257,n='text-λ',b=x'ff00' WHERE k='{before[0]}'")
    e.sql('DELETE FROM items')
    rows = [r for r in records(e) if r['table_name'] == 'items']
    assert [(r['change_type'], decode(r['b']), decode(r['a'])) for r in rows] == [(1, None, before), (0, before, after), (-1, after, None)]
    assert e.sql('SELECT * FROM audit') == [{'k': before[0], 'v': 257}]
    result['images_null_blob_trigger'] = 'PASS'
    old = records(e)
    e.sql('BEGIN')
    e.sql("INSERT INTO items VALUES('00000000000000000000000002',2,NULL,x'')")
    e.sql("INSERT INTO items VALUES('00000000000000000000000003',3,NULL,x'01')")
    e.sql('COMMIT')
    committed = records(e)[len(old):]
    assert len(committed) == 3 and committed[-1]['change_type'] == 2
    assert len({r['change_txn_id'] for r in committed}) == 1
    old = records(e)
    e.sql('BEGIN')
    e.sql('DELETE FROM items')
    e.sql('ROLLBACK')
    assert records(e) == old and len(e.sql('SELECT * FROM items')) == 2
    result['commit_rollback'] = 'PASS'
    result['checkpoint'] = e.sql('PRAGMA wal_checkpoint(TRUNCATE)')
    assert records(e) == old
    result['checkpoint_images'] = 'PASS'
    try:
        e.sql("ALTER TABLE items ADD COLUMN extra TEXT DEFAULT 'added'")
        e.sql("UPDATE items SET extra='new' WHERE v=2")
        changed = [r for r in records(e)[len(old):] if r['table_name'] == 'items'][-1]
        assert decode(changed['b']) == ['00000000000000000000000002', 2, None, {'hex': ''}, 'added']
        assert decode(changed['a']) == ['00000000000000000000000002', 2, None, {'hex': ''}, 'new']
        result['alter_post_schema'] = 'PASS'
    except Exception as error:
        result['alter_post_schema'] = f'FAIL: {error}'
    try:
        e.sql('CREATE INDEX items_v ON items(v)')
        assert e.sql("SELECT name FROM sqlite_schema WHERE name='items_v'")
        result['create_index'] = 'PASS'
    except Exception as error:
        result['create_index'] = f'FAIL: {error}'
    old = records(e)
    result['records_before_restart'] = old
    e.stop(crash=True)
    e = Engine(version, file, log)
    try:
        e.sql("PRAGMA capture_data_changes_conn('full')")
        assert records(e) == old
        for record in old:
            decode(record['b'])
            decode(record['a'])
        e.sql('UPDATE items SET v=v+10 WHERE v=3')
        new = records(e)[len(old):]
        row = next(r for r in new if r['table_name'] == 'items')
        assert row['change_id'] > old[-1]['change_id']
        assert decode(row['b'])[:4] == ['00000000000000000000000003', 3, None, {'hex': '01'}]
        assert decode(row['a'])[:4] == ['00000000000000000000000003', 13, None, {'hex': '01'}]
        result['restart_old_and_new'] = 'PASS'
        result['records_after_restart'] = records(e)
    finally:
        e.stop()
    return result


def growth(e, file, rate, capture):
    autocheckpoint = e.sql('PRAGMA wal_autocheckpoint')
    e.sql('CREATE TABLE items(k TEXT PRIMARY KEY,body TEXT,b BLOB)')
    if capture:
        e.sql("PRAGMA capture_data_changes_conn('full')")
    roots = {r['name']: r['rootpage'] for r in e.sql('SELECT name,rootpage FROM sqlite_schema WHERE rootpage>0')}
    before_checkpoint = e.sql('PRAGMA wal_checkpoint(TRUNCATE)')
    baseline = allocation(file, roots)
    sizes = {'baseline': file.stat().st_size}
    timing = e.call(grow=True, rate=rate)
    sizes.update(dbBeforeCheckpoint=file.stat().st_size, walBeforeCheckpoint=Path(str(file) + '-wal').stat().st_size)
    n = rate * 30
    assert e.sql('SELECT count(*) AS n FROM items')[0]['n'] == n
    counts = e.sql('SELECT change_type,count(*) AS n FROM turso_cdc GROUP BY change_type') if capture else []
    if capture:
        assert {r['change_type']: r['n'] for r in counts} == {1: n, 2: n}
    images = e.sql('SELECT sum(coalesce(length(before),0)+coalesce(length(after),0)+coalesce(length(updates),0)) AS n FROM turso_cdc')[0]['n'] if capture else 0
    checkpoint = e.sql('PRAGMA wal_checkpoint(TRUNCATE)')
    sizes.update(dbAfterCheckpoint=file.stat().st_size, walAfterCheckpoint=Path(str(file) + '-wal').stat().st_size)
    final = allocation(file, roots)
    return dict(writes=n, timing=timing, sizes=sizes, baseline=baseline, final=final, counts=counts, imageBytes=images, walAutocheckpoint=autocheckpoint, baselineCheckpoint=before_checkpoint, checkpoint=checkpoint)


def run(case):
    version, repeat, rate, capture = case
    name = f'{version}-r{repeat}-' + (f'{rate}-{capture}' if rate else 'qualification')
    result = dict(version=version, repeat=repeat, rate=rate, capture=capture)
    with tempfile.TemporaryDirectory(prefix='cdc-', dir=OUT) as directory, open(OUT / f'{name}.stderr', 'w') as log:
        file = Path(directory) / 'engine.db'
        e = Engine(version, file, log)
        try:
            result['result'] = growth(e, file, rate, capture) if rate else qualification(e, version, file, log)
        except Exception as error:
            result['failure'] = repr(error)
        finally:
            e.stop()
    (OUT / f'{name}.json').write_text(json.dumps(result, indent=2) + '\n')
    print(name, 'FAIL' if 'failure' in result else 'RECORDED', flush=True)
    return result


environment = dict(host=platform.node(), platform=platform.platform(), cpu=platform.processor(), cpus=os.cpu_count(), node=subprocess.check_output(['node', '--version'], text=True).strip(), harness={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT / 'worker.mjs', ROOT / 'run.py')})
(OUT / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
cases = [(v, r, 0, True) for v in VERSIONS for r in (1, 2, 3)]
with cf.ThreadPoolExecutor(max_workers=9) as pool:
    results = list(pool.map(run, cases))
for v in VERSIONS:
    for r in (1, 2, 3):
        for rate in (1, 10, 100):
            with cf.ThreadPoolExecutor(max_workers=2) as pool:
                results.extend(pool.map(run, [(v, r, rate, capture) for capture in (False, True)]))
(OUT / 'all.json').write_text(json.dumps(results, separators=(',', ':')) + '\n')

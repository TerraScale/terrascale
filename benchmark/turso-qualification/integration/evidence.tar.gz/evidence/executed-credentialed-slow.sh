set -euo pipefail
ts-dev-secret get dev-tigris-ci-env | bash -c 'set -euo pipefail; set -a; source /dev/stdin; set +a; exec python3 benchmark/turso-qualification/integration/qualify.py --slow-only'

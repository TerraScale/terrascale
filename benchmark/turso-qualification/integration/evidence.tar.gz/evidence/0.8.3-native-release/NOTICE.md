Turso
=====

Please visit our GitHub for more information:

* https://github.com/tursodatabase/turso

Dependencies
============

This product depends on Error Prone, distributed by the Error Prone project:

* License: licenses/bindings/java/assertj-license.md (Apache License v2.0)
* Homepage: https://github.com/google/error-prone

This product depends on AssertJ, distributed by the AssertJ authors:

* License: licenses/bindings/java/errorprone-license.md (Apache License v2.0)
* Homepage: https://joel-costigliola.github.io/assertj/

This product depends on logback, distributed by the logback authors:

* License: licenses/bindings/java/logback-license.md (Apache License v2.0)
* Homepage: https://github.com/qos-ch/logback?tab=License-1-ov-file

This product depends on spotless, distributed by the diffplug authors:

* License: licenses/bindings/java/spotless-license.md (Apache License v2.0)
* Homepage: https://github.com/diffplug/spotless


This project depends on ipnetwork, distributed by the ipnetwork project:

* License: licenses/extensions/ipnetwork-apache-license.md (Apache License v2.0)
* License: licenses/extensions/ipnetwork-mit-license.md (MIT License)
* Homepage: https://github.com/achanda/ipnetwork

This project depends on libm, distributed by the rust-lang project:

* License: licenses/extensions/libm-apache-license.md (Apache License v2.0)
* License: licenses/extensions/libm-mit-license.md (MIT License)
* Homepage: https://github.com/rust-lang/libm

This project includes a vendored copy of crossbeam-skiplist (in `core/skiplist`), distributed by the Crossbeam project developers:

* License: licenses/core/crossbeam-skiplist-apache-license.md (Apache License v2.0)
* License: licenses/core/crossbeam-skiplist-mit-license.md (MIT License)
* Homepage: https://github.com/crossbeam-rs/crossbeam

This project depends on pastey, distributed by the pastey authors:

* License: licenses/core/pastey-apache-license.md (Apache License v2.0)
* License: licenses/core/pastey-mit-license.md (MIT License)
* Homepage: https://github.com/AS1100K/pastey

This project depends on windows-sys, distributed by the Microsoft:

* License: licenses/core/windows-apache.license.md (Apache License v2.0)
* License: licenses/core/windows-mit-license.md (MIT License)
* Homepage: https://github.com/microsoft/windows-rs

This project depends on SQLAlchemy, distributed by the SQLAlchemy authors:

* License: licenses/bindings/python/sqlalchemy-mit-license.md (MIT License)
* Homepage: https://github.com/sqlalchemy/sqlalchemy

The FTS benchmark depends on pprof, distributed by the TiKV project:

* License: licenses/perf/pprof-apache-license.md (Apache License v2.0)
* Homepage: https://github.com/tikv/pprof-rs

The FTS profiler depends on spin, distributed by the spin-rs authors:

* License: licenses/perf/spin-mit-license.md (MIT License)
* Homepage: https://github.com/mvdnes/spin-rs

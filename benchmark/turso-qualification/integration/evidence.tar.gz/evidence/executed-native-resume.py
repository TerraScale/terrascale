import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

root = Path.cwd()
if root.parent.parent.name != "remote-builds" or subprocess.check_output(["git", "branch", "--show-current"], text=True).strip() != "feat/turso-qualification-integration":
    raise RuntimeError("Run only in the assigned ts-heavy-any disposable workspace")
out = root / "benchmark/turso-qualification/integration/evidence"
out.mkdir(parents=True, exist_ok=True)
scratch = Path(tempfile.mkdtemp(prefix="turso-integration-"))
vendor = root / "src/vendor/Turso.Data.Sqlite"
baseline = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
receipt = {"repository_sha": baseline, "host": os.uname().nodename, "scratch": str(scratch), "steps": []}
native_recipe = (root / "scripts/vendor/Dockerfile.turso-native").read_text()
eligible = {}


def run(name, command, cwd=root):
    started = time.time()
    with (out / (name + ".log")).open("w") as log:
        result = subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    step = {"name": name, "command": command, "exit": result.returncode, "seconds": round(time.time() - started, 3)}
    receipt["steps"].append(step)
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(name + ": exit=" + str(result.returncode) + " seconds=" + str(step["seconds"]), flush=True)
    return result.returncode


def capture(command):
    return subprocess.check_output(command, text=True).strip()


if "--native-only" in sys.argv:
    receipt = json.loads((out / "receipt.json").read_text())
    baseline = receipt["repository_sha"]
    scratch = Path(receipt["scratch"])
    sources = receipt["source_commits"]
    eligible = {"0.8.3": next((scratch / "0.8.3").iterdir())}
else:
    run("environment", ["bash", "-c", "uname -a; dotnet --info; rustc --version; cargo --version; git -C /home/mariogk/Projects/TerraScale/ts-dotnet rev-parse HEAD; df -h ."])
    run("latest-release", ["gh", "api", "repos/tursodatabase/turso/releases/latest", "--jq", "{tag_name,target_commitish,published_at,prerelease}"])
    refs = capture(["git", "ls-remote", "https://github.com/tursodatabase/turso.git", "refs/tags/v0.8.2", "refs/tags/v0.8.2^{}", "refs/tags/v0.8.3", "refs/tags/v0.8.3^{}", "refs/tags/v0.9.0-pre.2", "refs/tags/v0.9.0-pre.2^{}"])
    (out / "tag-refs.log").write_text(refs + "\n")
    sources = {"baseline": "5c168be5ef6a32ac966daf5983502a4f694b37ad"}
    refmap = dict(line.split()[::-1] for line in refs.splitlines())
    for version in ("0.8.3", "0.9.0-pre.2"):
        tag = "refs/tags/v" + version
        sources[version] = refmap.get(tag + "^{}", refmap[tag])
    receipt["source_commits"] = sources
    native_patches = [root / "src/vendor/Turso.Native/patches/0001-preserve-page-authentication-damage.patch", root / "src/vendor/Turso.Native/patches/0002-select-runtime-aegis-c-backend.patch", root / "scripts/vendor/turso-native-budget.patch"]
    receipt["patch_sha256"] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in native_patches + sorted((vendor / "patches").glob("*.patch")) + [root / "src/vendor/Turso.Native/patches/0003-keep-aegis-c-runtime-portable.patch"]}
    for version, commit in sources.items():
        archive = scratch / (version + ".tar.gz")
        if run(version + "-download", ["curl", "--fail", "--location", "--retry", "2", "https://codeload.github.com/tursodatabase/turso/tar.gz/" + commit, "-o", str(archive)]):
            continue
        receipt.setdefault("archive_sha256", {})[version] = hashlib.sha256(archive.read_bytes()).hexdigest()
        unpack = scratch / version
        unpack.mkdir()
        with tarfile.open(archive) as bundle:
            bundle.extractall(unpack, filter="data")
        source = next(unpack.iterdir())
        header = source / "sdk-kit/turso.h"
        shutil.copyfile(header, out / (version + "-turso.h.txt"))
        shutil.copyfile(source / "sync/sdk-kit/turso_sync.h", out / (version + "-turso_sync.h.txt"))
        run(version + "-native-metadata", ["bash", "-c", "cat Cargo.toml sdk-kit/Cargo.toml sync/sdk-kit/Cargo.toml; rg -n 'name = \"aegis\"|version = \"0\\.[0-9]+\\.[0-9]+\"' Cargo.lock | head -35"], source)
        if version == "baseline":
            continue
        run(version + "-abi-diff", ["diff", "-u", str(out / "baseline-turso.h.txt"), str(out / (version + "-turso.h.txt"))])
        run(version + "-sync-abi-diff", ["diff", "-u", str(out / "baseline-turso_sync.h.txt"), str(out / (version + "-turso_sync.h.txt"))])
        for repeat in range(1, 4):
            label = version + "-r" + str(repeat)
            work = scratch / label
            shutil.copytree(source, work)
            native_ok = True
            for patch in native_patches:
                if run(label + "-native-" + patch.stem, ["git", "apply", "--check", str(patch)], work):
                    native_ok = False
                    break
                run(label + "-native-apply-" + patch.stem, ["git", "apply", str(patch)], work)
            run(label + "-restore-vendor", ["git", "restore", "--source=" + baseline, "--staged", "--worktree", "--", str(vendor.relative_to(root))])
            shutil.rmtree(vendor / "src")
            (vendor / "src").mkdir()
            for project in ("Turso.Raw", "Turso.Data", "Turso.Data.Sqlite"):
                shutil.copytree(source / "bindings/dotnet/src" / project, vendor / "src" / project)
            for license_name in ("LICENSE.md", "NOTICE.md"):
                shutil.copyfile(source / license_name, vendor / license_name)
            run(label + "-stage-import", ["git", "add", "-A", "--", str(vendor.relative_to(root))])
            binder_ok = True
            for patch in sorted((vendor / "patches").glob("*.patch")):
                if run(label + "-binder-" + patch.stem, ["git", "apply", "--3way", "--whitespace=nowarn", "--directory=" + str(vendor.relative_to(root)), str(patch)]):
                    binder_ok = False
                    break
            receipt.setdefault("candidate_gates", []).append({"version": version, "repeat": repeat, "native_patch_queue": native_ok, "binder_patch_queue": binder_ok})
            (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
            if native_ok and binder_ok:
                eligible[version] = source
            shutil.rmtree(work)
    run("restore-baseline-vendor", ["git", "restore", "--source=" + baseline, "--staged", "--worktree", "--", str(vendor.relative_to(root))])
    os.environ["TsDotnetRoot"] = "/home/mariogk/Projects/TerraScale/ts-dotnet"
    if run("baseline-native-download", ["bash", "scripts/vendor/download-turso-native.sh"]):
        raise RuntimeError("Pinned baseline native delivery failed")
    run("baseline-native-sha256", ["sha256sum", "src/vendor/Turso.Data.Sqlite/native/runtimes/linux-x64/native/libturso_sdk_kit.so", "src/vendor/Turso.Data.Sqlite/native/runtimes/linux-arm64/native/libturso_sdk_kit.so"])
    for suite in ("fast", "slow"):
        for repeat in range(1, 4):
            run("baseline-" + suite + "-r" + str(repeat), ["make", "terrabase-test-" + suite, "CONFIGURATION=Release"])
for version, source in eligible.items():
    run(version + "-restore-vendor-for-build", ["git", "restore", "--source=" + baseline, "--staged", "--worktree", "--", str(vendor.relative_to(root))])
    shutil.rmtree(vendor / "src")
    (vendor / "src").mkdir()
    for project in ("Turso.Raw", "Turso.Data", "Turso.Data.Sqlite"):
        shutil.copytree(source / "bindings/dotnet/src" / project, vendor / "src" / project)
    run(version + "-stage-build-import", ["git", "add", "-A", "--", str(vendor.relative_to(root))])
    for patch in sorted((vendor / "patches").glob("*.patch")):
        if run(version + "-build-binder-" + patch.stem, ["git", "apply", "--3way", "--whitespace=nowarn", "--directory=" + str(vendor.relative_to(root)), str(patch)]):
            raise RuntimeError("Previously eligible binder queue changed")
    recipe = native_recipe.replace(sources["baseline"], sources[version]).replace("7ea83d5e28577cf9d8655b77705902379e06b82fb29424f6ea328b5f26f17ecb", receipt["archive_sha256"][version]).replace("version=0.8.2", "version=" + version)
    recipe = "\n".join(line for line in recipe.splitlines() if not line.lstrip().startswith("#")) + "\n"
    (root / "scripts/vendor/Dockerfile.turso-native").write_text(recipe)
    (out / (version + "-Dockerfile.txt")).write_text(recipe)
    artifact = scratch / (version + "-native")
    if run(version + "-native-build-docker", ["env", "BUILDAH_FORMAT=docker", "bash", "scripts/vendor/build-turso-native.sh", "amd64", str(artifact)]):
        continue
    native = artifact / "runtimes/linux-x64/native/libturso_sdk_kit.so"
    digest = hashlib.sha256(native.read_bytes()).hexdigest()
    receipt.setdefault("native_sha256", {})[version] = digest
    shutil.copytree(artifact / "release", out / (version + "-native-release"), dirs_exist_ok=True)
    shutil.copyfile(native, vendor / "native/runtimes/linux-x64/native/libturso_sdk_kit.so")
    pins = root / "src/vendor/Turso.Native/SHA256SUMS"
    pins.write_text(pins.read_text().replace("7464a29f3fc9bce603a1e0881720b309a276455a778937d6a9ffc2ed680bd76d", digest))
    for suite in ("fast", "slow"):
        for repeat in range(1, 4):
            run(version + "-" + suite + "-r" + str(repeat), ["make", "terrabase-test-" + suite, "CONFIGURATION=Release"])
run("restore-disposable-inputs", ["git", "restore", "--source=" + baseline, "--staged", "--worktree", "--", str(vendor.relative_to(root)), "src/vendor/Turso.Native/SHA256SUMS", "scripts/vendor/Dockerfile.turso-native"])
print("Evidence directory: " + str(out), flush=True)

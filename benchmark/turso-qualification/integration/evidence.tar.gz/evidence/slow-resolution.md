Environment setup resolved at repository SHA `4bacd8a818cff3fab76f3f0558bdc4585361e617` on beta (NixOS 26.05, linux-x64, .NET 11.0.100-rc.1.26425.128, Release, managed ts-heavy-any workspace). The original failed repeats and logs remain recorded; no tests or production code were changed.

The isolated SDK export now uses CI commit `2dda37f08abe7497b35dc431895960e70f3c3611`. OCI Vault `dev-tigris-ci-env` was piped directly into the test consumer, without logging credentials. With that corrected environment:

| Input | Slow repeat exits | Tests in each repeat | Target seconds |
|---|---|---|---|
| Exact patched baseline | 0 / 0 / 0 | 90 total, 89 passed, 0 failed, 1 existing child-host helper skip | 126.032 / 118.635 / 122.201 |
| Custom patched 0.8.3 | 0 / 0 / 0 | 90 total, 89 passed, 0 failed, 1 existing child-host helper skip | 250.804 / 123.871 / 110.420 |

All three previously failing Tigris tests passed in each of these six full-suite runs. The unchanged target was `make terrabase-test-slow CONFIGURATION=Release`, with CI SDK scratch export supplied through `TsDotnetRoot`. Reproduction uses the committed qualification harness and its `with-ci-storage.sh` pipeline wrapper through `ts-heavy-any`, assigned branch `feat/turso-qualification-integration`.

Evidence: `benchmark/bench/2026-10-29-turso-qualification-integration.md` and `benchmark/turso-qualification/integration/evidence.tar.gz`. No CI run URL: developer-host qualification. Slow remains independent and non-blocking. The separate 0.8.3 Fast repeat-2 HTTP 429 remains unresolved and prevents clean Fast qualification; closure of this environment report does not qualify a release.

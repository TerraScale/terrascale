TerraBase Turso qualification at repository SHA `4bacd8a818cff3fab76f3f0558bdc4585361e617`.
Environment: beta, NixOS linux-x64, .NET 11.0.100-rc.1.26425.128, Release, managed ts-heavy-any workspace.
Native baseline: exact upstream `5c168be5ef6a32ac966daf5983502a4f694b37ad` plus TerraScale patches; source/artifact identities and per-repeat results are in `benchmark/bench/2026-10-29-turso-qualification-integration.md`.
CI run URL: none; this is a managed developer-host qualification run.
Reproduce: transfer `benchmark/turso-qualification/integration/qualify.py` into the assigned managed workspace and run `nice -n 19 ts-heavy-any python3 benchmark/turso-qualification/integration/qualify.py --repo terrascale --branch feat/turso-qualification-integration`. The harness records each native build and source patch command in `receipt.json` and invokes `make terrabase-test-slow CONFIGURATION=Release` without changing test parallelism.
Expected: the existing Slow suite builds and every integration test passes for the recorded input. Actual: the failures below occurred. Slow remains non-blocking; the required Fast gate is separate.
Failed test or runner: A_catch_up_reaches_two_regions_through_chunks_put_once_in_Tigris
- baseline-ci-sdk-slow-r2: exit 2, 114.349 s
- baseline-ci-sdk-slow-r3: exit 2, 109.504 s
Redacted logs:
```text
failed A_catch_up_reaches_two_regions_through_chunks_put_once_in_Tigris (573ms)
  TUnit.Engine.Exceptions.TestFailedException: [Test Failure] InvalidOperationException: required Tigris CI credential AWS_ACCESS_KEY_ID [redacted] missing
    at TerraBase.Slow.Backup.TigrisCiBucket.Variable(String name) in /home/mariogk/remote-builds/terrascale/feat-turso-qualification-integration-f598f9acc4cba457708cf84c19fee2cae6f37ba673ef16ec4dba6ff0e7011cea/tests/TerraBase.Slow/Backup/TigrisBackupTests.cs:230
    at TerraBase.Slow.Backup.TigrisCiBucket.Client() in /home/mariogk/remote-builds/terrascale/feat-turso-qualification-integration-f598f9acc4cba457708cf84c19fee2cae6f37ba673ef16ec4dba6ff0e7011cea/tests/TerraBase.Slow/Backup/TigrisBackupTests.cs:223
    at TerraBase.Slow.Replication.TigrisLogChunkTests.A_catch_up_reaches_two_regions_through_chunks_put_once_in_Tigris(CancellationToken [redacted] in /home/mariogk/remote-builds/terrascale/feat-turso-qualification-integration-f598f9acc4cba457708cf84c19fee2cae6f37ba673ef16ec4dba6ff0e7011cea/tests/TerraBase.Slow/Replication/TigrisLogChunkTests.cs:114
       --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---

```

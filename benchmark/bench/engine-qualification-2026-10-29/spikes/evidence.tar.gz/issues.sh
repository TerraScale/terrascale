set -euo pipefail
export SPIKE_ROOT=/home/mariogk/spikes/turso-qualification-spikes-20261029
mkdir -p "$SPIKE_ROOT/issues"
for version in 0.8.2 0.8.3 0.9.0-pre.2; do
 for repeat in 1 2 3; do
  for issue in 8725 10178; do
   (timeout -k 5 45 node "$SPIKE_ROOT/harness/repro.mjs" "$version" "$issue" "$repeat" > "$SPIKE_ROOT/issues/$version-$issue-$repeat.jsonl" 2> "$SPIKE_ROOT/issues/$version-$issue-$repeat.stderr") &
  done
 done
done
wait

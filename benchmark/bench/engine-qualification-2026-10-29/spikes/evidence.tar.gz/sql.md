# SQL-only TerraBase replication spike — 2026-10-29

## Decision

**DECISION: use Turso Sync's WAL/page pull protocol for read-only replicas, with every SQL write and write transaction forwarded to the database's home. Reason: the official protocol preserved SQL data and DDL in the measured workload; a generic CDC row applier did not support ALTER, and logical replay also needs explicit trigger/FK semantics. Keep replica push and MVCC synchronization disabled.**

This selects candidate 1's replication mechanism, not an unchanged production deployment of the development `tursodb --sync-server`. Productionizing the authority, bounding WAL history and implementing fenced failover remain substantial work. Estimated replication-specific effort: **40–65 engineer-days**, including the gaps below. Candidate 2 is approximately **45–75 engineer-days**. These estimates exclude the SQL-only storage/API migration (the prior research estimated 90–150 engineer-days), new infrastructure and any new credential/permission approvals. Both candidates still have production gates; this spike authorizes none of them.

The choice does not depend on a claimed sub-200 ms cross-region SLO. The dev-host results have outliers, and measured FRA↔GRU TCP RTT alone is about 181–189 ms.

## Scope and provenance

- Read the requested research first. Inspected TerraScale only through `git show origin/main:<path>` / read-only tree metadata, pinned to `4bacd8a818cff3fab76f3f0558bdc4585361e617`. No checkout, worktree, production configuration, PR or secret-store changes.
- All replication workloads and binaries ran on delta, beta and mariogk-dev. `ts-host -v` selected beta initially (load/core 0.003, versus 0.007 on mariogk-dev and 0.133 on delta). Scratch was exactly `/home/mariogk/spikes/sql-repl-20261029` on each dev host.
- **DECISION: treat the explicitly requested read-only cross-region probes as an exception to the dev-only workload restriction. Reason: direct inter-region RTT requires an origin in each region.** Existing `ts-gru-1`, `ts-sjc-1`, `ts-fra-1` ran only short Python-in-stdin socket connects, ICMP probes and an IMDS region read. No files, deployments, services, permissions or instances were created or changed there.
- Verified OCI region names with `oci iam region list` and each existing node's IMDS: gru=`sa-saopaulo-1`, sjc=`us-sanjose-1`, fra=`eu-frankfurt-1`. No region substitutions.
- Candidate 1: upstream CLI 0.8.2 authority; official vendored .NET `TursoSyncDatabase`, version 0.8.2 plus TerraScale patches, Linux x64 native asset downloaded by the exported `scripts/vendor/download-turso-native.sh`. Pin verification passed for both native architectures. Used the explicit Create/Open and Pull APIs, never automatic push, in WAL mode.
- Candidate 2: small single-writer CDC prototype using the same vendored runtime. Mode `after`; ordered `change_id` records through complete commit markers; SQLite-record decoding copied from `TursoChangeTap.cs`; image replay with rowids; commit and replica cursor in the same target transaction. No LWW, merge logic or production replication service was reused. ALTER mutations fail closed. This is a measured prototype, not a complete shipper.
- Upstream issue reproducers used matching official npm sync 0.8.2/0.8.3 clients and matching CLI servers. The 0.8.3 issue results are not a qualification of an upgraded TerraScale .NET/native runtime.
- Hardware: beta AMD Ryzen 5 PRO 6650H/12 logical CPUs; delta i7-13620H/16; mariogk-dev Xeon E5-2660 v4/46. All x86_64, Linux 7.3.0; .NET `11.0.100-rc.1.26425.128`. These shared dev machines are not the OCI ARM serving environment.

Artifact SHA-256:

| Artifact | SHA-256 |
|---|---|
| TerraScale 0.8.2 `libturso_sdk_kit.so`, linux-x64 | `7464a29f3fc9bce603a1e0881720b309a276455a778937d6a9ffc2ed680bd76d` |
| Upstream `tursodb` 0.8.2 | `e973cccf573ca6cc44a2f7b0db36c47ef319c6d2c29b17d1eec9aba37c1e95fb` |
| Upstream `tursodb` 0.8.3 | `8125a4aa4bdf7deb316498e24d2610f1ac4ea084421273a7965bad9e91437841` |

## Correctness

Each candidate had three independent fresh 100k-item runs. Schema: 100 parent rows; `items(id INTEGER PRIMARY KEY, parent_id REFERENCES parent(id), name TEXT UNIQUE, val INTEGER)`. Inserted 100,000 items in 1,000-row statements; updated 10,000; deleted 5,000; committed a multi-statement parent+child insert and another update; rolled back an additional insert. Final DML state: 95,001 items and 101 parents. The home rejected duplicate-UNIQUE and dangling-FK writes. Then executed `ALTER TABLE items ADD COLUMN extra TEXT DEFAULT 'added'` and `CREATE INDEX idx_items_val ON items(val)`.

Hashes cover every column of both application tables, ordered by table name and primary key, serialized to compact JSON and SHA-256 hashed. Hrana integer strings were normalized to integers before hashing. Index presence and source constraint failures were checked separately. Row hashes are not physical file hashes or proof of every SQL feature.

| Check | Turso Sync, WAL pull-only | Own CDC prototype |
|---|---|---|
| 100k inserts, updates, deletes; final exact row hash | PASS 3/3 | PASS 3/3 |
| UNIQUE and FK rejected at home; invalid rows absent from replica hash | PASS 3/3 | PASS 3/3 |
| Multi-statement committed transaction and rollback, final parity | PASS 3/3 | PASS 3/3 |
| ALTER TABLE, including existing rows' default value | PASS 3/3 | REFUSED 3/3: schema mutation requires a DDL envelope or snapshot |
| CREATE INDEX | PASS 3/3, index present | PASS 3/3 independently before ALTER; main sequence refuses ALTER |
| Entire requested DML+DDL workload | PASS 3/3 | FAIL 3/3, deliberately refuses rather than silently diverging |
| Kill replica during active apply/pull, reopen, resume, exact hash | PASS 3/3 | PASS 3/3 |
| Kill home after acknowledged commit, restart, add writes, exact hash | PASS 3/3 | PASS 3/3 |
| Damage closed replica's 16-byte database header, reopen/query | REFUSED 3/3: `file is not a database` | REFUSED 3/3: `file is not a database` |
| Truncated SQLite-record image on the CDC transport | Not this protocol | REFUSED 3/3; application rows and durable cursor unchanged |

All three repeats produced these identical hashes:

| State | SHA-256 |
|---|---|
| Initial 100,000 items + 100 parents | `8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd` |
| Final DML, home and both replicas | `9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22` |
| After ALTER, home and Sync replica | `565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d` |

Recovery used 10,000 changes queued behind an initial row, killed the replica while its operation was still active (`SIGKILL`, exit -9), and committed an additional row while it was down. Reopened without deleting the replica or sidecars. CDC was killed after its target apply request had begun, with the source packet prefetched; its three persisted resume cursors were [1005, 2006, 2006], proving stream progress before the kill. CDC resumed from its durable commit cursor; Sync used `TursoSyncDatabase.Open`, then Pull. An abrupt home kill happened after another acknowledged write; both recovered that write and a new post-restart write. This is a process-crash test, not power-loss or disk-controller durability proof. Header damage and malformed records do not establish detection of arbitrary valid-looking bit rot; authenticated/checksummed transport, integrity scans and fail-closed rebuild remain production work.

| Replica catch-up after reopen, milliseconds | Repeat 1 | Repeat 2 | Repeat 3 |
|---|---:|---:|---:|
| Turso Sync | 65.55 | 65.38 | 70.89 |
| CDC | 402.78 | 319.10 | 327.76 |

The timer covers catch-up after opening the replica, not total process startup or failure detection. Recovery rows matched SHA-256 `377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc` (10,002 rows); after the home restart both matched `3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0` (10,004 rows).

## Replica lag

All values below are milliseconds, with repeats 1 / 2 / 3 shown separately. A source marker is stamped on the home controller immediately before its transaction. The replica emits its own timestamp immediately after a successful Pull or CDC apply; a subsequent query identifies newly applied markers. Thus the metric includes home commit and shipping/apply time. It is a conservative batch-completion visibility delay for earlier rows in a pull/drain, not an isolated network delay or a per-row microsecond timestamp. The verification query's completion time is excluded.

Each fresh run schedules 200 transactions over a 10 s offered-load window: 10 rows/transaction at 200 row writes/s, 100 rows/transaction at 2,000 row writes/s, both at 20 transactions/s. Each case supplies 2,000 or 20,000 row observations, correlated within batches. p50/p99 use the sorted observed values at indices floor(0.50N)/floor(0.99N). Source elapsed time is first submission through the final commit, so a last submission at 9.95 s explains achieved rates slightly above the offered rate. The 10 s runs do not prove sustained long-term capacity. **These are row-write rates, not 200 or 2,000 separate transactions/s.**

The home is beta in every case. Cross-host Sync uses an SSH reverse forward to the loopback-only authority; CDC uses SSH stdio RPC. There is one measured replica at a time, not simultaneous three-replica fan-out. The controller polls at 1 ms after each completed pass. Both transports include real dev-host IPC/network cost, but they are different prototypes, not the same production TLS transport. No synthetic WAN delay was inserted.

Clocks were calibrated with 21 request/response probes before and after each run, using the minimum-RTT midpoint offset. Largest half-RTT was 0.287 ms, largest observed offset drift was 0.215 ms; allow roughly 0.51 ms calibration uncertainty under the usual bounded-asymmetry/drift assumption. Begin offsets were applied to the data; the small end drift was measured rather than silently ignored. Pilot runs using later verification-read timestamps were excluded from this final table; no recovery or issue workload overlapped these final runs.

| Candidate | Home → replica | Offered rows/s | p50, R1 / R2 / R3 | p99, R1 / R2 / R3 | Achieved rows/s, R1 / R2 / R3 |
|---|---|---:|---|---|---|
| Sync | beta → beta | 200 | 25.69 / 26.00 / 26.94 | 32.14 / 32.83 / 35.66 | 200.9 / 200.8 / 200.8 |
| Sync | beta → beta | 2,000 | 26.39 / 25.93 / 26.02 | 32.81 / 33.11 / 34.32 | 2008.9 / 2008.0 / 2008.7 |
| Sync | beta → delta | 200 | 24.17 / 31.87 / 22.39 | 32.61 / 148.40 / 205.17 | 200.8 / 200.9 / 200.9 |
| Sync | beta → delta | 2,000 | 25.24 / 22.58 / 45.36 | 113.09 / 36.01 / 627.10 | 2008.1 / 2009.2 / 1549.2 |
| Sync | beta → mariogk-dev | 200 | 28.26 / 27.10 / 31.49 | 54.92 / 120.52 / 101.70 | 200.9 / 200.9 / 200.9 |
| Sync | beta → mariogk-dev | 2,000 | 27.74 / 28.26 / 27.01 | 58.92 / 80.09 / 66.24 | 2007.7 / 2008.1 / 2009.4 |
| CDC | beta → beta | 200 | 3.67 / 3.93 / 3.72 | 4.99 / 6.32 / 7.23 | 201.0 / 201.0 / 201.0 |
| CDC | beta → beta | 2,000 | 5.26 / 5.45 / 5.38 | 14.21 / 14.22 / 13.99 | 2009.6 / 2009.6 / 2009.7 |
| CDC | beta → delta | 200 | 4.49 / 4.22 / 4.36 | 7.76 / 17.29 / 1687.44 | 201.0 / 201.0 / 201.0 |
| CDC | beta → delta | 2,000 | 6.72 / 8.22 / 5.94 | 331.19 / 288.79 / 175.39 | 2009.6 / 2009.5 / 2009.6 |
| CDC | beta → mariogk-dev | 200 | 4.77 / 4.76 / 5.08 | 9.18 / 11.06 / 34.78 | 201.0 / 201.0 / 201.0 |
| CDC | beta → mariogk-dev | 2,000 | 9.50 / 9.45 / 9.75 | 118.31 / 85.50 / 177.61 | 2009.5 / 2009.5 / 2009.6 |

All 396,000 final-run rows eventually applied; no replication error was returned. **One target was not sustained:** Sync beta→delta, offered 2,000 rows/s, repeat 3, achieved only **1,549.2 rows/s** over 12.91 s. Its p99=627.10 ms is an overloaded-target observation, not a successful p99 measurement at a sustained 2,000 rows/s. The other 35 runs delivered their target batch rate. Do not replace that failed repeat with a favorable one.

CDC's same-host medians were 3.7–5.5 ms versus Sync's 25.7–26.9 ms, but correctness and production complexity decide the recommendation. Cross-host outliers remain: CDC beta→delta at 200 rows/s had p99=1,687.44 ms in one repeat; Sync beta→delta had p99 up to 627.10 ms at the 2,000-row target. Instrumentation found slow shipping/apply operations as well as occasional slow probe queries; removing the query-completion timestamp did not remove these stalls. Their precise runtime/host/transport cause remains unresolved. These shared-host results do not support a sub-200 ms p99 claim.

For separate single-row transactions, a 2 s smoke using the CLI authority attempted 200/s but achieved **82.18 / 85.09 / 84.42 commits/s** with same-host / delta / mariogk-dev replicas respectively. These are three topology-specific pilot observations, not three repeats of one topology. They expose the serialized request-loop limit and justify the explicit batching caveat; they do not establish unbatched capacity for either candidate.


## Upstream issue reproduction

All three reports were open when inspected. Each listed outcome reproduced in **3/3 fresh runs on 0.8.2 and 3/3 on 0.8.3**.

| Issue | Reproducer and measured result | Consequence for this model |
|---|---|---|
| [#8725](https://github.com/tursodatabase/turso/issues/8725) | Fresh MVCC database; home creates table and row after server startup, without checkpoint; fresh file-backed client connects and pulls. Home has `(1,'tail')`; pull returns false; replica reports `no such table: t`. | MVCC sync is excluded. Tested the fresh-bootstrap subcase; did not exhaustively reproduce every LML2 migration, OPFS or WAL-to-MVCC upgrade variant in the issue. Native Node result, not browser-WASM qualification. |
| [#10178](https://github.com/tursodatabase/turso/issues/10178) | Exact upstream local table-rebuild sequence. First push reports `near ")": syntax error`; second push succeeds; home table is missing; pull removes it locally too. | Push is excluded, including all application, migration and background writes on replicas. A client library's availability of Push is not permission to call it. |
| [#10147](https://github.com/tursodatabase/turso/issues/10147) | Bootstrap identical trigger on home/replica; local INSERT produces one local audit row; push yields two home audit rows; pull yields two locally. | Push is excluded. A naive own CDC shipper is also exposed when it replays captured trigger effects through active target triggers. |

Supplemental 0.8.2 .NET checks, each repeated three times:

| Check | Sync WAL pulls | Own CDC image replay |
|---|---|---|
| CREATE INDEX before any ALTER | Index present, 3/3 | Index present, 3/3 |
| Home-triggered INSERT, one audit row | One matching audit row; trigger schema present, 3/3 | One matching audit row **but trigger definition absent**, 3/3: CREATE TRIGGER was not present in the captured schema changes |
| Install the same missing trigger on CDC target, then ship a second home INSERT | Not needed: page pulls preserve schema and data together | Home has 2 audit rows; replica has **3**, including duplicate `inserted 2`, 3/3 |
| Table rebuild executed transactionally at home, then pull | Same row `(1,'one',NULL)` on both, 3/3 | Already blocked on ALTER; no claim |
| Enable CDC on home writer, write a new row, then page-pull | Same 2 rows on both; source CDC has 2 records, 3/3 | Not a page-pull protocol |

This distinguishes the desired home-write/page-pull direction from the broken push direction. It also shows that omitting triggers on CDC replicas can preserve a data sample while silently losing schema, and that simply restoring those triggers creates duplicate effects. A production image applier needs an explicit policy for schema preservation, suppressed/indirect trigger effects and FK actions. The local CDC coexistence check did not perform a Tigris upload or retention trimming.


## Existing OCI inter-region RTT

Three repeats per directed pair. Each repeat attempted five ICMP echo requests and ten TCP connects to the other region's existing public IPv4 HTTPS port. Public regional DNS resolved to gru `163.176.124.12`, sjc `163.192.54.17`, fra `130.162.238.198`. No TLS or application request was needed. All 180 TCP connects succeeded. All 90 ICMP probes received no replies; ICMP RTT is **unavailable**, not zero, and the observed loss does not distinguish filtering from other causes. No firewall change was attempted.

| Origin → target | TCP median, R1 / R2 / R3 (ms) | TCP max, R1 / R2 / R3 (ms) | ICMP |
|---|---|---|---|
| gru → sjc | 168.74 / 168.53 / 168.35 | 168.96 / 168.78 / 168.85 | 0/15 replies |
| gru → fra | 180.92 / 184.39 / 181.07 | 187.77 / 188.05 / 187.90 | 0/15 replies |
| sjc → gru | 168.28 / 168.40 / 168.54 | 168.74 / 168.74 / 168.98 | 0/15 replies |
| sjc → fra | 143.94 / 137.26 / 137.83 | 144.89 / 144.98 / 145.46 | 0/15 replies |
| fra → gru | 181.00 / 181.21 / 181.12 | 188.45 / 187.97 / 189.37 | 0/15 replies |
| fra → sjc | 137.67 / 143.96 / 137.10 | 144.92 / 145.40 / 144.82 | 0/15 replies |


TCP connect duration estimates handshake RTT and includes local scheduling; it is not an application SQL latency percentile. Each repeat has only ten samples, so the table reports medians and maxima rather than presenting its maximum as a statistically meaningful p99. Results are over public IPv4, not a measured NetBird private replication path.

For a FRA client using a FRA edge and a GRU home, a reused forwarding connection adds approximately one FRA↔GRU round trip: repeat medians **181.00 / 181.21 / 181.12 ms**. A one-RPC transaction therefore costs roughly **181 ms + home commit/queue time + client↔FRA-edge time**. As an illustrative estimate only, adding the dev authority's roughly 8 ms median batched commit/RPC service time gives about **189 ms plus client access and queueing**. OCI commit performance was not benchmarked. Cold TCP/TLS adds connection round trips. Separate BEGIN, statement and COMMIT forwarding RPCs can each add about 181 ms, so batch a complete transaction or pin its session to the home.

A read-replica pull also needs a request/response exchange; a measured 181 ms network RTT leaves very little margin for a 200 ms apply-lag target. LAN medians cannot validate that target. A write response should carry a commit/revision token; a subsequent replica read must wait for that token, route to home or explicitly permit staleness. Do not acknowledge a forwarded write merely because a local queue accepted it.

## Production gaps and effort

Estimates are engineer-days, not measurements or promises. They assume reuse of existing TerraScale routing, identity, Vault, backup encryption and deployment conventions, and no new capacity. Each row is a bounded deliverable; totals include the replication portions of forwarding and HA, but not the SQL-only engine rewrite, full PostgreSQL protocol implementation or commercial support from upstream.

| Deliverable | Turso Sync | Own CDC, single writer |
|---|---|---|
| Home routing and transaction ownership across HTTP SQL/Hrana/psql | 4–7 d: pin sessions/transactions to one home, reject replica writes, forward cancellation/errors, revision-aware reads | 4–7 d: same requirements |
| Production authority / ordered transport | 5–8 d: harden or derive the CLI server, remove serial accept-loop bottleneck without unsafe concurrent writers, quotas/backpressure, lifecycle API | 5–8 d: durable ordered stream, framing, idempotent resume/cursor, lineage, size limits and checksums; one writer |
| SQL semantics and DDL | 2–4 d: qualify home DDL/triggers/FKs through page pulls; assert WAL mode and deny Push/MVCC transitions | 8–14 d: transactional ordered DDL envelope or snapshot cutover, schema identity changes, trigger suppression/indirect effects, FK actions, constraints and large transactions |
| Auth and TLS | 3–4 d: CLI has no production auth/TLS; private authority behind verified TLS/mTLS and per-database authorization. .NET token support alone does not authenticate the CLI | 3–4 d: authenticate replication peers and home SQL callers, isolate tenant/database scope, replay/epoch protection and verified TLS |
| Encryption at rest on replicas | 4–7 d if per-database encryption is required: Sync options expose **remote** encryption, not local replica encryption; extend/qualify native+binding path or document verified volume-level coverage | 2–4 d: reuse local Turso encrypted connections, encrypt spool/after-images and cursor snapshots, qualify rebuild/rekey. No keys were created or installed in this spike |
| Bounded retention and bootstrap | 5–8 d: CLI disables automatic WAL checkpointing; define bounded page history, snapshot/rebootstrap on a missing revision, crash-safe generation install and disk/backlog limits | 5–8 d: snapshot plus exact source commit cursor; retain complete transaction groups, preserve final CDC row across reopen, detect holes/lineage mismatch and rebootstrap |
| HA and failover | 7–12 d: single fenced home, durable epoch/lease, promotion/rebootstrap protocol, no concurrent old/new authorities; determine explicit RPO/RTO | 7–12 d: same fencing and durability requirements; ordered CDC alone is not leader election or HA |
| Tigris backup coexistence | 4–6 d: enable CDC on the authority's writer for backup alongside page sync, provide a safe in-owner snapshot/CDC export, independent WAL/CDC retention and restores | 5–8 d: one coordinated retention floor over every replica's durable ack and backup's durable position; snapshot/generation restore and offline-peer eviction policy |
| Hardening, deployment and evidence | 5–8 d: ARM qualification, TLS/tenant denial tests, fault injection, multi-database load, tail-lag diagnosis, disk budgets, alerts, restore drills and measured cross-region SLO | 5–8 d: equivalent evidence plus CDC schema/version compatibility and repeated replay/DDL fault tests |
| Arithmetic total | **39–64 d; budget 40–65 d** | **44–73 d; budget 45–75 d** |

Important implementation constraints:

- Candidate 1 needs a production authority, not just an exposed CLI subprocess. `cli/sync_server.rs` v0.8.2 accepts one connection at a time and sleeps 10 ms when accept would block; the measured single-row smoke sustained only 82–85 commits/s. Both SQL execution and pulling use that authority. Hardening must preserve the single-writer rule while servicing network I/O efficiently.
- Do not open the authority's live file for a second process to write or trim CDC. TerraScale's existing runtime relies on one writer per file. Keeping a .NET writer beside `tursodb` is not the measured topology; adapt backup/maintenance to the authority's owner or a safe remote export. A new server implementation must pass the same protocol and crash proofs.
- Current `TursoChangeTap.Place` explicitly returns false on schema updates (`ALTER`); its existing safe response is a backup generation/snapshot restart. It is not an arbitrary-SQL CDC replication implementation waiting only for transport. `TursoChangeGroupSource` is tailored to current document/state groups and cannot simply replace its merge with SQL execution.
- Existing continuous backup already coordinates `BackupAnchor`, peer acknowledgements and trimming. Preserve those safety principles, not the document-specific state protocol. With own CDC, no consumer may independently delete rows needed by another. Keep the latest row because CDC IDs can restart after empty-table reopen. With Sync, WAL/page revisions and backup CDC IDs are different namespaces and need different retention bookkeeping. In three completed same-host 2,000-row/s runs, the authority retained exactly 1,808,712 bytes of WAL for 20,000 sample rows in each repeat (main file 4,096 bytes); this short workload already demonstrates why history must be bounded.
- Tigris remains the permitted object store. No bucket, key, backup upload or restore against real Tigris occurred here. A simultaneous local CDC/page-pull check is not a remote backup/retention qualification.
- Async read replicas do not give lossless failover of every acknowledged home commit. Production must specify durability acknowledgements and the promotion condition. Zero-RPO writes may require waiting for a remote durable ack, which adds a WAN exchange (roughly 168 ms GRU↔SJC in these probes) beyond the forwarding round trip. Automatic lossless failover is not justified by these tests. Refuse unsafe promotion until fencing and the committed prefix are proven.

## Recommended next implementation boundary

Start with a WAL-only authority and a read-only official .NET replica, behind the existing SQL gateway. All write paths, migrations, triggers and transactions execute at home. Explicitly prohibit Push and mode conversion; keep a commit token for read-after-write routing. Preserve the existing deployment and approval holds.

Recommendation is conditional on closing these measured and identified gaps; neither bare candidate is production-ready today. The first production milestone should close authority authentication/TLS, snapshot/history bounds, encrypted replica storage and safe Tigris exports before serving customer traffic. Then prove fenced recovery/promotion and measure realistic unbatched transactions and ARM cross-region lag. If hardening the page authority cannot provide bounded history and safe snapshots within the authority and retention estimates, reassess the protocol choice; do not conceal that work by switching to unsupported MVCC sync. Own CDC remains an alternative only after its DDL and indirect-write semantics are designed and tested.

## Reproducibility and cleanup

The report embeds the final probe sources and machine-readable observations below so removing scratch does not remove the evidence or make reproduction depend on a leftover worktree. Setup-only pilot mistakes were corrected in scratch and excluded. The final lag pass and final prefetched recovery pass are identified explicitly in the raw data. No provider errors occurred.

To reproduce in a fresh copy of the exact scratch directory: export the vendored driver and vendor verification scripts from the pinned commit with `git show` (not the live worktree); preserve executable bits on shell helpers; run the exported native download script; download/checksum the matching 0.8.2 and 0.8.3 Linux-x64 CLI release archives; place the embedded source files at their shown relative paths; build `Probe.csproj -c Release` on the selected dev host; copy its `bin` directory to the same scratch path on delta and mariogk-dev. `Record.cs` is the unchanged `SqliteRecord` class extracted from the pinned `TursoChangeTap.cs`, with `using System.Buffers.Binary; using System.Text;` prepended.

On beta, run `python3 run.py correct`, `python3 run.py bench`, `python3 recovery.py`, and `python3 supplement.py` sequentially. Each writes fresh named databases; reruns require fresh names or a fresh exact scratch directory. For issue reproducers install `sync083@npm:@tursodatabase/sync@0.8.3` in the scratch root; under `npm082`, install exact `@tursodatabase/sync@0.8.2`, `@tursodatabase/sync-common@0.8.2`, `@tursodatabase/database-common@0.8.2`. The final 0.8.2 issue matrix explicitly pins both common packages to 0.8.2, rather than accepting npm's initial shared 0.8.3 dependency resolution. Invoke `node repro.mjs VERSION ISSUE REPEAT` for both versions, all three issue numbers, repeats 1–3. The RTT source is a read-only stdin probe, not a script to deploy to serving machines.

Cleanup: completed and verified on delta, beta and mariogk-dev at 2026-10-29T11:58:24+00:00. Removed only the exact `/home/mariogk/spikes/sql-repl-20261029` directory on each host, without deletion globs. Probe database processes and sync servers had exited before removal. Final measurements and source text are preserved in this report. No PRs or production changes were made.


<details>
<summary>Machine-readable final measurements and correctness evidence</summary>

```json
{"correctness":[{"kind":"cdc","repeat":1,"initial":{"sha256":"8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd","counts":{"items":100000,"parent":100}},"constraints":{"unique":"UNIQUE constraint failed: items.name","fk":"FOREIGN KEY constraint failed"},"dml_home":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_replica":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_match":true,"ddl_error":"REFUSE schema mutation: DDL envelope or snapshot required"},{"kind":"cdc","repeat":2,"initial":{"sha256":"8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd","counts":{"items":100000,"parent":100}},"constraints":{"unique":"UNIQUE constraint failed: items.name","fk":"FOREIGN KEY constraint failed"},"dml_home":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_replica":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_match":true,"ddl_error":"REFUSE schema mutation: DDL envelope or snapshot required"},{"kind":"cdc","repeat":3,"initial":{"sha256":"8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd","counts":{"items":100000,"parent":100}},"constraints":{"unique":"UNIQUE constraint failed: items.name","fk":"FOREIGN KEY constraint failed"},"dml_home":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_replica":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_match":true,"ddl_error":"REFUSE schema mutation: DDL envelope or snapshot required"},{"kind":"sync","repeat":1,"initial":{"sha256":"8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd","counts":{"items":100000,"parent":100}},"constraints":{"unique":"{'type': 'error', 'error': {'message': 'UNIQUE constraint failed: items.name', 'code': 'EXECUTE_ERROR'}}","fk":"{'type': 'error', 'error': {'message': 'FOREIGN KEY constraint failed', 'code': 'EXECUTE_ERROR'}}"},"dml_home":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_replica":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_match":true,"ddl_replica":{"sha256":"565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d","counts":{"items":95001,"parent":101}},"ddl_home":{"sha256":"565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d","counts":{"items":95001,"parent":101}},"ddl_match":true,"index":[["idx_items_val"]]},{"kind":"sync","repeat":2,"initial":{"sha256":"8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd","counts":{"items":100000,"parent":100}},"constraints":{"unique":"{'type': 'error', 'error': {'message': 'UNIQUE constraint failed: items.name', 'code': 'EXECUTE_ERROR'}}","fk":"{'type': 'error', 'error': {'message': 'FOREIGN KEY constraint failed', 'code': 'EXECUTE_ERROR'}}"},"dml_home":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_replica":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_match":true,"ddl_replica":{"sha256":"565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d","counts":{"items":95001,"parent":101}},"ddl_home":{"sha256":"565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d","counts":{"items":95001,"parent":101}},"ddl_match":true,"index":[["idx_items_val"]]},{"kind":"sync","repeat":3,"initial":{"sha256":"8de5f8275bb840a72d628a03a8560b4f649bb70b24037b8bdbd455f72876d1bd","counts":{"items":100000,"parent":100}},"constraints":{"unique":"{'type': 'error', 'error': {'message': 'UNIQUE constraint failed: items.name', 'code': 'EXECUTE_ERROR'}}","fk":"{'type': 'error', 'error': {'message': 'FOREIGN KEY constraint failed', 'code': 'EXECUTE_ERROR'}}"},"dml_home":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_replica":{"sha256":"9a3647972d8daad1f8f24937a042d005ca702f39fb2b12b64a7fc362789c4c22","counts":{"items":95001,"parent":101}},"dml_match":true,"ddl_replica":{"sha256":"565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d","counts":{"items":95001,"parent":101}},"ddl_home":{"sha256":"565181092a0909bfa09be98d7d44421320cf31239490cfcefb85898d9431077d","counts":{"items":95001,"parent":101}},"ddl_match":true,"index":[["idx_items_val"]]}],"lag":[{"kind":"cdc","host":"beta","rate":200,"repeat":1,"clock":{"offset_ticks":-4.0,"half_rtt_ms":0.0064,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.952092699008062,"achieved_writes_s":200.9627583351733,"batch":10,"p50_ms":3.6736,"p99_ms":4.992,"max_ms":14.8352,"min_ms":3.0592,"commit_p50_ms":1.8204109801445156,"commit_p99_ms":2.593726007035002,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":0.0,"half_rtt_ms":0.0055,"samples":21}},{"kind":"cdc","host":"beta","rate":200,"repeat":2,"clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0092,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.952224387001479,"achieved_writes_s":200.96009919271756,"batch":10,"p50_ms":3.9296,"p99_ms":6.3232,"max_ms":12.2112,"min_ms":3.328,"commit_p50_ms":2.0046049903612584,"commit_p99_ms":2.7538159920368344,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":4.0,"half_rtt_ms":0.0083,"samples":21}},{"kind":"cdc","host":"beta","rate":200,"repeat":3,"clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0064,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.951777203998063,"achieved_writes_s":200.96912933264954,"batch":10,"p50_ms":3.7248,"p99_ms":7.232,"max_ms":12.096,"min_ms":3.2512,"commit_p50_ms":1.8851320201065391,"commit_p99_ms":2.9399940103758126,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-16.0,"half_rtt_ms":0.0088,"samples":21}},{"kind":"cdc","host":"beta","rate":2000,"repeat":1,"clock":{"offset_ticks":-4.0,"half_rtt_ms":0.0064,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.952015893999487,"achieved_writes_s":2009.64309271842,"batch":100,"p50_ms":5.2608,"p99_ms":14.208,"max_ms":61.2352,"min_ms":4.2368,"commit_p50_ms":2.1188590035308152,"commit_p99_ms":5.1756300090346485,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":0.0,"half_rtt_ms":0.0054,"samples":21}},{"kind":"cdc","host":"beta","rate":2000,"repeat":2,"clock":{"offset_ticks":-4.0,"half_rtt_ms":0.0065,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.952316270006122,"achieved_writes_s":2009.582438640457,"batch":100,"p50_ms":5.4528,"p99_ms":14.2208,"max_ms":61.3504,"min_ms":4.5056,"commit_p50_ms":2.2034769935999066,"commit_p99_ms":5.665345001034439,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0055,"samples":21}},{"kind":"cdc","host":"beta","rate":2000,"repeat":3,"clock":{"offset_ticks":-4.0,"half_rtt_ms":0.0065,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.95196795501397,"achieved_writes_s":2009.6527732410614,"batch":100,"p50_ms":5.376,"p99_ms":13.9904,"max_ms":59.2,"min_ms":4.5056,"commit_p50_ms":2.121312980307266,"commit_p99_ms":5.196624988457188,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":0.0,"half_rtt_ms":0.0053,"samples":21}},{"kind":"cdc","host":"delta","rate":200,"repeat":1,"clock":{"offset_ticks":-16746.0,"half_rtt_ms":0.1746,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.952283827005886,"achieved_writes_s":200.95889895874222,"batch":10,"p50_ms":4.4928,"p99_ms":7.7568,"max_ms":19.2384,"min_ms":3.0464,"commit_p50_ms":1.8093750113621354,"commit_p99_ms":2.4673109874129295,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-14602.0,"half_rtt_ms":0.1838,"samples":21}},{"kind":"cdc","host":"delta","rate":200,"repeat":2,"clock":{"offset_ticks":-14610.0,"half_rtt_ms":0.1042,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.951839437999297,"achieved_writes_s":200.96787256869942,"batch":10,"p50_ms":4.224,"p99_ms":17.2928,"max_ms":33.9072,"min_ms":3.0976,"commit_p50_ms":2.0029229926876724,"commit_p99_ms":2.5598829961381853,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-12492.0,"half_rtt_ms":0.1625,"samples":21}},{"kind":"cdc","host":"delta","rate":200,"repeat":3,"clock":{"offset_ticks":-12388.0,"half_rtt_ms":0.1019,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.951701925019734,"achieved_writes_s":200.97064955008025,"batch":10,"p50_ms":4.3648,"p99_ms":1687.4368,"max_ms":1737.4336,"min_ms":3.1488,"commit_p50_ms":1.9437049922998995,"commit_p99_ms":2.3717459989711642,"errors":[],"slow_operations":[{"ship_ms":1736.35,"query_ms":1.586,"through":310}],"measurement":"apply_completion","end_clock":{"offset_ticks":-10310.0,"half_rtt_ms":0.1076,"samples":21}},{"kind":"cdc","host":"delta","rate":2000,"repeat":1,"clock":{"offset_ticks":-10342.0,"half_rtt_ms":0.1142,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.952015744987875,"achieved_writes_s":2009.6431228088222,"batch":100,"p50_ms":6.72,"p99_ms":331.1872,"max_ms":381.2096,"min_ms":4.1088,"commit_p50_ms":2.079967991448939,"commit_p99_ms":5.901016003917903,"errors":[],"slow_operations":[{"ship_ms":380.282,"query_ms":2.058,"through":4700},{"ship_ms":0.278,"query_ms":140.747,"through":9800},{"ship_ms":229.344,"query_ms":1.737,"through":11700},{"ship_ms":138.137,"query_ms":1.44,"through":12600}],"measurement":"apply_completion","end_clock":{"offset_ticks":-8250.0,"half_rtt_ms":0.1033,"samples":21}},{"kind":"cdc","host":"delta","rate":2000,"repeat":2,"clock":{"offset_ticks":-8098.0,"half_rtt_ms":0.1146,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.95267564500682,"achieved_writes_s":2009.5098758728104,"batch":100,"p50_ms":8.2176,"p99_ms":288.7936,"max_ms":337.1136,"min_ms":4.4288,"commit_p50_ms":2.510624995920807,"commit_p99_ms":5.881601013243198,"errors":[],"slow_operations":[{"ship_ms":315.22,"query_ms":9.142,"through":5700},{"ship_ms":158.111,"query_ms":55.111,"through":7100},{"ship_ms":154.797,"query_ms":5.404,"through":7500},{"ship_ms":137.411,"query_ms":1.731,"through":8300},{"ship_ms":111.919,"query_ms":4.745,"through":8700},{"ship_ms":153.201,"query_ms":1.382,"through":9000},{"ship_ms":277.288,"query_ms":1.897,"through":9500},{"ship_ms":0.225,"query_ms":122.654,"through":10200},{"ship_ms":0.335,"query_ms":119.03,"through":12300},{"ship_ms":184.67,"query_ms":5.341,"through":12800}],"measurement":"apply_completion","end_clock":{"offset_ticks":-6074.0,"half_rtt_ms":0.1344,"samples":21}},{"kind":"cdc","host":"delta","rate":2000,"repeat":3,"clock":{"offset_ticks":-6024.0,"half_rtt_ms":0.1197,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.952338503993815,"achieved_writes_s":2009.577949139704,"batch":100,"p50_ms":5.9392,"p99_ms":175.3856,"max_ms":225.3952,"min_ms":4.288,"commit_p50_ms":2.164054021704942,"commit_p99_ms":6.366218003677204,"errors":[],"slow_operations":[{"ship_ms":225.95,"query_ms":2.186,"through":10600}],"measurement":"apply_completion","end_clock":{"offset_ticks":-4096.0,"half_rtt_ms":0.1217,"samples":21}},{"kind":"cdc","host":"mariogk-dev","rate":200,"repeat":1,"clock":{"offset_ticks":4134.0,"half_rtt_ms":0.2313,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.952142808004282,"achieved_writes_s":200.96174648854972,"batch":10,"p50_ms":4.7744,"p99_ms":9.1776,"max_ms":19.5072,"min_ms":3.776,"commit_p50_ms":1.9831200188491493,"commit_p99_ms":2.5477650051470846,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":5986.0,"half_rtt_ms":0.2169,"samples":21}},{"kind":"cdc","host":"mariogk-dev","rate":200,"repeat":2,"clock":{"offset_ticks":6160.0,"half_rtt_ms":0.2365,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.952103068993893,"achieved_writes_s":200.96254893411086,"batch":10,"p50_ms":4.7616,"p99_ms":11.0592,"max_ms":19.2256,"min_ms":4.0192,"commit_p50_ms":2.076233009574935,"commit_p99_ms":4.759939998621121,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":8128.0,"half_rtt_ms":0.2633,"samples":21}},{"kind":"cdc","host":"mariogk-dev","rate":200,"repeat":3,"clock":{"offset_ticks":8440.0,"half_rtt_ms":0.2725,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.951848938013427,"achieved_writes_s":200.96768072518964,"batch":10,"p50_ms":5.0816,"p99_ms":34.7776,"max_ms":84.7872,"min_ms":4.0576,"commit_p50_ms":1.8175340082962066,"commit_p99_ms":2.4836669908836484,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":10236.0,"half_rtt_ms":0.258,"samples":21}},{"kind":"cdc","host":"mariogk-dev","rate":2000,"repeat":1,"clock":{"offset_ticks":10240.0,"half_rtt_ms":0.2842,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.95279722198029,"achieved_writes_s":2009.4853289918265,"batch":100,"p50_ms":9.4976,"p99_ms":118.3104,"max_ms":168.3456,"min_ms":7.6032,"commit_p50_ms":2.4783080152701586,"commit_p99_ms":6.0179519932717085,"errors":[],"slow_operations":[{"ship_ms":169.14,"query_ms":4.392,"through":2800}],"measurement":"apply_completion","end_clock":{"offset_ticks":12180.0,"half_rtt_ms":0.2839,"samples":21}},{"kind":"cdc","host":"mariogk-dev","rate":2000,"repeat":2,"clock":{"offset_ticks":12246.0,"half_rtt_ms":0.2867,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.952578003983945,"achieved_writes_s":2009.529590423119,"batch":100,"p50_ms":9.4464,"p99_ms":85.504,"max_ms":135.5264,"min_ms":8.064,"commit_p50_ms":2.3009200231172144,"commit_p99_ms":6.882675981614739,"errors":[],"slow_operations":[{"ship_ms":135.045,"query_ms":1.834,"through":4000}],"measurement":"apply_completion","end_clock":{"offset_ticks":14144.0,"half_rtt_ms":0.2518,"samples":21}},{"kind":"cdc","host":"mariogk-dev","rate":2000,"repeat":3,"clock":{"offset_ticks":14276.0,"half_rtt_ms":0.28,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.95213717300794,"achieved_writes_s":2009.6186027503463,"batch":100,"p50_ms":9.7536,"p99_ms":177.6128,"max_ms":227.6224,"min_ms":7.9488,"commit_p50_ms":2.0516799995675683,"commit_p99_ms":5.876904004253447,"errors":[],"slow_operations":[{"ship_ms":167.136,"query_ms":3.317,"through":2800},{"ship_ms":226.751,"query_ms":2.535,"through":7000}],"measurement":"apply_completion","end_clock":{"offset_ticks":15872.0,"half_rtt_ms":0.2637,"samples":21}},{"kind":"sync","host":"beta","rate":200,"repeat":1,"clock":{"offset_ticks":-4.0,"half_rtt_ms":0.0097,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.957249426981434,"achieved_writes_s":200.85868237673594,"batch":10,"p50_ms":25.6896,"p99_ms":32.1408,"max_ms":32.3456,"min_ms":16.5888,"commit_p50_ms":8.70150700211525,"commit_p99_ms":12.992678006412461,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-10.0,"half_rtt_ms":0.0076,"samples":21}},{"kind":"sync","host":"beta","rate":200,"repeat":2,"clock":{"offset_ticks":0.0,"half_rtt_ms":0.0065,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.958756139996694,"achieved_writes_s":200.82829340177656,"batch":10,"p50_ms":25.9968,"p99_ms":32.832,"max_ms":33.3952,"min_ms":18.112,"commit_p50_ms":8.116687007714063,"commit_p99_ms":12.494485010392964,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":0.0,"half_rtt_ms":0.0057,"samples":21}},{"kind":"sync","host":"beta","rate":200,"repeat":3,"clock":{"offset_ticks":-4.0,"half_rtt_ms":0.0066,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.959165050997399,"achieved_writes_s":200.8200476404096,"batch":10,"p50_ms":26.944,"p99_ms":35.6608,"max_ms":37.7088,"min_ms":19.8144,"commit_p50_ms":8.611282974015921,"commit_p99_ms":13.189535005949438,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":0.0,"half_rtt_ms":0.0118,"samples":21}},{"kind":"sync","host":"beta","rate":2000,"repeat":1,"clock":{"offset_ticks":-12.0,"half_rtt_ms":0.0097,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.955637734004995,"achieved_writes_s":2008.9119888007735,"batch":100,"p50_ms":26.3936,"p99_ms":32.8064,"max_ms":32.8576,"min_ms":18.944,"commit_p50_ms":8.417047007242218,"commit_p99_ms":12.62695700279437,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0055,"samples":21}},{"kind":"sync","host":"beta","rate":2000,"repeat":2,"clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0078,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.960072151996428,"achieved_writes_s":2008.0175820805814,"batch":100,"p50_ms":25.9328,"p99_ms":33.1136,"max_ms":33.2544,"min_ms":18.24,"commit_p50_ms":8.291254984214902,"commit_p99_ms":12.548324011731893,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":8.0,"half_rtt_ms":0.0075,"samples":21}},{"kind":"sync","host":"beta","rate":2000,"repeat":3,"clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0067,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.956596251984593,"achieved_writes_s":2008.7185915581856,"batch":100,"p50_ms":26.0224,"p99_ms":34.3168,"max_ms":38.6176,"min_ms":19.7248,"commit_p50_ms":8.35483500850387,"commit_p99_ms":12.750541005516425,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":-2.0,"half_rtt_ms":0.0055,"samples":21}},{"kind":"sync","host":"delta","rate":200,"repeat":1,"clock":{"offset_ticks":18358.0,"half_rtt_ms":0.103,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.959699675993761,"achieved_writes_s":200.80926785580445,"batch":10,"p50_ms":24.1664,"p99_ms":32.6144,"max_ms":53.3504,"min_ms":13.888,"commit_p50_ms":7.440721994498745,"commit_p99_ms":15.431056002853438,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":20004.0,"half_rtt_ms":0.1549,"samples":21}},{"kind":"sync","host":"delta","rate":200,"repeat":2,"clock":{"offset_ticks":20076.0,"half_rtt_ms":0.1009,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.954404785996303,"achieved_writes_s":200.91608117178114,"batch":10,"p50_ms":31.872,"p99_ms":148.4032,"max_ms":198.4512,"min_ms":9.5872,"commit_p50_ms":7.639072020538151,"commit_p99_ms":12.756157986586913,"errors":[],"slow_operations":[{"ship_ms":108.337,"query_ms":2.105,"through":210},{"ship_ms":179.685,"query_ms":1.814,"through":930}],"measurement":"apply_completion","end_clock":{"offset_ticks":21584.0,"half_rtt_ms":0.1744,"samples":21}},{"kind":"sync","host":"delta","rate":200,"repeat":3,"clock":{"offset_ticks":21744.0,"half_rtt_ms":0.1108,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.9542389579874,"achieved_writes_s":200.91942823968236,"batch":10,"p50_ms":22.3872,"p99_ms":205.1712,"max_ms":255.1808,"min_ms":14.0928,"commit_p50_ms":7.592557987663895,"commit_p99_ms":13.517043989850208,"errors":[],"slow_operations":[{"ship_ms":105.191,"query_ms":1.248,"through":1800},{"ship_ms":254.377,"query_ms":9.347,"through":1890},{"ship_ms":127.81,"query_ms":1.162,"through":1930}],"measurement":"apply_completion","end_clock":{"offset_ticks":23306.0,"half_rtt_ms":0.1142,"samples":21}},{"kind":"sync","host":"delta","rate":2000,"repeat":1,"clock":{"offset_ticks":23520.0,"half_rtt_ms":0.2109,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.959874370018952,"achieved_writes_s":2008.0574570502283,"batch":100,"p50_ms":25.2416,"p99_ms":113.088,"max_ms":139.136,"min_ms":11.2,"commit_p50_ms":7.76947897975333,"commit_p99_ms":12.679564009886235,"errors":[],"slow_operations":[{"ship_ms":132.994,"query_ms":1.264,"through":9400}],"measurement":"apply_completion","end_clock":{"offset_ticks":25114.0,"half_rtt_ms":0.1082,"samples":21}},{"kind":"sync","host":"delta","rate":2000,"repeat":2,"clock":{"offset_ticks":25116.0,"half_rtt_ms":0.1129,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.953995153977303,"achieved_writes_s":2009.2434937552316,"batch":100,"p50_ms":22.5792,"p99_ms":36.0064,"max_ms":39.04,"min_ms":14.7968,"commit_p50_ms":7.7554029994644225,"commit_p99_ms":12.757099000737071,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":26640.0,"half_rtt_ms":0.1087,"samples":21}},{"kind":"sync","host":"delta","rate":2000,"repeat":3,"clock":{"offset_ticks":26792.0,"half_rtt_ms":0.0986,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":12.909901292994618,"achieved_writes_s":1549.1985218239217,"batch":100,"p50_ms":45.3632,"p99_ms":627.0976,"max_ms":1033.2544,"min_ms":10.6112,"commit_p50_ms":7.896204973803833,"commit_p99_ms":577.2689900186379,"errors":[],"slow_operations":[{"ship_ms":103.745,"query_ms":2.657,"through":1300},{"ship_ms":303.057,"query_ms":1.202,"through":19300},{"ship_ms":218.336,"query_ms":1.301,"through":19400},{"ship_ms":580.166,"query_ms":1.443,"through":19500},{"ship_ms":482.662,"query_ms":1.701,"through":19600},{"ship_ms":229.999,"query_ms":1.533,"through":19700},{"ship_ms":477.711,"query_ms":1.432,"through":19800},{"ship_ms":997.921,"query_ms":1.446,"through":19900}],"measurement":"apply_completion","end_clock":{"offset_ticks":28700.0,"half_rtt_ms":0.1756,"samples":21}},{"kind":"sync","host":"mariogk-dev","rate":200,"repeat":1,"clock":{"offset_ticks":37098.0,"half_rtt_ms":0.2375,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.953421723999782,"achieved_writes_s":200.93592489682032,"batch":10,"p50_ms":28.2624,"p99_ms":54.9248,"max_ms":57.152,"min_ms":19.6224,"commit_p50_ms":7.673896005144343,"commit_p99_ms":15.23758700932376,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":38762.0,"half_rtt_ms":0.2249,"samples":21}},{"kind":"sync","host":"mariogk-dev","rate":200,"repeat":2,"clock":{"offset_ticks":38602.0,"half_rtt_ms":0.2114,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.95386485697236,"achieved_writes_s":200.9269794937054,"batch":10,"p50_ms":27.0976,"p99_ms":120.5248,"max_ms":147.5072,"min_ms":17.216,"commit_p50_ms":7.355656998697668,"commit_p99_ms":16.243997000856325,"errors":[],"slow_operations":[{"ship_ms":145.092,"query_ms":1.386,"through":980}],"measurement":"apply_completion","end_clock":{"offset_ticks":40146.0,"half_rtt_ms":0.2541,"samples":21}},{"kind":"sync","host":"mariogk-dev","rate":200,"repeat":3,"clock":{"offset_ticks":40566.0,"half_rtt_ms":0.2342,"samples":21},"writes":2000,"applied":2000,"samples":2000,"seconds":9.955689845024608,"achieved_writes_s":200.89014735623843,"batch":10,"p50_ms":31.488,"p99_ms":101.696,"max_ms":102.1952,"min_ms":21.4528,"commit_p50_ms":7.982581999385729,"commit_p99_ms":59.91572799393907,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":41756.0,"half_rtt_ms":0.2122,"samples":21}},{"kind":"sync","host":"mariogk-dev","rate":2000,"repeat":1,"clock":{"offset_ticks":41904.0,"half_rtt_ms":0.2687,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.961858624010347,"achieved_writes_s":2007.6574818875113,"batch":100,"p50_ms":27.7376,"p99_ms":58.9184,"max_ms":61.1968,"min_ms":16.7424,"commit_p50_ms":7.829540001694113,"commit_p99_ms":12.948418006999418,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":43182.0,"half_rtt_ms":0.2275,"samples":21}},{"kind":"sync","host":"mariogk-dev","rate":2000,"repeat":2,"clock":{"offset_ticks":43280.0,"half_rtt_ms":0.2636,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.959852558997227,"achieved_writes_s":2008.0618544832787,"batch":100,"p50_ms":28.2624,"p99_ms":80.0896,"max_ms":130.112,"min_ms":19.9808,"commit_p50_ms":7.53384199924767,"commit_p99_ms":12.767667009029537,"errors":[],"slow_operations":[{"ship_ms":125.157,"query_ms":1.305,"through":5000}],"measurement":"apply_completion","end_clock":{"offset_ticks":44762.0,"half_rtt_ms":0.2447,"samples":21}},{"kind":"sync","host":"mariogk-dev","rate":2000,"repeat":3,"clock":{"offset_ticks":44886.0,"half_rtt_ms":0.2542,"samples":21},"writes":20000,"applied":20000,"samples":20000,"seconds":9.953038511011982,"achieved_writes_s":2009.4366135398873,"batch":100,"p50_ms":27.008,"p99_ms":66.24,"max_ms":66.8544,"min_ms":19.2896,"commit_p50_ms":7.562888000393286,"commit_p99_ms":12.89402399561368,"errors":[],"slow_operations":[],"measurement":"apply_completion","end_clock":{"offset_ticks":46204.0,"half_rtt_ms":0.2441,"samples":21}}],"recovery":[{"kind":"cdc","repeat":1,"profile":"prefetched-apply","kill_in_operation":true,"killed_returncode":-9,"persisted_resume_cursor":[[1005]],"replica_resume_ms":402.78035498340614,"replica_home":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_after_restart":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_restart_match":true,"home_restart_home":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_replica":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_match":true,"malformed":"REFUSED: a record varint is truncated","malformed_atomic":true,"corruption":"REFUSED: {'startup_error': 'Turso.Raw.Public.TursoNativeException: file is not a database\\n   at Turso.Raw.Public.TursoBindings.ThrowException(TursoStatusCode status, IntPtr errorPtr, String messagePrefix) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 543\\n   at Turso.Raw.Public.TursoBindings.ThrowIfError(TursoStatusCode status, IntPtr errorPtr, String messagePrefix) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 530\\n   at Turso.Raw.Public.TursoBindings.NewOpenedDatabase(String path, String cipher, String hexkey) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 445\\n   at Turso.Ra"},{"kind":"cdc","repeat":2,"profile":"prefetched-apply","kill_in_operation":true,"killed_returncode":-9,"persisted_resume_cursor":[[2006]],"replica_resume_ms":319.0977100166492,"replica_home":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_after_restart":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_restart_match":true,"home_restart_home":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_replica":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_match":true,"malformed":"REFUSED: a record varint is truncated","malformed_atomic":true,"corruption":"REFUSED: {'startup_error': 'Turso.Raw.Public.TursoNativeException: file is not a database\\n   at Turso.Raw.Public.TursoBindings.ThrowException(TursoStatusCode status, IntPtr errorPtr, String messagePrefix) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 543\\n   at Turso.Raw.Public.TursoBindings.ThrowIfError(TursoStatusCode status, IntPtr errorPtr, String messagePrefix) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 530\\n   at Turso.Raw.Public.TursoBindings.NewOpenedDatabase(String path, String cipher, String hexkey) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 445\\n   at Turso.Ra"},{"kind":"cdc","repeat":3,"profile":"prefetched-apply","kill_in_operation":true,"killed_returncode":-9,"persisted_resume_cursor":[[2006]],"replica_resume_ms":327.7553520165384,"replica_home":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_after_restart":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_restart_match":true,"home_restart_home":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_replica":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_match":true,"malformed":"REFUSED: a record varint is truncated","malformed_atomic":true,"corruption":"REFUSED: {'startup_error': 'Turso.Raw.Public.TursoNativeException: file is not a database\\n   at Turso.Raw.Public.TursoBindings.ThrowException(TursoStatusCode status, IntPtr errorPtr, String messagePrefix) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 543\\n   at Turso.Raw.Public.TursoBindings.ThrowIfError(TursoStatusCode status, IntPtr errorPtr, String messagePrefix) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 530\\n   at Turso.Raw.Public.TursoBindings.NewOpenedDatabase(String path, String cipher, String hexkey) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoBindings.cs:line 445\\n   at Turso.Ra"},{"kind":"sync","repeat":1,"profile":"prefetched-apply","kill_in_operation":true,"killed_returncode":-9,"replica_resume_ms":65.55495801148936,"replica_home":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_after_restart":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_restart_match":true,"home_restart_home":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_replica":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_match":true,"corruption":"REFUSED: {'startup_error': 'Turso.TursoSyncException: Turso sync Open failed: sync engine operation failed: database sync engine error: unable to open database file: file is not a database\\n ---> Turso.Raw.Public.TursoSyncNativeException: sync engine operation failed: database sync engine error: unable to open database file: file is not a database\\n   at Turso.Raw.Public.TursoSyncBindings.ThrowException(TursoStatusCode status, IntPtr errorPtr) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoSyncBindings.cs:line 466\\n   at Turso.Raw.Public.TursoSyncBindings.Resume(TursoSyncOperationHandle operation) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoSyncBindings.cs:line 178\\n   at Turso.Turso"},{"kind":"sync","repeat":2,"profile":"prefetched-apply","kill_in_operation":true,"killed_returncode":-9,"replica_resume_ms":65.37887200829573,"replica_home":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_after_restart":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_restart_match":true,"home_restart_home":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_replica":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_match":true,"corruption":"REFUSED: {'startup_error': 'Turso.TursoSyncException: Turso sync Open failed: sync engine operation failed: database sync engine error: unable to open database file: file is not a database\\n ---> Turso.Raw.Public.TursoSyncNativeException: sync engine operation failed: database sync engine error: unable to open database file: file is not a database\\n   at Turso.Raw.Public.TursoSyncBindings.ThrowException(TursoStatusCode status, IntPtr errorPtr) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoSyncBindings.cs:line 466\\n   at Turso.Raw.Public.TursoSyncBindings.Resume(TursoSyncOperationHandle operation) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoSyncBindings.cs:line 178\\n   at Turso.Turso"},{"kind":"sync","repeat":3,"profile":"prefetched-apply","kill_in_operation":true,"killed_returncode":-9,"replica_resume_ms":70.89274399913847,"replica_home":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_after_restart":{"rows":10002,"sha256":"377351a0ea18697636d1282aaa7dd079bea92480a92c53161d8408787de99fbc"},"replica_restart_match":true,"home_restart_home":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_replica":{"rows":10004,"sha256":"3db0bde8efbef97513f61981dd7753b101a66fd6c8a4fe17f0faf7f8ea8d73e0"},"home_restart_match":true,"corruption":"REFUSED: {'startup_error': 'Turso.TursoSyncException: Turso sync Open failed: sync engine operation failed: database sync engine error: unable to open database file: file is not a database\\n ---> Turso.Raw.Public.TursoSyncNativeException: sync engine operation failed: database sync engine error: unable to open database file: file is not a database\\n   at Turso.Raw.Public.TursoSyncBindings.ThrowException(TursoStatusCode status, IntPtr errorPtr) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoSyncBindings.cs:line 466\\n   at Turso.Raw.Public.TursoSyncBindings.Resume(TursoSyncOperationHandle operation) in /home/mariogk/spikes/sql-repl-20261029/export/src/vendor/Turso.Data.Sqlite/src/Turso.Raw/Public/TursoSyncBindings.cs:line 178\\n   at Turso.Turso"}],"issues":[{"issue":"10178","version":"0.8.2","repeat":"1","push1_error":"sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"near \\\")\\\": syntax error\", code: \"BATCH_STEP_ERROR\" }","push2":"ok","home_error":"Parse error: no such table: t","pull":true,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10178","version":"0.8.2","repeat":"2","push1_error":"sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"near \\\")\\\": syntax error\", code: \"BATCH_STEP_ERROR\" }","push2":"ok","home_error":"Parse error: no such table: t","pull":true,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10178","version":"0.8.2","repeat":"3","push1_error":"sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"near \\\")\\\": syntax error\", code: \"BATCH_STEP_ERROR\" }","push2":"ok","home_error":"Parse error: no such table: t","pull":true,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10147","version":"0.8.2","repeat":"1","local_before":[{"id":1,"msg":"inserted 1"}],"home":[["1","inserted 1"],["2","inserted 1"]],"local_after":[{"id":1,"msg":"inserted 1"},{"id":2,"msg":"inserted 1"}]},{"issue":"10147","version":"0.8.2","repeat":"2","local_before":[{"id":1,"msg":"inserted 1"}],"home":[["1","inserted 1"],["2","inserted 1"]],"local_after":[{"id":1,"msg":"inserted 1"},{"id":2,"msg":"inserted 1"}]},{"issue":"10147","version":"0.8.2","repeat":"3","local_before":[{"id":1,"msg":"inserted 1"}],"home":[["1","inserted 1"],["2","inserted 1"]],"local_after":[{"id":1,"msg":"inserted 1"},{"id":2,"msg":"inserted 1"}]},{"issue":"8725","version":"0.8.2","repeat":"1","home":[["1","tail"]],"pull":false,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"8725","version":"0.8.2","repeat":"2","home":[["1","tail"]],"pull":false,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"8725","version":"0.8.2","repeat":"3","home":[["1","tail"]],"pull":false,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10178","version":"0.8.3","repeat":"1","push1_error":"sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"near \\\")\\\": syntax error\", code: \"BATCH_STEP_ERROR\" }","push2":"ok","home_error":"Parse error: no such table: t","pull":true,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10178","version":"0.8.3","repeat":"2","push1_error":"sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"near \\\")\\\": syntax error\", code: \"BATCH_STEP_ERROR\" }","push2":"ok","home_error":"Parse error: no such table: t","pull":true,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10178","version":"0.8.3","repeat":"3","push1_error":"sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"near \\\")\\\": syntax error\", code: \"BATCH_STEP_ERROR\" }","push2":"ok","home_error":"Parse error: no such table: t","pull":true,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"10147","version":"0.8.3","repeat":"1","local_before":[{"id":1,"msg":"inserted 1"}],"home":[["1","inserted 1"],["2","inserted 1"]],"local_after":[{"id":1,"msg":"inserted 1"},{"id":2,"msg":"inserted 1"}]},{"issue":"10147","version":"0.8.3","repeat":"2","local_before":[{"id":1,"msg":"inserted 1"}],"home":[["1","inserted 1"],["2","inserted 1"]],"local_after":[{"id":1,"msg":"inserted 1"},{"id":2,"msg":"inserted 1"}]},{"issue":"10147","version":"0.8.3","repeat":"3","local_before":[{"id":1,"msg":"inserted 1"}],"home":[["1","inserted 1"],["2","inserted 1"]],"local_after":[{"id":1,"msg":"inserted 1"},{"id":2,"msg":"inserted 1"}]},{"issue":"8725","version":"0.8.3","repeat":"1","home":[["1","tail"]],"pull":false,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"8725","version":"0.8.3","repeat":"2","home":[["1","tail"]],"pull":false,"local_error":"prepare failed: Parse error: no such table: t"},{"issue":"8725","version":"0.8.3","repeat":"3","home":[["1","tail"]],"pull":false,"local_error":"prepare failed: Parse error: no such table: t"}],"supplement":[{"kind":"cdc","repeat":1,"profile":"schema-and-trigger","index":[["idx_t_x"]],"trigger_home":[[1,"inserted 1"]],"trigger_replica":[[1,"inserted 1"]],"trigger_schema_home":[["t_ai"]],"trigger_schema_replica":[],"explicit_trigger_home":[[1,"inserted 1"],[2,"inserted 2"]],"explicit_trigger_replica":[[1,"inserted 1"],[2,"inserted 2"],[3,"inserted 2"]]},{"kind":"cdc","repeat":2,"profile":"schema-and-trigger","index":[["idx_t_x"]],"trigger_home":[[1,"inserted 1"]],"trigger_replica":[[1,"inserted 1"]],"trigger_schema_home":[["t_ai"]],"trigger_schema_replica":[],"explicit_trigger_home":[[1,"inserted 1"],[2,"inserted 2"]],"explicit_trigger_replica":[[1,"inserted 1"],[2,"inserted 2"],[3,"inserted 2"]]},{"kind":"cdc","repeat":3,"profile":"schema-and-trigger","index":[["idx_t_x"]],"trigger_home":[[1,"inserted 1"]],"trigger_replica":[[1,"inserted 1"]],"trigger_schema_home":[["t_ai"]],"trigger_schema_replica":[],"explicit_trigger_home":[[1,"inserted 1"],[2,"inserted 2"]],"explicit_trigger_replica":[[1,"inserted 1"],[2,"inserted 2"],[3,"inserted 2"]]},{"kind":"sync","repeat":1,"profile":"schema-and-trigger","index":[["idx_t_x"]],"trigger_home":[["1","inserted 1"]],"trigger_replica":[[1,"inserted 1"]],"trigger_schema_home":[["t_ai"]],"trigger_schema_replica":[["t_ai"]],"rebuild_home":[["1","one",null]],"rebuild_replica":[[1,"one",null]],"with_cdc_home":[["1","one",null],["2","with-cdc","two"]],"with_cdc_replica":[[1,"one",null],[2,"with-cdc","two"]],"backup_cdc_rows":[["2"]]},{"kind":"sync","repeat":2,"profile":"schema-and-trigger","index":[["idx_t_x"]],"trigger_home":[["1","inserted 1"]],"trigger_replica":[[1,"inserted 1"]],"trigger_schema_home":[["t_ai"]],"trigger_schema_replica":[["t_ai"]],"rebuild_home":[["1","one",null]],"rebuild_replica":[[1,"one",null]],"with_cdc_home":[["1","one",null],["2","with-cdc","two"]],"with_cdc_replica":[[1,"one",null],[2,"with-cdc","two"]],"backup_cdc_rows":[["2"]]},{"kind":"sync","repeat":3,"profile":"schema-and-trigger","index":[["idx_t_x"]],"trigger_home":[["1","inserted 1"]],"trigger_replica":[[1,"inserted 1"]],"trigger_schema_home":[["t_ai"]],"trigger_schema_replica":[["t_ai"]],"rebuild_home":[["1","one",null]],"rebuild_replica":[[1,"one",null]],"with_cdc_home":[["1","one",null],["2","with-cdc","two"]],"with_cdc_replica":[[1,"one",null],[2,"with-cdc","two"]],"backup_cdc_rows":[["2"]]}],"rtt":[{"source":"gru","target":"sjc","repeat":1,"path":"public IPv4","icmp":["--- 163.192.54.17 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 827ms"],"tcp_ms":[168.9649559557438,168.89247600920498,168.82439609616995,168.19335205946118,168.71391504537314,168.76159503590316,168.69719501119107,167.82158997375518,167.93362994212657,168.86107600294054],"tcp_errors":[]},{"source":"gru","target":"sjc","repeat":2,"path":"public IPv4","icmp":["--- 163.192.54.17 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 831ms"],"tcp_ms":[168.61391405109316,168.34287298843265,168.25715196318924,168.69623505044729,168.45143400132656,168.17199205979705,168.78079599700868,168.70447504334152,168.38191309943795,168.70883491355926],"tcp_errors":[]},{"source":"gru","target":"sjc","repeat":3,"path":"public IPv4","icmp":["--- 163.192.54.17 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 830ms"],"tcp_ms":[168.4223529882729,168.84743608534336,168.69823494926095,168.26851305086166,168.23167190887034,168.5128330718726,168.2768720202148,168.13679109327495,168.25915197841823,168.6445940285921],"tcp_errors":[]},{"source":"gru","target":"fra","repeat":1,"path":"public IPv4","icmp":["--- 130.162.238.198 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 833ms"],"tcp_ms":[181.15290894638747,180.98978698253632,180.9040670050308,180.85126602090895,187.7701870398596,180.8955860324204,180.77566602732986,180.79778598621488,180.93494698405266,181.04038701858371],"tcp_errors":[]},{"source":"gru","target":"fra","repeat":2,"path":"public IPv4","icmp":["--- 130.162.238.198 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 826ms"],"tcp_ms":[181.04894796852022,180.81494607031345,187.79874709434807,180.9558270033449,187.7541480353102,180.9550269972533,187.87894793786108,188.0489889299497,187.72478692699224,180.98850699607283],"tcp_errors":[]},{"source":"gru","target":"fra","repeat":3,"path":"public IPv4","icmp":["--- 130.162.238.198 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 824ms"],"tcp_ms":[181.1753889778629,187.81182798556983,181.05974805075675,181.05754803400487,181.07518798206002,187.78682698030025,180.9186669997871,180.92358799185604,187.90018802974373,180.92590698506683],"tcp_errors":[]},{"source":"sjc","target":"gru","repeat":1,"path":"public IPv4","icmp":["--- 163.176.124.12 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 826ms"],"tcp_ms":[168.738076929003,168.08382899034768,168.18763001356274,167.72262402810156,168.65859599784017,168.55063405819237,168.34351199213415,168.46427298150957,167.95722697861493,168.22238999884576],"tcp_errors":[]},{"source":"sjc","target":"gru","repeat":2,"path":"public IPv4","icmp":["--- 163.176.124.12 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 825ms"],"tcp_ms":[168.3019120246172,168.37999201379716,168.4130320791155,168.6907160328701,168.37763192597777,168.30695199314505,168.67171495687217,167.90274705272168,168.73643605504185,168.4476729715243],"tcp_errors":[]},{"source":"sjc","target":"gru","repeat":3,"path":"public IPv4","icmp":["--- 163.176.124.12 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 832ms"],"tcp_ms":[168.3144720736891,168.21859101764858,167.88346704561263,168.74615696724504,168.77135599497706,168.37231197860092,168.24783105403185,168.86935802176595,168.70503593236208,168.97519899066538],"tcp_errors":[]},{"source":"sjc","target":"fra","repeat":1,"path":"public IPv4","icmp":["--- 130.162.238.198 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 830ms"],"tcp_ms":[137.73500407114625,136.84715400449932,143.87667400296777,143.8976339995861,144.59072204772383,144.51116102281958,137.26611901074648,144.42759996745735,144.89340502768755,143.97615497000515],"tcp_errors":[]},{"source":"sjc","target":"fra","repeat":2,"path":"public IPv4","icmp":["--- 130.162.238.198 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 828ms"],"tcp_ms":[137.34395999927074,130.2409990457818,137.59844296146184,144.98048601672053,137.17935793101788,136.5801509236917,136.63027191068977,136.88855501823127,144.32451908942312,137.75392400566489],"tcp_errors":[]},{"source":"sjc","target":"fra","repeat":3,"path":"public IPv4","icmp":["--- 130.162.238.198 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 824ms"],"tcp_ms":[137.61840399820358,137.57624302525073,143.9347950508818,137.77116395067424,137.89020606782287,144.42328095901757,137.05347606446594,137.05167593434453,145.46465303283185,144.36719892546535],"tcp_errors":[]},{"source":"fra","target":"gru","repeat":1,"path":"public IPv4","icmp":["--- 163.176.124.12 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 829ms"],"tcp_ms":[181.01990805007517,180.86134793702513,188.45247197896242,180.96134695224464,187.76798795443028,181.06862902641296,187.7805080730468,180.93770800624043,180.9781880583614,180.78622699249536],"tcp_errors":[]},{"source":"fra","target":"gru","repeat":2,"path":"public IPv4","icmp":["--- 163.176.124.12 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 828ms"],"tcp_ms":[187.9735889378935,187.87310796324164,180.92130799777806,181.0254679294303,181.05466896668077,180.854266975075,181.36494990903884,181.03598791640252,187.93474894482642,187.81006801873446],"tcp_errors":[]},{"source":"fra","target":"gru","repeat":3,"path":"public IPv4","icmp":["--- 163.176.124.12 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 829ms"],"tcp_ms":[180.99010805599391,180.89970794972032,180.90794701129198,181.29715009126812,187.53298709634691,189.3651169957593,180.93586701434106,187.79458804056048,181.14438897464424,181.09578895382583],"tcp_errors":[]},{"source":"fra","target":"sjc","repeat":1,"path":"public IPv4","icmp":["--- 163.192.54.17 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 827ms"],"tcp_ms":[137.72933196742088,144.3905319320038,137.63205206487328,137.1584889711812,144.1710910294205,137.71161204203963,137.1001279912889,137.09100894629955,137.51273101661354,144.92385601624846],"tcp_errors":[]},{"source":"fra","target":"sjc","repeat":2,"path":"public IPv4","icmp":["--- 163.192.54.17 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 824ms"],"tcp_ms":[137.13808997999877,144.39745200797915,143.8988889567554,145.40273789316416,144.30897100828588,144.01784993242472,129.7667259350419,144.55569291021675,137.3830899829045,137.52025098074228],"tcp_errors":[]},{"source":"fra","target":"sjc","repeat":3,"path":"public IPv4","icmp":["--- 163.192.54.17 ping statistics ---","5 packets transmitted, 0 received, 100% packet loss, time 828ms"],"tcp_ms":[137.15312897693366,136.62896596360952,144.81625403277576,136.5324059734121,144.314331933856,144.2077710526064,138.0430149147287,137.05372903496027,136.97956805117428,136.93104800768197],"tcp_errors":[]}]}
```

</details>

<details>
<summary>Probe sources (recreate under the exact scratch directory)</summary>

### `Probe.csproj`

SHA-256 `0ae846007911eeb1f55fad760ee871c24b46cd51f70613a13bf9d01ede39ac96`

```xml
<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="Program.cs"/><Compile Include="Record.cs"/><ProjectReference Include="export/src/vendor/Turso.Data.Sqlite/src/Turso.Data/Turso.Data.csproj"/></ItemGroup></Project>

```

### `Program.cs`

SHA-256 `e06347a0d34d39613e49aedb64956dfd5d565291a729dd71484a2bd20efbdca5`

```csharp
using System.Data.Common;
using System.Text.Json;
using Turso;
using System.Diagnostics;

TursoSyncDatabase? sync = null;
TursoConnection? db = null;
var path=args[0];
try {
 if(args.Length>1) {var opts=new TursoSyncDatabaseOptions(path,new Uri(args[1])){ExperimentalFeatures="triggers",ForceLogicalMvccPull=args.Contains("mvcc")};sync=File.Exists(path)?TursoSyncDatabase.Open(opts):TursoSyncDatabase.Create(opts);db=sync.Connect();}
 else {db=new TursoConnection($"Data Source={path};Pooling=False");db.Open();}
 Console.WriteLine("{\"ready\":true}");
} catch(Exception e){Console.WriteLine(JsonSerializer.Serialize(new{startup_error=e.ToString()}));return;}
var shapes=new Dictionary<string,(string[],int)>();
string Q(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
object?[] Sql(string sql, object?[]? pars=null){using var cmd=db.CreateCommand();cmd.CommandText=sql;if(pars!=null)for(int i=0;i<pars.Length;i++)cmd.Parameters.Add(new TursoParameter("$p"+i,pars[i]??DBNull.Value));using var rows=cmd.ExecuteReader();var result=new List<object?[]>();while(rows.Read()){var v=new object[rows.FieldCount];rows.GetValues(v);result.Add(v.Select(x=>x is DBNull?null:x).ToArray());}return result.Cast<object?>().ToArray();}
object? ConvertJson(JsonElement x)=>x.ValueKind switch{JsonValueKind.Null=>null,JsonValueKind.String=>x.GetString(),JsonValueKind.Number=>x.TryGetInt64(out var n)?n:x.GetDouble(),_=>throw new Exception("bad parameter")};
while(Console.ReadLine() is {} line){try{
 var j=JsonDocument.Parse(line).RootElement;var op=j.GetProperty("op").GetString();object? result=null;
 if(op=="batch"){foreach(var s in j.GetProperty("sqls").EnumerateArray())result=Sql(s.GetString()!);}
 else if(op=="sql")result=Sql(j.GetProperty("sql").GetString()!,j.TryGetProperty("args",out var a)?a.EnumerateArray().Select(ConvertJson).ToArray():null);
 else if(op=="pull"){result=sync!.Pull();}
 else if(op=="push"){sync!.Push();result=true;}
 else if(op=="stats")result=sync!.GetStats();
 else if(op=="cdc"){
  var after=j.GetProperty("after").GetInt64();var data=Sql("SELECT change_id,change_type,table_name,id,after FROM turso_cdc WHERE change_id>$p0 ORDER BY change_id LIMIT 20000",[after]).Cast<object?[]>().ToList();
  int end=data.FindLastIndex(r=>System.Convert.ToInt64(r[1])==2);result=end<0?Array.Empty<object[]>():data.Take(end+1).ToArray();
 }
 else if(op=="apply"){
  long end=0;bool open=false;
  try{foreach(var row in j.GetProperty("rows").EnumerateArray()){
   long id=row[0].GetInt64(),type=row[1].GetInt64();if(!open){Sql("BEGIN IMMEDIATE");open=true;}
   if(type==2){Sql("INSERT OR REPLACE INTO _spike_cursor VALUES(1,$p0)",[id]);Sql("COMMIT");open=false;end=id;continue;}
   var table=row[2].GetString()!;long rid=row[3].GetInt64();var v=row[4].ValueKind==JsonValueKind.Null?null:SqliteRecord.Decode(row[4].GetBytesFromBase64());
   if(table=="sqlite_schema"){
    if(type!=1)throw new Exception("REFUSE schema mutation: DDL envelope or snapshot required");
    if(v is [string kind,string name,_,_,string ddl,..]&&!name.StartsWith("sqlite_")&&!name.StartsWith("turso_")){Sql(ddl);shapes.Clear();}
    continue;
   }
   if(table.StartsWith("turso_")||table.StartsWith("sqlite_")||table.StartsWith("_spike_"))continue;
   if(type==-1){Sql($"DELETE FROM {Q(table)} WHERE rowid=$p0",[rid]);continue;}
   if(!shapes.TryGetValue(table,out var sh)){
    var info=Sql($"PRAGMA table_info({Q(table)})").Cast<object?[]>().ToArray();var cols=info.Select(x=>(string)x[1]!).ToArray();int alias=Array.FindIndex(info,x=>string.Equals((string)x[2]!,"INTEGER",StringComparison.OrdinalIgnoreCase)&&System.Convert.ToInt64(x[5])==1);sh=(cols,alias);shapes[table]=sh;
   }
   var names=new List<string>{"rowid"};var vals=new List<object?>{rid};for(int k=0;k<v!.Length;k++)if(k!=sh.Item2){names.Add(Q(sh.Item1[k]));vals.Add(v[k]);}
   Sql($"INSERT OR REPLACE INTO {Q(table)}({string.Join(',',names)}) VALUES({string.Join(',',Enumerable.Range(0,vals.Count).Select(k=>"$p"+k))})",vals.ToArray());
  }}catch{if(open)Sql("ROLLBACK");throw;}result=end;
 }
 else if(op=="clock")result=DateTime.UtcNow.Ticks;
 else if(op=="exit")break;
 else throw new Exception("unknown op");
 Console.WriteLine(JsonSerializer.Serialize(new{ok=true,result,ticks=DateTime.UtcNow.Ticks}));
}catch(Exception e){Console.WriteLine(JsonSerializer.Serialize(new{ok=false,error=e.Message,ticks=DateTime.UtcNow.Ticks}));}}
db.Dispose();sync?.Dispose();

```

### `run.py`

SHA-256 `41279435836d7e5a9c14e46644a59ddd5b27331ea3c7d420300773651132fbc1`

```python
import subprocess,os,json,time,threading,hashlib,urllib.request,socket,statistics,sys,traceback
from pathlib import Path
R=Path('/home/mariogk/spikes/sql-repl-20261029'); TICKS=621355968000000000
class RPC:
 def __init__(self,path,host='beta',url=None,mvcc=False):
  self.host=host;self.last_ticks=0;self.lock=threading.Lock();self.log=open(R/(Path(path).stem+'-'+host+'.log'),'a')
  args=['dotnet',str(R/'bin/Release/net11.0/Probe.dll'),str(path)]+([url]+(['mvcc'] if mvcc else []) if url else [])
  if host!=socket.gethostname():args=['ssh','-o','BatchMode=yes',host]+args
  self.p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True,bufsize=1)
  ready=self.p.stdout.readline();self.ready=json.loads(ready) if ready else {'startup_error':'no stdout; '+str(self.p.poll())}
  if 'startup_error' in self.ready:raise RuntimeError(self.ready)
 def call(self,op,**kw):
  with self.lock:
   self.p.stdin.write(json.dumps(dict(op=op,**kw))+'\n');self.p.stdin.flush();s=self.p.stdout.readline()
   if not s:raise RuntimeError('child EOF '+str(self.p.poll()))
   r=json.loads(s)
   self.last_ticks=r.get('ticks',0)
   if not r.get('ok'):raise RuntimeError(r.get('error',str(r)))
   return r
 def sql(self,s):return self.call('sql',sql=s)['result']
 def sqls(self,s):return self.call('batch',sqls=s)['result']
 def close(self):
  if self.p.poll() is None:
   try:self.call('exit')
   except:pass
  try:self.p.wait(timeout=5)
  except:self.p.kill();self.p.wait()
  self.log.close()
class Server:
 def __init__(self,path,v='0.8.2',port=None):
  self.path=path;self.v=v
  if port is None:
   s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
  self.port=port;self.url='http://127.0.0.1:'+str(port);self.log=open(R/(Path(path).stem+'-server.log'),'a')
  self.start()
 def start(self):
  exe=R/('cli-'+self.v)/'turso_cli-x86_64-unknown-linux-gnu/tursodb'
  self.p=subprocess.Popen([str(exe),str(self.path),'--sync-server','127.0.0.1:'+str(self.port)],stdout=self.log,stderr=self.log)
  for k in range(100):
   try:self.sql('SELECT 1');return
   except Exception:
    if self.p.poll()!=None:raise RuntimeError('server exited '+str(self.p.returncode))
    time.sleep(.05)
  raise RuntimeError('server failed to listen')
 def sqls(self,ss):
  body={'requests':[{'type':'execute','stmt':{'sql':s}} for s in ss]}
  req=urllib.request.Request(self.url+'/v2/pipeline',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
  data=json.load(urllib.request.urlopen(req,timeout=20));result=None
  for r in data['results']:
   if r['type']!='ok':raise RuntimeError(r)
   out=r['response']['result'];result=[[cell.get('value') for cell in row] for row in out.get('rows',[])]
  return result
 def sql(self,s):return self.sqls([s])
 def close(self):
  if self.p.poll() is None:self.p.terminate();self.p.wait(timeout=5)
 def done(self):self.close();self.log.close()
def drain(h,r,after):
 while True:
  rows=h.call('cdc',after=after)['result']
  if not rows:return after
  after=r.call('apply',rows=rows)['result']
def digest(db):
 tables=db.sql("SELECT name FROM sqlite_schema WHERE type='table' AND name IN ('items','parent') ORDER BY name")
 h=hashlib.sha256();counts={}
 for (table,) in tables:
  rows=db.sql('SELECT * FROM '+table+' ORDER BY id');counts[table]=len(rows)
  # Normalize HTTP Hrana integers (strings) to match typed ADO integers.
  rows=[[int(c) if isinstance(c,str) and c.lstrip('-').isdigit() else c for c in row] for row in rows]
  h.update(json.dumps([table,rows],separators=(',',':'),ensure_ascii=False).encode())
 return {'sha256':h.hexdigest(),'counts':counts}
def correct(kind,rep):
 prefix=f'correct-valid-{kind}-{rep}';h=r=None;out={'kind':kind,'repeat':rep}
 try:
  h=Server(R/(prefix+'-home.db')) if kind=='sync' else RPC(R/(prefix+'-home.db'))
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  r=RPC(R/(prefix+'-rep.db'),url=h.url if kind=='sync' else None)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)')
  h.sql('PRAGMA foreign_keys=ON')
  h.sqls(['CREATE TABLE parent(id INTEGER PRIMARY KEY, name TEXT UNIQUE)','CREATE TABLE items(id INTEGER PRIMARY KEY, parent_id INTEGER REFERENCES parent(id), name TEXT UNIQUE, val INTEGER)','INSERT INTO parent VALUES '+','.join(f"({i},'p{i}')" for i in range(1,101))])
  for start in range(1,100001,1000):h.sql('INSERT INTO items VALUES '+','.join(f"({i},{(i-1)%100+1},'i{i}',{i*3})" for i in range(start,start+1000)))
  out['initial']=digest(h)
  failures={}
  for name,sql in [('unique',"INSERT INTO items VALUES(100001,1,'i1',0)"),('fk',"INSERT INTO items VALUES(100001,999,'bad-fk',0)")]:
   try:h.sql(sql);failures[name]='ACCEPTED INVALID'
   except Exception as e:failures[name]=str(e)[:300]
  out['constraints']=failures
  h.sqls(['UPDATE items SET val=val+1 WHERE id%10=0','DELETE FROM items WHERE id%20=1','BEGIN IMMEDIATE',"INSERT INTO parent VALUES(101,'txn-parent')","INSERT INTO items VALUES(100002,101,'txn-child',42)",'UPDATE items SET val=77 WHERE id=2','COMMIT','BEGIN IMMEDIATE',"INSERT INTO items VALUES(100003,1,'rollback',0)",'ROLLBACK'])
  if kind=='sync':r.call('pull');after=0
  else:after=drain(h,r,0)
  out['dml_home']=digest(h);out['dml_replica']=digest(r);out['dml_match']=out['dml_home']==out['dml_replica']
  h.sql('ALTER TABLE items ADD COLUMN extra TEXT DEFAULT \'added\'');h.sql('CREATE INDEX idx_items_val ON items(val)')
  try:
   if kind=='sync':r.call('pull')
   else:after=drain(h,r,after)
   out['ddl_replica']=digest(r);out['ddl_home']=digest(h);out['ddl_match']=out['ddl_home']==out['ddl_replica'];out['index']=r.sql("SELECT name FROM sqlite_schema WHERE name='idx_items_val'")
  except Exception as e:out['ddl_error']=str(e)
 except Exception as e:out['error']=str(e);out['trace']=traceback.format_exc()
 finally:
  if r:r.close()
  if h:h.done() if kind=='sync' else h.close()
 return out

def clock_offset(r):
 samples=[]
 for _ in range(21):
  t0=time.time_ns()/100;v=r.call('clock')['result']-TICKS;t1=time.time_ns()/100;samples.append((t1-t0,v-(t0+t1)/2))
 best=min(samples);return {'offset_ticks':best[1],'half_rtt_ms':best[0]/20000,'samples':21}
def bench(kind,host,rate,rep,seconds=10):
 prefix=f'bench-final-{kind}-{host}-{rate}-{rep}';h=r=None;tunnel=None;err=[];out={'kind':kind,'host':host,'rate':rate,'repeat':rep}
 stop=threading.Event();lock=threading.Lock();last=0;delays=[];after=0;slow=[]
 try:
  h=Server(R/(prefix+'-home.db')) if kind=='sync' else RPC(R/(prefix+'-home.db'))
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sql('CREATE TABLE samples(id INTEGER PRIMARY KEY, stamp INTEGER)')
  url=None
  if kind=='sync':
   url=h.url
   if host!='beta':
    targetport=h.port+1000 if h.port<64000 else h.port-1000
    tunnel=subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ExitOnForwardFailure=yes','-N','-R',f'127.0.0.1:{targetport}:127.0.0.1:{h.port}',host],stderr=subprocess.DEVNULL)
    time.sleep(.3);url='http://127.0.0.1:'+str(targetport)
  r=RPC(R/(prefix+'-rep.db'),host=host,url=url)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)');after=drain(h,r,0)
  else:r.call('pull')
  offset=clock_offset(r);out['clock']=offset
  def tail():
   nonlocal last,after
   try:
    while not stop.is_set():
     ship_start=time.perf_counter()
     if kind=='sync':r.call('pull')
     else:after=drain(h,r,after)
     applied=r.last_ticks-offset['offset_ticks']
     ship_ms=(time.perf_counter()-ship_start)*1000
     q_start=time.perf_counter()
     rows=r.call('sql',sql=f'SELECT id,stamp FROM samples WHERE id>{last} ORDER BY id')
     q_ms=(time.perf_counter()-q_start)*1000
     if ship_ms>100 or q_ms>100:slow.append({'ship_ms':round(ship_ms,3),'query_ms':round(q_ms,3),'through':last})
     for idx,stamp in rows['result']:delays.append((applied-stamp)/10000);last=idx
     time.sleep(.001)
   except Exception as e:err.append(str(e));stop.set()
  th=threading.Thread(target=tail);th.start()
  batch=10 if rate==200 else 100;interval=batch/rate;start=time.monotonic();n=0;commits=[]
  for step in range(int(seconds/interval)):
   due=start+step*interval
   delay=due-time.monotonic()
   if delay>0:time.sleep(delay)
   if stop.is_set():break
   stamp=TICKS+time.time_ns()//100;t0=time.monotonic()
   h.sqls(['BEGIN IMMEDIATE','INSERT INTO samples VALUES '+','.join(f'({n+i+1},{stamp})' for i in range(batch)),'COMMIT'])
   commits.append((time.monotonic()-t0)*1000);n+=batch
  elapsed=time.monotonic()-start
  until=time.monotonic()+20
  while last<n and time.monotonic()<until and not stop.is_set():time.sleep(.01)
  stop.set();th.join(timeout=25)
  def p(xs,q):return sorted(xs)[min(len(xs)-1,int(q*len(xs)))] if xs else None
  out.update(writes=n,applied=last,samples=len(delays),seconds=elapsed,achieved_writes_s=n/elapsed,batch=batch,p50_ms=p(delays,.5),p99_ms=p(delays,.99),max_ms=max(delays) if delays else None,min_ms=min(delays) if delays else None,commit_p50_ms=p(commits,.5),commit_p99_ms=p(commits,.99),errors=err,slow_operations=slow,measurement='apply_completion',end_clock=clock_offset(r))
 except Exception as e:out['error']=str(e);out['trace']=traceback.format_exc()
 finally:
  stop.set()
  if r:r.close()
  if h:h.done() if kind=='sync' else h.close()
  if tunnel:tunnel.terminate();tunnel.wait(timeout=5)
 return out

def save(x):
 print(json.dumps(x),flush=True)
 with open(R/'results.jsonl','a') as f:f.write(json.dumps(x)+'\n')
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='correct':
  for kind in ['cdc','sync']:
   for rep in range(1,4):save(correct(kind,rep))
 if mode=='bench':
  for kind in ['cdc','sync']:
   for host in ['beta','delta','mariogk-dev']:
    for rate in [200,2000]:
     for rep in range(1,4):save(bench(kind,host,rate,rep))

```

### `recovery.py`

SHA-256 `37a3a7e48a2ff5b95ecfeedf83baae57c3608c6816de9bbd6995ece09056ccfa`

```python
from run import *
import base64,shutil

def rowsig(db):
 rows=db.sql('SELECT * FROM t ORDER BY id');rows=[[int(x) if isinstance(x,str) and x.isdigit() else x for x in row]for row in rows]
 return {'rows':len(rows),'sha256':hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()}
def recover(kind,rep):
 prefix=f'recovery-final-{kind}-{rep}';hp=R/(prefix+'-home.db');rp=R/(prefix+'-rep.db');h=r=None;out={'kind':kind,'repeat':rep,'profile':'prefetched-apply'}
 try:
  h=Server(hp) if kind=='sync' else RPC(hp)
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sql('CREATE TABLE t(id INTEGER PRIMARY KEY,val TEXT)');h.sql("INSERT INTO t VALUES(1,'base')")
  r=RPC(rp,url=h.url if kind=='sync' else None)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)');after=drain(h,r,0)
  else:r.call('pull')
  for start in range(2,10002,1000):h.sql('INSERT INTO t VALUES '+','.join(f"({i},'v{i}')"for i in range(start,start+1000)))
  packet=h.call('cdc',after=after)['result'] if kind=='cdc' else None
  errors=[];kill_started=time.monotonic()
  def pending():
   try:
    if kind=='sync':r.call('pull')
    else:r.call('apply',rows=packet)
   except Exception as e:errors.append(str(e))
  t=threading.Thread(target=pending);t.start();time.sleep(.050 if kind=='cdc' else .001);was_running=t.is_alive();r.p.kill();r.p.wait();t.join(timeout=5);r.log.close()
  out['kill_in_operation']=was_running;out['killed_returncode']=r.p.returncode;r=None
  h.sql("INSERT INTO t VALUES(20000,'offline')")
  r=RPC(rp,url=h.url if kind=='sync' else None)
  resume=time.monotonic()
  if kind=='sync':r.call('pull')
  else:
   cursor=r.sql('SELECT seq FROM _spike_cursor WHERE id=1');after=cursor[0][0]if cursor else 0;after=drain(h,r,after);out['persisted_resume_cursor']=cursor
  out['replica_resume_ms']=(time.monotonic()-resume)*1000;out['replica_home']=rowsig(h);out['replica_after_restart']=rowsig(r);out['replica_restart_match']=out['replica_home']==out['replica_after_restart']
  # Abrupt home termination, after an acknowledged committed write.
  h.sql("INSERT INTO t VALUES(20001,'before-home-kill')")
  if kind=='sync':h.p.kill();h.p.wait();h.start()
  else:h.p.kill();h.p.wait();h.log.close();h=RPC(hp);h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sql("INSERT INTO t VALUES(20002,'after-home-kill')")
  if kind=='sync':r.call('pull')
  else:after=drain(h,r,after)
  out['home_restart_home']=rowsig(h);out['home_restart_replica']=rowsig(r);out['home_restart_match']=out['home_restart_home']==out['home_restart_replica']
  if kind=='cdc':
   h.sql("INSERT INTO t VALUES(20003,'malformed-transport-test')");packet=h.call('cdc',after=after)['result'];bad=json.loads(json.dumps(packet));bad[0][4]=base64.b64encode(b'\xff').decode();before=rowsig(r);cursorbefore=r.sql('SELECT * FROM _spike_cursor')
   try:r.call('apply',rows=bad);out['malformed']='ACCEPTED'
   except Exception as e:out['malformed']='REFUSED: '+str(e)
   out['malformed_atomic']=before==rowsig(r)and cursorbefore==r.sql('SELECT * FROM _spike_cursor');after=drain(h,r,after)
  r.close();r=None
  # Corrupt this scratch replica's database header after closing its owner.
  with open(rp,'r+b')as f:f.write(b'CORRUPT-SPIKE!!!\0');f.flush();os.fsync(f.fileno())
  try:
   r=RPC(rp,url=h.url if kind=='sync' else None);r.sql('SELECT count(*) FROM t');out['corruption']='ACCEPTED'
  except Exception as e:out['corruption']='REFUSED: '+str(e)[:800]
 except Exception as e:out['error']=str(e);out['trace']=traceback.format_exc()
 finally:
  if r:r.close()
  if h:h.done()if kind=='sync'else h.close()
 return out
if __name__=='__main__':
 for kind in ['cdc','sync']:
  for rep in range(1,4):
   x=recover(kind,rep);print(json.dumps(x),flush=True)
   with open(R/'recovery.jsonl','a')as f:f.write(json.dumps(x)+'\n')

```

### `supplement.py`

SHA-256 `8dafc200fb2d050d2b3ac713d8cc8309dc6428b45232b9ab5a33f8906264d36d`

```python
from run import *

def trial(kind,rep):
 prefix=f'extra-final-{kind}-{rep}';h=r=None;out={'kind':kind,'repeat':rep,'profile':'schema-and-trigger'}
 try:
  h=Server(R/(prefix+'-home.db')) if kind=='sync' else RPC(R/(prefix+'-home.db'))
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sqls(['CREATE TABLE t(id INTEGER PRIMARY KEY,x TEXT)','CREATE TABLE audit(id INTEGER PRIMARY KEY,msg TEXT)',"CREATE TRIGGER t_ai AFTER INSERT ON t BEGIN INSERT INTO audit(msg) VALUES('inserted ' ||new.id); END;"])
  r=RPC(R/(prefix+'-rep.db'),url=h.url if kind=='sync' else None)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)');after=drain(h,r,0)
  else:r.call('pull')
  h.sql('CREATE INDEX idx_t_x ON t(x)')
  if kind=='cdc':after=drain(h,r,after)
  else:r.call('pull')
  out['index']=r.sql("SELECT name FROM sqlite_schema WHERE name='idx_t_x'")
  h.sql("INSERT INTO t VALUES(1,'one')")
  if kind=='cdc':after=drain(h,r,after)
  else:r.call('pull')
  out['trigger_home']=h.sql('SELECT * FROM audit ORDER BY id');out['trigger_replica']=r.sql('SELECT * FROM audit ORDER BY id')
  out['trigger_schema_home']=h.sql("SELECT name FROM sqlite_schema WHERE type='trigger'");out['trigger_schema_replica']=r.sql("SELECT name FROM sqlite_schema WHERE type='trigger'")
  if kind=='cdc':
   r.sql("CREATE TRIGGER t_ai AFTER INSERT ON t BEGIN INSERT INTO audit(msg) VALUES('inserted ' ||new.id); END;")
   h.sql("INSERT INTO t VALUES(2,'two')");after=drain(h,r,after)
   out['explicit_trigger_home']=h.sql('SELECT * FROM audit ORDER BY id');out['explicit_trigger_replica']=r.sql('SELECT * FROM audit ORDER BY id')
  if kind=='sync':
   h.sqls(['BEGIN IMMEDIATE','CREATE TABLE __new_t(id INTEGER PRIMARY KEY,x TEXT,y TEXT)','INSERT INTO __new_t(id,x) SELECT id,x FROM t','DROP TABLE t','ALTER TABLE __new_t RENAME TO t','COMMIT'])
   r.call('pull');out['rebuild_home']=h.sql('SELECT * FROM t');out['rebuild_replica']=r.sql('SELECT * FROM t')
   # Enable source CDC as continuous backup would. Keep it alongside WAL pulls.
   h.sql("PRAGMA capture_data_changes_conn('after')");h.sql("INSERT INTO t VALUES(2,'with-cdc','two')");r.call('pull')
   out['with_cdc_home']=h.sql('SELECT * FROM t ORDER BY id');out['with_cdc_replica']=r.sql('SELECT * FROM t ORDER BY id')
   out['backup_cdc_rows']=h.sql('SELECT count(*) FROM turso_cdc')
 except Exception as e:out['error']=str(e)
 finally:
  if r:r.close()
  if h:h.done()if kind=='sync'else h.close()
 return out
for kind in ['cdc','sync']:
 for rep in range(1,4):
  x=trial(kind,rep);print(json.dumps(x),flush=True)
  with open(R/'supplement.jsonl','a')as f:f.write(json.dumps(x)+'\n')

```

### `repro.mjs`

SHA-256 `f955d253b61402ce888c7399eb5a3ca495ff8f7354062db603098fca857d03f1`

```javascript
import {spawn,execFileSync} from 'node:child_process';
import {mkdirSync,createWriteStream} from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const root='/home/mariogk/spikes/sql-repl-20261029';
const [v,issue,repeat]=process.argv.slice(2);
const {connect}=require(v==='0.8.2'?`${root}/npm082/node_modules/@tursodatabase/sync`:'sync083');
const dir=`${root}/issue-pinned-${issue}-${v}-${repeat}`;mkdirSync(dir,{recursive:true});
const exe=`${root}/cli-${v}/turso_cli-x86_64-unknown-linux-gnu/tursodb`;
const port=19400+Number(repeat)+(v==='0.8.3'?10:0)+(issue==='10147'?20:issue==='8725'?40:0);const url=`http://127.0.0.1:${port}`;
if(issue==='8725')execFileSync(exe,[`${dir}/server.db`,"PRAGMA journal_mode='mvcc'"],{stdio:'ignore'});
const log=createWriteStream(`${dir}/server.log`);const server=spawn(exe,[`${dir}/server.db`,'--sync-server',`127.0.0.1:${port}`]);server.stdout.pipe(log);server.stderr.pipe(log);
const timeout=setTimeout(()=>{server.kill('SIGKILL');process.exit(124)},30000);
let db;const result={issue,version:v,repeat};
async function remoteSql(sql){const res=await fetch(`${url}/v2/pipeline`,{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql}}]})});const [x]=(await res.json()).results;if(x.type!=='ok')throw Error(x.error.message);return x.response.result.rows.map(row=>row.map(cell=>cell.value));}
try{
 for(let n=0;n<100;n++){try{await remoteSql('SELECT 1');break}catch(e){await new Promise(r=>setTimeout(r,50))}}
 if(issue==='8725'){
  await remoteSql('CREATE TABLE t(id INTEGER PRIMARY KEY,x)');await remoteSql("INSERT INTO t VALUES(1,'tail')");result.home=await remoteSql('SELECT * FROM t');
  db=await connect({path:`${dir}/app.db`,url});result.pull=await db.pull();
  try{result.local=await (await db.prepare('SELECT * FROM t')).all()}catch(e){result.local_error=e.message}
 } else if(issue==='10178'){
  db=await connect({path:`${dir}/app.db`,url});await db.exec('CREATE TABLE t(x)');await db.exec('INSERT INTO t VALUES(1),(2)');await db.push();
  await db.exec('CREATE TABLE __new_t(x,y)');await db.exec('INSERT INTO __new_t(x) SELECT x FROM t');await db.exec('DROP TABLE t');await db.exec('ALTER TABLE __new_t RENAME TO t');
  for(const step of ['push1','push2','home','pull','local']){try{if(step.startsWith('push')){await db.push();result[step]='ok'}if(step==='home')result.home=await remoteSql('SELECT count(*) FROM t');if(step==='pull')result.pull=await db.pull();if(step==='local')result.local=await(await db.prepare('SELECT count(*) AS n FROM t')).get()}catch(e){result[step+'_error']=e.message}}
 } else {
  for(const s of ['CREATE TABLE t(id INTEGER PRIMARY KEY,x)','CREATE TABLE audit(id INTEGER PRIMARY KEY,msg)',"CREATE TRIGGER t_ai AFTER INSERT ON t BEGIN INSERT INTO audit(msg) VALUES ('inserted ' || new.id); END;"])await remoteSql(s);
  db=await connect({path:`${dir}/app.db`,url});await db.exec("INSERT INTO t VALUES(1,'a')");result.local_before=await(await db.prepare('SELECT * FROM audit ORDER BY id')).all();await db.push();result.home=await remoteSql('SELECT * FROM audit ORDER BY id');await db.pull();result.local_after=await(await db.prepare('SELECT * FROM audit ORDER BY id')).all();
 }
}catch(e){result.error=e.message}
finally{if(db)try{await db.close()}catch{}server.kill();clearTimeout(timeout);console.log(JSON.stringify(result));}

```

### `rtt.py`

SHA-256 `7f470333760e6627d1707d1640693b68edd3d7cfdd34ab88da271098dd03a783`

```python
import json,sys,socket,time,subprocess,statistics,urllib.request
region=sys.argv[1]
try:
 req=urllib.request.Request('http://169.254.169.254/opc/v2/instance/',headers={'Authorization':'Bearer Oracle'})
 m=json.load(urllib.request.urlopen(req,timeout=2));print(json.dumps({'imds_region':m.get('region'),'canonicalRegionName':m.get('canonicalRegionName'),'source':region}),flush=True)
except Exception as e:print(json.dumps({'source':region,'imds_error':str(e)}),flush=True)
ips={'gru':'163.176.124.12','sjc':'163.192.54.17','fra':'130.162.238.198'}
for dst,ip in ips.items():
 if dst==region:continue
 for repeat in range(1,4):
  ping=subprocess.run(['ping','-n','-c','5','-i','0.2','-W','1',ip],capture_output=True,text=True,timeout=12)
  times=[];errors=[]
  for _ in range(10):
   start=time.perf_counter()
   try:
    s=socket.create_connection((ip,443),timeout=2);times.append((time.perf_counter()-start)*1000);s.close()
   except Exception as e:errors.append(type(e).__name__)
  print(json.dumps({'source':region,'target':dst,'repeat':repeat,'path':'public IPv4','icmp':ping.stdout.strip().splitlines()[-2:],'tcp_ms':times,'tcp_errors':errors}),flush=True)

```

</details>

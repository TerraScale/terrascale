import {spawn,execFileSync} from 'node:child_process';
import {mkdirSync,createWriteStream} from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const root=process.env.SPIKE_ROOT;
const [v,issue,repeat]=process.argv.slice(2);
const {connect}=require(`${root}/js${v}/node_modules/@tursodatabase/sync`);
const dir=`${root}/issue-pinned-${issue}-${v}-${repeat}`;mkdirSync(dir,{recursive:true});
const exe=`${root}/bin${v}/turso_cli-x86_64-unknown-linux-gnu/tursodb`;
const net=await import('node:net');const sock=net.createServer();sock.listen(0,'127.0.0.1');await new Promise(r=>sock.once('listening',r));const port=sock.address().port;await new Promise(r=>sock.close(r));const url=`http://127.0.0.1:${port}`;
if(issue==='8725')execFileSync(exe,[`${dir}/server.db`,"PRAGMA journal_mode='mvcc'"],{stdio:'ignore'});
const log=createWriteStream(`${dir}/server.log`);const server=spawn(exe,[`${dir}/server.db`,'--sync-server',`127.0.0.1:${port}`]);server.stdout.pipe(log);server.stderr.pipe(log);
const timeout=setTimeout(()=>{server.kill('SIGKILL');process.exit(124)},30000);
let db;const result={issue,version:v,repeat};
async function remoteSql(sql){const res=await fetch(`${url}/v2/pipeline`,{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql}}]})});const [x]=(await res.json()).results;if(x.type!=='ok')throw Error(x.error.message);return x.response.result.rows.map(row=>row.map(cell=>cell.value));}
try{
 for(let n=0;n<100;n++){try{await remoteSql('SELECT 1');break}catch(e){await new Promise(r=>setTimeout(r,50))}}
 if(issue==='8725'){
  await remoteSql('CREATE TABLE t(id INTEGER PRIMARY KEY,x)');await remoteSql("INSERT INTO t VALUES(1,'tail')");result.home=await remoteSql('SELECT * FROM t');
  db=await connect({path:`${dir}/app.db`,url});result.pull=await db.pull();
  try{result.local=await (await db.prepare('SELECT * FROM t')).all()}catch(e){result.local_error=e.message}
 } else if(issue==='10178'){
  db=await connect({path:`${dir}/app.db`,url});await db.exec('CREATE TABLE t(x)');await db.exec('INSERT INTO t VALUES(1),(2)');await db.push();
  await db.exec('CREATE TABLE __new_t(x,y)');await db.exec('INSERT INTO __new_t(x) SELECT x FROM t');await db.exec('DROP TABLE t');await db.exec('ALTER TABLE __new_t RENAME TO t');
  for(const step of ['push1','push2','home','pull','local']){try{if(step.startsWith('push')){await db.push();result[step]='ok'}if(step==='home')result.home=await remoteSql('SELECT count(*) FROM t');if(step==='pull')result.pull=await db.pull();if(step==='local')result.local=await(await db.prepare('SELECT count(*) AS n FROM t')).get()}catch(e){result[step+'_error']=e.message}}
 } else {
  for(const s of ['CREATE TABLE t(id INTEGER PRIMARY KEY,x)','CREATE TABLE audit(id INTEGER PRIMARY KEY,msg)',"CREATE TRIGGER t_ai AFTER INSERT ON t BEGIN INSERT INTO audit(msg) VALUES ('inserted ' || new.id); END;"])await remoteSql(s);
  db=await connect({path:`${dir}/app.db`,url});await db.exec("INSERT INTO t VALUES(1,'a')");result.local_before=await(await db.prepare('SELECT * FROM audit ORDER BY id')).all();await db.push();result.home=await remoteSql('SELECT * FROM audit ORDER BY id');await db.pull();result.local_after=await(await db.prepare('SELECT * FROM audit ORDER BY id')).all();
 }
}catch(e){result.error=e.message}
finally{if(db)try{await db.close()}catch{}server.kill();clearTimeout(timeout);console.log(JSON.stringify(result));}


import {spawn,spawnSync} from 'node:child_process';
import {mkdir,open,writeFile,readFile} from 'node:fs/promises';
import net from 'node:net';
import {performance} from 'node:perf_hooks';
const root=process.env.SPIKE_ROOT,ver=process.argv[2]??'082';
const {connect}=await import(`${root}/js${ver}/node_modules/@tursodatabase/sync/dist/promise.js`);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const records=[];
const only=process.argv[3];
async function run(rtt,rate,repeat){
 const tc=rtt?spawnSync('tc',['qdisc','replace','dev','lo','root','netem','delay',`${rtt/2}ms`]):spawnSync('tc',['qdisc','del','dev','lo','root']);
 if(rtt&&tc.status)throw Error(tc.stderr.toString());
 const ping=spawnSync('ping',['-n','-c','3','-i','0.2','127.0.0.1']).stdout.toString().trim().split('\n').slice(-1)[0];
 const dir=`${root}/lag${ver}/${rtt}-${rate}-${repeat}-${Date.now()}`;await mkdir(dir,{recursive:true});
 const port=await new Promise(r=>{let s=net.createServer();s.listen(0,'127.0.0.1',()=>{let p=s.address().port;s.close(()=>r(p))})});
 const log=await open(`${dir}/server.log`,'w');
 const server=spawn(`${root}/bin${ver}/turso_cli-x86_64-unknown-linux-gnu/tursodb`,[`${dir}/H.db`,'--sync-server',`127.0.0.1:${port}`],{stdio:['ignore',log.fd,log.fd]});
 const url=`http://127.0.0.1:${port}`;
 let a,b,c,pushTask,pullTask;
 let stopped=false,writerDone=false,pushDirty=false,pushes=0,pulls=0,pushHttp=0,waitHttp=0;
 let error=null;const requestMs=[],emptyPullMs=[],ackTimes=[],startTimes=[],observed=[],localDur=[];
 try{
  for(let i=0;i<100;i++){try{await fetch(url);break}catch{await sleep(10)}}
  await fetch(url+'/v2/pipeline',{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql:'CREATE TABLE t(id INTEGER PRIMARY KEY,v TEXT)',want_rows:false}}]})});
  const options=i=>({path:`${dir}/R${i}.db`,url,clientName:`lag-R${i}`,longPollTimeoutMs:5000,fetch:async(u,init)=>{let t=performance.now();let res=await fetch(u,init);if(u.endsWith('/pull-updates')){waitHttp++;requestMs.push(performance.now()-t)}if(i===1&&u.endsWith('/v2/pipeline'))pushHttp++;return res}});
  a=await connect(options(1));b=await connect(options(2));c=await connect(options(3));
  for(let i=0;i<3;i++){let t=performance.now();let changed=await c.pull();if(!changed)emptyPullMs.push(performance.now()-t)}
  const ins=await a.prepare('INSERT INTO t VALUES(?,?)'),sel=await c.prepare('SELECT id FROM t WHERE id>? ORDER BY id');
  let pushActive=false;
  function requestPush(){pushDirty=true;if(!pushActive){pushActive=true;pushTask=(async()=>{try{while(pushDirty){pushDirty=false;await a.push();pushes++}}catch(e){error='push: '+e;stopped=true}finally{pushActive=false}})()}}
  let seen=-1;
  const begin=performance.now();
  pullTask=(async()=>{try{while(!stopped){await c.pull();pulls++;let rs=await sel.all(seen);let now=performance.now();for(let row of rs){observed[row.id]=now;seen=Math.max(seen,row.id)}if(writerDone&&seen===ackTimes.length-1)break;if(rs.length===0)await sleep(1)}}catch(e){error='pull: '+e;stopped=true}})();
  const n=6*rate;
  for(let id=0;id<n&&!stopped;id++){
   const due=begin+id*1000/rate;const dt=due-performance.now();if(dt>0)await sleep(dt);
   startTimes[id]=performance.now();await ins.run(id,`v${id}`);ackTimes[id]=performance.now();localDur.push(ackTimes[id]-startTimes[id]);requestPush();
  }
  const writeEnd=performance.now();writerDone=true;
  await pushTask;
  let limit;await Promise.race([pullTask,new Promise((_,reject)=>limit=setTimeout(()=>reject(Error('30s convergence deadline')),30000))]);clearTimeout(limit);stopped=true;
  await b.pull();
  let lags=[],total=[];for(let i=rate;i<ackTimes.length;i++){if(observed[i]!==undefined){lags.push(Math.max(0,observed[i]-ackTimes[i]));total.push(observed[i]-startTimes[i])}}
  const p=(xs,q)=>{xs=xs.slice().sort((a,b)=>a-b);return xs.length?xs[Math.ceil(q*xs.length)-1]:null};
  let record={ver,rtt,rate,repeat,ping,committed:ackTimes.length,measured:lags.length,missing:Math.max(0,ackTimes.length-rate-lags.length),actualRate:ackTimes.length/((writeEnd-begin)/1000),writeDurationMs:writeEnd-begin,ackToVisibleP50:p(lags,.5),ackToVisibleP99:p(lags,.99),startToVisibleP50:p(total,.5),startToVisibleP99:p(total,.99),localCommitP50:p(localDur,.5),localCommitP99:p(localDur,.99),pushes,pulls,pushHttp,waitHttp,emptyPullMs,error};
  await writeFile(`${dir}/samples.json`,JSON.stringify({record,ackTimes,startTimes,observed}));return record;
 }finally{stopped=true;for(let d of [a,b,c])if(d)try{await d.close()}catch{}server.kill('SIGINT');await Promise.race([new Promise(r=>server.once('exit',r)),sleep(500)]);if(server.exitCode===null)server.kill('SIGKILL');await log.close()}
}
for(let rtt of [0,70,150])for(let rate of [100,1000])for(let repeat=1;repeat<=3;repeat++){
 if(only&&!`${rtt}-${rate}-${repeat}`.startsWith(only))continue;
 try{let x=await run(rtt,rate,repeat);records.push(x);console.log(JSON.stringify(x))}catch(e){let x={ver,rtt,rate,repeat,error:String(e),stack:e.stack};records.push(x);console.log(JSON.stringify(x))}
 await writeFile(`${root}/lag${ver}.json`,JSON.stringify(records,null,2));
}

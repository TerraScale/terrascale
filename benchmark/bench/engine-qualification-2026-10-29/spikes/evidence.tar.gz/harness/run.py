import subprocess,os,json,time,threading,hashlib,urllib.request,socket,statistics,sys,traceback
from pathlib import Path
R=Path('/home/mariogk/spikes/sql-repl-20261029'); TICKS=621355968000000000
class RPC:
 def __init__(self,path,host='beta',url=None,mvcc=False):
  self.host=host;self.last_ticks=0;self.lock=threading.Lock();self.log=open(R/(Path(path).stem+'-'+host+'.log'),'a')
  args=['dotnet',str(R/'bin/Release/net11.0/Probe.dll'),str(path)]+([url]+(['mvcc'] if mvcc else []) if url else [])
  if host!=socket.gethostname():args=['ssh','-o','BatchMode=yes',host]+args
  self.p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True,bufsize=1)
  ready=self.p.stdout.readline();self.ready=json.loads(ready) if ready else {'startup_error':'no stdout; '+str(self.p.poll())}
  if 'startup_error' in self.ready:raise RuntimeError(self.ready)
 def call(self,op,**kw):
  with self.lock:
   self.p.stdin.write(json.dumps(dict(op=op,**kw))+'\n');self.p.stdin.flush();s=self.p.stdout.readline()
   if not s:raise RuntimeError('child EOF '+str(self.p.poll()))
   r=json.loads(s)
   self.last_ticks=r.get('ticks',0)
   if not r.get('ok'):raise RuntimeError(r.get('error',str(r)))
   return r
 def sql(self,s):return self.call('sql',sql=s)['result']
 def sqls(self,s):return self.call('batch',sqls=s)['result']
 def close(self):
  if self.p.poll() is None:
   try:self.call('exit')
   except:pass
  try:self.p.wait(timeout=5)
  except:self.p.kill();self.p.wait()
  self.log.close()
class Server:
 def __init__(self,path,v='0.8.2',port=None):
  self.path=path;self.v=v
  if port is None:
   s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
  self.port=port;self.url='http://127.0.0.1:'+str(port);self.log=open(R/(Path(path).stem+'-server.log'),'a')
  self.start()
 def start(self):
  exe=R/('cli-'+self.v)/'turso_cli-x86_64-unknown-linux-gnu/tursodb'
  self.p=subprocess.Popen([str(exe),str(self.path),'--sync-server','127.0.0.1:'+str(self.port)],stdout=self.log,stderr=self.log)
  for k in range(100):
   try:self.sql('SELECT 1');return
   except Exception:
    if self.p.poll()!=None:raise RuntimeError('server exited '+str(self.p.returncode))
    time.sleep(.05)
  raise RuntimeError('server failed to listen')
 def sqls(self,ss):
  body={'requests':[{'type':'execute','stmt':{'sql':s}} for s in ss]}
  req=urllib.request.Request(self.url+'/v2/pipeline',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
  data=json.load(urllib.request.urlopen(req,timeout=20));result=None
  for r in data['results']:
   if r['type']!='ok':raise RuntimeError(r)
   out=r['response']['result'];result=[[cell.get('value') for cell in row] for row in out.get('rows',[])]
  return result
 def sql(self,s):return self.sqls([s])
 def close(self):
  if self.p.poll() is None:self.p.terminate();self.p.wait(timeout=5)
 def done(self):self.close();self.log.close()
def drain(h,r,after):
 while True:
  rows=h.call('cdc',after=after)['result']
  if not rows:return after
  after=r.call('apply',rows=rows)['result']
def digest(db):
 tables=db.sql("SELECT name FROM sqlite_schema WHERE type='table' AND name IN ('items','parent') ORDER BY name")
 h=hashlib.sha256();counts={}
 for (table,) in tables:
  rows=db.sql('SELECT * FROM '+table+' ORDER BY id');counts[table]=len(rows)
  # Normalize HTTP Hrana integers (strings) to match typed ADO integers.
  rows=[[int(c) if isinstance(c,str) and c.lstrip('-').isdigit() else c for c in row] for row in rows]
  h.update(json.dumps([table,rows],separators=(',',':'),ensure_ascii=False).encode())
 return {'sha256':h.hexdigest(),'counts':counts}
def correct(kind,rep):
 prefix=f'correct-valid-{kind}-{rep}';h=r=None;out={'kind':kind,'repeat':rep}
 try:
  h=Server(R/(prefix+'-home.db')) if kind=='sync' else RPC(R/(prefix+'-home.db'))
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  r=RPC(R/(prefix+'-rep.db'),url=h.url if kind=='sync' else None)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)')
  h.sql('PRAGMA foreign_keys=ON')
  h.sqls(['CREATE TABLE parent(id INTEGER PRIMARY KEY, name TEXT UNIQUE)','CREATE TABLE items(id INTEGER PRIMARY KEY, parent_id INTEGER REFERENCES parent(id), name TEXT UNIQUE, val INTEGER)','INSERT INTO parent VALUES '+','.join(f"({i},'p{i}')" for i in range(1,101))])
  for start in range(1,100001,1000):h.sql('INSERT INTO items VALUES '+','.join(f"({i},{(i-1)%100+1},'i{i}',{i*3})" for i in range(start,start+1000)))
  out['initial']=digest(h)
  failures={}
  for name,sql in [('unique',"INSERT INTO items VALUES(100001,1,'i1',0)"),('fk',"INSERT INTO items VALUES(100001,999,'bad-fk',0)")]:
   try:h.sql(sql);failures[name]='ACCEPTED INVALID'
   except Exception as e:failures[name]=str(e)[:300]
  out['constraints']=failures
  h.sqls(['UPDATE items SET val=val+1 WHERE id%10=0','DELETE FROM items WHERE id%20=1','BEGIN IMMEDIATE',"INSERT INTO parent VALUES(101,'txn-parent')","INSERT INTO items VALUES(100002,101,'txn-child',42)",'UPDATE items SET val=77 WHERE id=2','COMMIT','BEGIN IMMEDIATE',"INSERT INTO items VALUES(100003,1,'rollback',0)",'ROLLBACK'])
  if kind=='sync':r.call('pull');after=0
  else:after=drain(h,r,0)
  out['dml_home']=digest(h);out['dml_replica']=digest(r);out['dml_match']=out['dml_home']==out['dml_replica']
  h.sql('ALTER TABLE items ADD COLUMN extra TEXT DEFAULT \'added\'');h.sql('CREATE INDEX idx_items_val ON items(val)')
  try:
   if kind=='sync':r.call('pull')
   else:after=drain(h,r,after)
   out['ddl_replica']=digest(r);out['ddl_home']=digest(h);out['ddl_match']=out['ddl_home']==out['ddl_replica'];out['index']=r.sql("SELECT name FROM sqlite_schema WHERE name='idx_items_val'")
  except Exception as e:out['ddl_error']=str(e)
 except Exception as e:out['error']=str(e);out['trace']=traceback.format_exc()
 finally:
  if r:r.close()
  if h:h.done() if kind=='sync' else h.close()
 return out

def clock_offset(r):
 samples=[]
 for _ in range(21):
  t0=time.time_ns()/100;v=r.call('clock')['result']-TICKS;t1=time.time_ns()/100;samples.append((t1-t0,v-(t0+t1)/2))
 best=min(samples);return {'offset_ticks':best[1],'half_rtt_ms':best[0]/20000,'samples':21}
def bench(kind,host,rate,rep,seconds=10):
 prefix=f'bench-final-{kind}-{host}-{rate}-{rep}';h=r=None;tunnel=None;err=[];out={'kind':kind,'host':host,'rate':rate,'repeat':rep}
 stop=threading.Event();lock=threading.Lock();last=0;delays=[];after=0;slow=[]
 try:
  h=Server(R/(prefix+'-home.db')) if kind=='sync' else RPC(R/(prefix+'-home.db'))
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sql('CREATE TABLE samples(id INTEGER PRIMARY KEY, stamp INTEGER)')
  url=None
  if kind=='sync':
   url=h.url
   if host!='beta':
    targetport=h.port+1000 if h.port<64000 else h.port-1000
    tunnel=subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ExitOnForwardFailure=yes','-N','-R',f'127.0.0.1:{targetport}:127.0.0.1:{h.port}',host],stderr=subprocess.DEVNULL)
    time.sleep(.3);url='http://127.0.0.1:'+str(targetport)
  r=RPC(R/(prefix+'-rep.db'),host=host,url=url)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)');after=drain(h,r,0)
  else:r.call('pull')
  offset=clock_offset(r);out['clock']=offset
  def tail():
   nonlocal last,after
   try:
    while not stop.is_set():
     ship_start=time.perf_counter()
     if kind=='sync':r.call('pull')
     else:after=drain(h,r,after)
     applied=r.last_ticks-offset['offset_ticks']
     ship_ms=(time.perf_counter()-ship_start)*1000
     q_start=time.perf_counter()
     rows=r.call('sql',sql=f'SELECT id,stamp FROM samples WHERE id>{last} ORDER BY id')
     q_ms=(time.perf_counter()-q_start)*1000
     if ship_ms>100 or q_ms>100:slow.append({'ship_ms':round(ship_ms,3),'query_ms':round(q_ms,3),'through':last})
     for idx,stamp in rows['result']:delays.append((applied-stamp)/10000);last=idx
     time.sleep(.001)
   except Exception as e:err.append(str(e));stop.set()
  th=threading.Thread(target=tail);th.start()
  batch=10 if rate==200 else 100;interval=batch/rate;start=time.monotonic();n=0;commits=[]
  for step in range(int(seconds/interval)):
   due=start+step*interval
   delay=due-time.monotonic()
   if delay>0:time.sleep(delay)
   if stop.is_set():break
   stamp=TICKS+time.time_ns()//100;t0=time.monotonic()
   h.sqls(['BEGIN IMMEDIATE','INSERT INTO samples VALUES '+','.join(f'({n+i+1},{stamp})' for i in range(batch)),'COMMIT'])
   commits.append((time.monotonic()-t0)*1000);n+=batch
  elapsed=time.monotonic()-start
  until=time.monotonic()+20
  while last<n and time.monotonic()<until and not stop.is_set():time.sleep(.01)
  stop.set();th.join(timeout=25)
  def p(xs,q):return sorted(xs)[min(len(xs)-1,int(q*len(xs)))] if xs else None
  out.update(writes=n,applied=last,samples=len(delays),seconds=elapsed,achieved_writes_s=n/elapsed,batch=batch,p50_ms=p(delays,.5),p99_ms=p(delays,.99),max_ms=max(delays) if delays else None,min_ms=min(delays) if delays else None,commit_p50_ms=p(commits,.5),commit_p99_ms=p(commits,.99),errors=err,slow_operations=slow,measurement='apply_completion',end_clock=clock_offset(r))
 except Exception as e:out['error']=str(e);out['trace']=traceback.format_exc()
 finally:
  stop.set()
  if r:r.close()
  if h:h.done() if kind=='sync' else h.close()
  if tunnel:tunnel.terminate();tunnel.wait(timeout=5)
 return out

def save(x):
 print(json.dumps(x),flush=True)
 with open(R/'results.jsonl','a') as f:f.write(json.dumps(x)+'\n')
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='correct':
  for kind in ['cdc','sync']:
   for rep in range(1,4):save(correct(kind,rep))
 if mode=='bench':
  for kind in ['cdc','sync']:
   for host in ['beta','delta','mariogk-dev']:
    for rate in [200,2000]:
     for rep in range(1,4):save(bench(kind,host,rate,rep))


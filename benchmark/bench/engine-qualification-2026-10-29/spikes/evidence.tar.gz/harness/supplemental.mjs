import {readFile,writeFile} from 'node:fs/promises';
let s=await readFile('cases.mjs','utf8');
s=s.replace('const cases={',`const cases={
 async pullConflict(s){
  await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,email TEXT UNIQUE)');
  let a=await s.client(1),skip=false,calls=[];
  let b=await s.client(2,{transform:m=>{calls.push({...m,skipped:skip}); return skip&&m.tableName==='t'?{operation:'skip'}:null}});
  let c=await s.client(3);
  await a.exec("INSERT INTO t VALUES('R1','same@local')");await b.exec("INSERT INTO t VALUES('R2','same@local')");await a.push();
  let firstPull=await attempt(()=>b.pull());let localAfterError=await attempt(()=>rows(b,'SELECT * FROM t'));
  skip=true;let policyPull=await attempt(()=>b.pull());let localAfterPolicy=await attempt(()=>rows(b,'SELECT * FROM t'));
  return {firstPull,localAfterError,policyPull,localAfterPolicy,calls,home:await s.home('SELECT * FROM t')};
 },
 async fkDefault(s){
  let defaultFk=await s.home('PRAGMA foreign_keys');await s.home('CREATE TABLE p(id INTEGER PRIMARY KEY)');await s.home('CREATE TABLE c(id TEXT PRIMARY KEY,pid INTEGER REFERENCES p(id))');await s.home('INSERT INTO p VALUES(1)');let a=await s.client(1),b=await s.client(2),c=await s.client(3);for(let d of [a,b,c])await d.exec('PRAGMA foreign_keys=ON');await a.exec('DELETE FROM p WHERE id=1');await b.exec("INSERT INTO c VALUES('child',1)");await a.push();let push=await attempt(()=>b.push());return {defaultFk,push,homeParent:await s.home('SELECT * FROM p'),homeChild:await s.home('SELECT * FROM c'),check:await s.home('PRAGMA foreign_key_check')};
 },
 async fkReverse(s){
  await s.home('PRAGMA foreign_keys=ON');await s.home('CREATE TABLE p(id INTEGER PRIMARY KEY)');await s.home('CREATE TABLE c(id TEXT PRIMARY KEY,pid INTEGER REFERENCES p(id))');await s.home('INSERT INTO p VALUES(1)');let a=await s.client(1),b=await s.client(2),c=await s.client(3);for(let d of [a,b,c])await d.exec('PRAGMA foreign_keys=ON');await a.exec('DELETE FROM p WHERE id=1');await b.exec("INSERT INTO c VALUES('child',1)");await b.push();let push=await attempt(()=>a.push()),retry=await attempt(()=>a.push()),pull=await attempt(()=>a.pull());return {push,retry,pull,homeParent:await s.home('SELECT * FROM p'),homeChild:await s.home('SELECT * FROM c'),localParent:await rows(a,'SELECT * FROM p')};
 },
`);
s=s.replace('cases'+ '${ver}' + '.json','supplemental'+ '${ver}' + '.json');
await writeFile('supplemental-run.mjs',s);

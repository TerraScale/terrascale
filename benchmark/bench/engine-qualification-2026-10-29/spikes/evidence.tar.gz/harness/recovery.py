from run import *
import base64,shutil

def rowsig(db):
 rows=db.sql('SELECT * FROM t ORDER BY id');rows=[[int(x) if isinstance(x,str) and x.isdigit() else x for x in row]for row in rows]
 return {'rows':len(rows),'sha256':hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()}
def recover(kind,rep):
 prefix=f'recovery-final-{kind}-{rep}';hp=R/(prefix+'-home.db');rp=R/(prefix+'-rep.db');h=r=None;out={'kind':kind,'repeat':rep,'profile':'prefetched-apply'}
 try:
  h=Server(hp) if kind=='sync' else RPC(hp)
  if kind=='cdc':h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sql('CREATE TABLE t(id INTEGER PRIMARY KEY,val TEXT)');h.sql("INSERT INTO t VALUES(1,'base')")
  r=RPC(rp,url=h.url if kind=='sync' else None)
  if kind=='cdc':r.sql('CREATE TABLE _spike_cursor(id INTEGER PRIMARY KEY,seq INTEGER)');after=drain(h,r,0)
  else:r.call('pull')
  for start in range(2,10002,1000):h.sql('INSERT INTO t VALUES '+','.join(f"({i},'v{i}')"for i in range(start,start+1000)))
  packet=h.call('cdc',after=after)['result'] if kind=='cdc' else None
  errors=[];kill_started=time.monotonic()
  def pending():
   try:
    if kind=='sync':r.call('pull')
    else:r.call('apply',rows=packet)
   except Exception as e:errors.append(str(e))
  t=threading.Thread(target=pending);t.start();time.sleep(.050 if kind=='cdc' else .001);was_running=t.is_alive();r.p.kill();r.p.wait();t.join(timeout=5);r.log.close()
  out['kill_in_operation']=was_running;out['killed_returncode']=r.p.returncode;r=None
  h.sql("INSERT INTO t VALUES(20000,'offline')")
  r=RPC(rp,url=h.url if kind=='sync' else None)
  resume=time.monotonic()
  if kind=='sync':r.call('pull')
  else:
   cursor=r.sql('SELECT seq FROM _spike_cursor WHERE id=1');after=cursor[0][0]if cursor else 0;after=drain(h,r,after);out['persisted_resume_cursor']=cursor
  out['replica_resume_ms']=(time.monotonic()-resume)*1000;out['replica_home']=rowsig(h);out['replica_after_restart']=rowsig(r);out['replica_restart_match']=out['replica_home']==out['replica_after_restart']
  # Abrupt home termination, after an acknowledged committed write.
  h.sql("INSERT INTO t VALUES(20001,'before-home-kill')")
  if kind=='sync':h.p.kill();h.p.wait();h.start()
  else:h.p.kill();h.p.wait();h.log.close();h=RPC(hp);h.sql("PRAGMA capture_data_changes_conn('after')")
  h.sql("INSERT INTO t VALUES(20002,'after-home-kill')")
  if kind=='sync':r.call('pull')
  else:after=drain(h,r,after)
  out['home_restart_home']=rowsig(h);out['home_restart_replica']=rowsig(r);out['home_restart_match']=out['home_restart_home']==out['home_restart_replica']
  if kind=='cdc':
   h.sql("INSERT INTO t VALUES(20003,'malformed-transport-test')");packet=h.call('cdc',after=after)['result'];bad=json.loads(json.dumps(packet));bad[0][4]=base64.b64encode(b'\xff').decode();before=rowsig(r);cursorbefore=r.sql('SELECT * FROM _spike_cursor')
   try:r.call('apply',rows=bad);out['malformed']='ACCEPTED'
   except Exception as e:out['malformed']='REFUSED: '+str(e)
   out['malformed_atomic']=before==rowsig(r)and cursorbefore==r.sql('SELECT * FROM _spike_cursor');after=drain(h,r,after)
  r.close();r=None
  # Corrupt this scratch replica's database header after closing its owner.
  with open(rp,'r+b')as f:f.write(b'CORRUPT-SPIKE!!!\0');f.flush();os.fsync(f.fileno())
  try:
   r=RPC(rp,url=h.url if kind=='sync' else None);r.sql('SELECT count(*) FROM t');out['corruption']='ACCEPTED'
  except Exception as e:out['corruption']='REFUSED: '+str(e)[:800]
 except Exception as e:out['error']=str(e);out['trace']=traceback.format_exc()
 finally:
  if r:r.close()
  if h:h.done()if kind=='sync'else h.close()
 return out
if __name__=='__main__':
 for kind in ['cdc','sync']:
  for rep in range(1,4):
   x=recover(kind,rep);print(json.dumps(x),flush=True)
   with open(R/'recovery.jsonl','a')as f:f.write(json.dumps(x)+'\n')


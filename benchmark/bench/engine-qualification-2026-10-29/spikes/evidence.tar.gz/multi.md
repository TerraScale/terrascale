# Turso Sync hub-and-spoke multi-writer spike — 2026-10-29

DECISION: Do not make locally acknowledged, asynchronously pushed writes the default SQL consistency model. Reason: both releases lose globally acknowledged business intent, collide on generated integer primary keys, and double-apply trigger effects; the requested CLI authority can partially commit a failed push and subsequently discard its rejected row. Keep home-authoritative transactions as the default. Consider a restricted, explicitly provisional local-writes mode only after the rejection/atomicity and trigger blockers are fixed.

## Scope and reproducibility

Read the SQL-only research note in this directory. Experiments ran on **mariogk-dev**, selected with `ts-host -v`: load/CPU scores delta 0.099, mariogk-dev 0.071, beta 0.142; 46 visible CPUs, about 22 GiB available memory. Node v24.22.2, NixOS Linux 7.3.0 x86_64. These are shared-host experiments, not isolated-capacity production benchmarks.

| Component | Exact version / identity |
|---|---|
| v0.8.2 source | `5d68fe09c36149d395cbf870bf5c25b2e5970157` |
| v0.8.3 source | `29ab7747f979722eedde051301cdf2cacb53a8b4` |
| main source inspected | `3c572612267b923360dfadb64e07fe5150d9ae9a` (snapshot fetched for this spike; not a claim about future main) |
| JS clients | Official `@tursodatabase/sync`, `sync-common`, `database-common`, and Linux native sync module explicitly pinned together to 0.8.2 or 0.8.3; serverless transitive dependency 0.2.4 was not used for local writes |
| CLI v0.8.2 SHA-256 | `e973cccf573ca6cc44a2f7b0db36c47ef319c6d2c29b17d1eec9aba37c1e95fb` |
| CLI v0.8.3 SHA-256 | `8125a4aa4bdf7deb316498e24d2610f1ac4ea084421273a7965bad9e91437841` |
| Release archives | Downloaded official Linux x86_64 artifacts; archive hashes matched each release's published `.sha256` file |
| TerraScale vendor source read | `git show origin/main:src/vendor/Turso.Data.Sqlite/...`, origin/main `4bacd8a818cff3fab76f3f0558bdc4585361e617` |

Each case used a fresh local database H served by the matching release's `tursodb H.db --sync-server 127.0.0.1:<ephemeral-port>`, and three independent on-disk sync clients R1/R2/R3. H was queried independently through `/v2/pipeline`. H setup and verification requests carried only synthetic data. Local write completion preceded explicit pushes. Semantic cases used an identity transform to record mutation images, except where a rewrite/skip is explicitly described; baseline lag used no transform. Case outcomes are observations on **both release binaries**, not runtime tests of main or of Turso Cloud. No paid infrastructure, OCI resources, credentials, PRs, or serving databases were involved.

A preliminary harness bug tried to JSON-parse an `undefined` successful return and mislabeled some successful calls as errors. It was fixed (`undefined` → `null`) and the affected v0.8.2 cases rerun against fresh databases. The final evidence below is from corrected runs. Expected conflict exceptions are case results, not provider/tool retry failures. An additional open-loop harness attempt reused one prepared statement concurrently and failed with a local UNIQUE error on each release. Those two identical failures ended that approach. The corrected open-loop harness serializes statement execution while allowing arrivals to queue; the unchanged failing approach was not retried.

## Source: what a push actually sends

1. **CDC → generated SQL, not the original user statements or WAL pages.** Sync connections enable connection-scoped full CDC ([`sync/engine/src/database_tape.rs:31` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_tape.rs#L31); [main:31](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_tape.rs#L31) and [`sync/engine/src/database_tape.rs:172` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_tape.rs#L172); [main:172](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_tape.rs#L172)). Push scans the CDC tape after the authority's `(client_id, pull_gen, change_id)` watermark and creates a generator with `use_implicit_rowid: false` ([`sync/engine/src/database_sync_operations.rs:2876` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L2876); [main:2913](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L2913), especially 2885–2920). It serializes a JSON Hrana batch to `POST /v2/pipeline`, containing SQL text plus positional typed values ([`sync/engine/src/database_sync_operations.rs:2992` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L2992); [main:3029](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3029); [`sync/engine/src/database_sync_operations.rs:3667` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3667); [main:3704](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3704)). Pull is asymmetric: this CLI serves WAL page updates via `/pull-updates`, with logical MVCC streams also implemented but not selected in these default WAL-mode runs ([`cli/sync_server.rs:589` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/cli/sync_server.rs#L589); [main:589](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/cli/sync_server.rs#L589)).
2. **Ordinary UPDATEs send changed columns, not the whole row.** The CDC update bitmap selects `SET` columns; row identity comes from the before-image primary key, with NULL-safe `IS` predicates. The bound values are new values, not expressions such as `balance - 80`; original non-key WHERE conditions and the reads that informed the transaction are not re-executed at H. A table with no declared PK falls back to an implicit-rowid predicate ([`sync/engine/src/database_replay_generator.rs:169` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L169); [main:169](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L169), [`sync/engine/src/database_replay_generator.rs:341` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L341); [main:341](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L341), [`sync/engine/src/database_replay_generator.rs:451` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L451); [main:451](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L451)). Without an update bitmap, the code falls back to an upsert of the after image. INSERT sends all writable columns present in its captured image and uses `ON CONFLICT(<declared PK>) DO UPDATE SET` for those columns ([`sync/engine/src/database_replay_generator.rs:514` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L514); [main:514](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L514)). Thus UPDATE/UPDATE on disjoint columns merges by default, whereas colliding INSERTs at the same PK replace all captured column values. DELETE sends an identity-based DELETE ([`sync/engine/src/database_replay_generator.rs:605` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L605); [main:605](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L605)).
3. **Implicit rowids are not a distributed key allocator.** Push omits the implicit rowid from INSERT when there is no declared PK, allowing H to allocate another rowid. An explicit `INTEGER PRIMARY KEY`, including AUTOINCREMENT, is sent as an ordinary PK value and collides across replicas. The replay code's `INSERT OR REPLACE` branch is conditional on implicit-rowid preservation; it is not the default logical push policy ([`sync/engine/src/database_replay_generator.rs:514` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L514); [main:514](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L514), 559–602).
4. **Transaction packaging is not an unconditional atomicity guarantee.** A push starts `BEGIN IMMEDIATE`, creates the bookkeeping table, applies generated mutations, advances the watermark, then sends COMMIT ([`sync/engine/src/database_sync_operations.rs:3007` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3007); [main:3044](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3044), [`sync/engine/src/database_sync_operations.rs:3178` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3178); [main:3215](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3215)). The default collects the complete change set in one HTTP batch; `pushOperationsThreshold` can split batches at local transaction boundaries, never within one local transaction ([`sync/engine/src/database_sync_operations.rs:2919` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L2919); [main:2956](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L2956)). Multiple local transactions may therefore share a remote transaction. Every step after BEGIN is gated only on `NOT is_autocommit`, not on previous-step success. The CLI continues after statement errors and reports per-step errors; it does not explicitly roll back the batch ([`cli/sync_server.rs:454` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/cli/sync_server.rs#L454); [main:454](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/cli/sync_server.rs#L454)). A UNIQUE/FK statement abort can leave the transaction open, so subsequent valid steps, the watermark, and COMMIT run. The experiments prove partial application, including within one original local transaction.
5. **The client discovers SQL rejection after H may already have committed.** `sql_execute_http` parses per-step errors and throws for the first unignored one ([`sync/engine/src/database_sync_operations.rs:3705` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3705); [main:3742](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3742)). `push_changes_to_remote` updates local success metadata only after the push returns successfully ([`sync/engine/src/database_sync_engine.rs:3165` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L3165); [main:3166](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L3166)). There is no rejection-resolution callback or automatic SQL-conflict retry in this return path. Transport retry wrappers do not turn an HTTP-200 Hrana batch error into a transaction-level reconciliation policy. With this CLI, H has nevertheless advanced its client watermark. The next push reads that watermark, sends no rejected mutation again, and can return success; a later pull removes that mutation from local state. `cdcOperations` was temporarily misleading (three pending after rejection, zero after pull). Do not infer Turso Cloud's server rollback policy from this local CLI result; Cloud was not exercised.
6. **There is no HLC conflict ordering here.** Push order at H determines competing UPDATE values. `changeTime` is provided to the transform but the default generated SQL does not compare it against a remote version. A stale replica's older edit can arrive later and overwrite a newer edit. H serializes requests; that does not serialize the clients' earlier reads and decisions.

### Pull/replay mechanics

The WAL path takes an internal connection/session, collects local CDC, rolls local WAL changes back to the synchronized watermark (including the revert WAL), and applies remote pages. It finds the authority's watermark for this client and replays only still-unpushed local changes; already pushed changes must not be replayed over newer remote values. The source labels rollback as Phase 1 ([`sync/engine/src/database_sync_engine.rs:2338` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L2338); [main:2339](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L2339)), remote application as Phase 2 ([`sync/engine/src/database_sync_engine.rs:2371` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L2371); [main:2372](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L2372)), and local replay as Phase 6 ([`sync/engine/src/database_sync_engine.rs:2780` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L2780); [main:2781](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L2781)). Replay enables CDC again so surviving local writes can be pushed later. The replay floor uses both authority bookkeeping and recorded successful-push hints ([`sync/engine/src/database_sync_engine.rs:2687` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L2687); [main:2688](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L2688)).

The tape replays SQL/row operations and propagates database errors ([`sync/engine/src/database_tape.rs:627` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_tape.rs#L627); [main:627](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_tape.rs#L627)). A replay constraint failure returns `failed to replay local change after remote apply`, rather than silently choosing a winner ([`sync/engine/src/database_sync_engine.rs:2921` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L2921); [main:2922](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L2922)). The pull-before-push UNIQUE experiment below retained the previous local row after this error and recovered when an explicit skip policy was enabled. This differs materially from the push-first case, in which H's advanced watermark caused the rejected mutation to disappear on pull. Convergence is conditional on successful replay or an explicit policy.

### Transform/conflict hooks, including the .NET gap

The JS configuration option is **`transform` on the database options**; `db.push()` itself has no transform argument. The synchronous callback receives `changeTime`, table name, rowid, operation, before/after column maps and `updates`. It returns `null` (keep), `{operation:'skip'}`, or `{operation:'rewrite', stmt:{sql,values}}`. See [`bindings/javascript/sync/packages/common/types.ts:27` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/javascript/sync/packages/common/types.ts#L27); [main:27](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/javascript/sync/packages/common/types.ts#L27), [`bindings/javascript/sync/packages/common/types.ts:29` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/javascript/sync/packages/common/types.ts#L29); [main:29](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/javascript/sync/packages/common/types.ts#L29), [`bindings/javascript/sync/packages/common/types.ts:100` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/javascript/sync/packages/common/types.ts#L100); [main:100](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/javascript/sync/packages/common/types.ts#L100), and [`bindings/javascript/sync/packages/common/run.ts:87` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/javascript/sync/packages/common/run.ts#L87); [main:87](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/javascript/sync/packages/common/run.ts#L87). Native JS turns this on with `useTransform: opts.transform != null` ([`bindings/javascript/sync/packages/native/promise.ts:92` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/javascript/sync/packages/native/promise.ts#L92); [main:92](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/javascript/sync/packages/native/promise.ts#L92)).

The engine calls transforms before sending DML, splits callback groups around DDL, and keeps DDL outside the callback ([`sync/engine/src/database_sync_operations.rs:3216` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3216); [main:3253](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3253)). It also calls the same transform during unpushed local replay ([`sync/engine/src/database_sync_engine.rs:2844` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_engine.rs#L2844); [main:2845](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_engine.rs#L2845)). This is a **pre-send/pre-replay transformation hook**, not a server-side callback receiving both competing versions or a notification that H rejected a row. It cannot synchronously inspect H's current row through its argument. A rewrite can send conditional SQL that evaluates the remote row, but conflict metadata/zero-row outcomes need an explicit protocol and durable log.

Verified rewrite: R1 changed `v:0→2`; R2 changed `v:0→3`. Rewriting R2 to `UPDATE t SET v=v+? WHERE id=?`, values `[3,'x']`, produced `v=5` at H and R3, versus the default absolute-value overwrite. This demonstrates a working hook, not general SQL transaction merging. A non-idempotent rewrite also requires authority-side operation deduplication; it may be invoked during local replay as well.

**The .NET path cannot currently use that hook.** Upstream and the TerraScale vendor expose `PushAsync`, long poll and push thresholds, but no transform in `TursoSyncDatabaseOptions` ([`bindings/dotnet/src/Turso.Data/TursoSyncDatabase.cs:188` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/dotnet/src/Turso.Data/TursoSyncDatabase.cs#L188); [main:188](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/dotnet/src/Turso.Data/TursoSyncDatabase.cs#L188); [`bindings/dotnet/src/Turso.Data/TursoSyncDatabaseOptions.cs:99` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/bindings/dotnet/src/Turso.Data/TursoSyncDatabaseOptions.cs#L99); [main:99](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/bindings/dotnet/src/Turso.Data/TursoSyncDatabaseOptions.cs#L99)). SDK-kit hardcodes `use_transform: false` ([`sync/sdk-kit/src/rsapi.rs:255` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/sdk-kit/src/rsapi.rs#L255); [main:255](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/sdk-kit/src/rsapi.rs#L255)) and its `transform` implementation remains `todo!()` ([`sync/sdk-kit/src/sync_engine_io.rs:315` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/sdk-kit/src/sync_engine_io.rs#L315); [main:315](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/sdk-kit/src/sync_engine_io.rs#L315)). Merely adding a C# delegate does not implement the native callback path. The vendor source read via `git show` had the same options and push path.

### DDL propagation

Schema CDC records in `sqlite_schema` become DDL SQL: INSERT → captured CREATE SQL, DELETE → DROP, UPDATE → captured DDL such as ALTER TABLE ([`sync/engine/src/database_replay_generator.rs:341` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L341); [main:341](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L341)). Push rewrites CREATE to `IF NOT EXISTS`, and records **every ALTER ADD COLUMN step** as an ignored-error step ([`sync/engine/src/database_sync_operations.rs:3074` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3074); [main:3111](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3111), [`sync/engine/src/database_sync_operations.rs:3171` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3171); [main:3208](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3208)). The response handler ignores those indexed errors without checking that the failure was specifically a harmless duplicate-column error ([`sync/engine/src/database_sync_operations.rs:3705` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_sync_operations.rs#L3705); [main:3742](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_sync_operations.rs#L3742)). This is not general concurrent schema reconciliation. The replay path also has idempotent DDL handling ([`sync/engine/src/database_replay_generator.rs:736` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/sync/engine/src/database_replay_generator.rs#L736); [main:736](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/sync/engine/src/database_replay_generator.rs#L736)). Runtime proof here covers additive DDL plus a stale-schema writer; destructive migrations and conflicting column definitions remain outside the proven envelope.

Main's relevant push/error construction and generated UPDATE/INSERT policies remain materially the same at the pinned snapshot. v0.8.3 changes logical-MVCC schema-operation ordering relative to 0.8.2; main also changes bootstrap handling and APIs. Those differences do not convert these observed WAL/default-SQL semantics into serializable multi-writer transactions. Main was source-reviewed, not built or runtime-tested.

## Case table: expected versus observed

“Expected” is the property a default SQL user would need, or the explicit hypothesis being tested; it is not an assertion Turso promises that property. H/R1/R2/R3 were separately inspected. Unless stated otherwise, both releases had the same outcome.

| # | Setup / expectation | v0.8.2 observed | v0.8.3 observed | Evidence / implication |
|---|---|---|---|---|
| 1 | Same PK, `R1: a='a1'`, `R2: b='b2'`; expect both edits | H and all clients `(x,a1,b2)` | Same | Wire contains only `SET a=?` or `SET b=?`; no whole-row overwrite for normal UPDATE |
| 2 | R2 edits first; R1 edits later and pushes first; expect edit-time ordering if “newest edit wins” | H goes `newer-edit-R1` → `older-edit-R2` after stale R2 push | Same | All clients end at older R2 value. Arrival ordering, no stale-write detection |
| 3 | Different explicit PKs insert the same UNIQUE email; R2 wraps a valid-before, colliding, valid-after insert in one transaction; expect atomic reject or explicit reconciliation | First R2 push throws UNIQUE. H commits both noncolliding R2 rows and watermark=3; local R2 initially retains all 3 rows. Retry succeeds without replaying rejected row; pull leaves H's R1 row plus before/after | Same | Failed transaction partially applied. Rejected local insert disappears after pull; not a permanently stuck push queue in this order |
| 3b | Pull before push with that duplicate local email; expect a defined conflict policy | Pull throws replay UNIQUE; R2 retains its local row. Switching transform to skip that mutation makes pull succeed and adopt R1 | Same | Concrete recovery through hook, but application must identify/reconcile the rejected intent |
| 4 | FK ON at H and clients. R1 deletes parent; R2 inserts child offline; delete pushed first | Child push throws FK, retry succeeds, pull removes locally acknowledged child | Same | H has neither parent nor child; both original local operations had succeeded |
| 4b | Same operations, child pushed first | Parent-delete push throws FK; retry/pull restore parent at R1 | Same | Outcome depends on push order; losing delete is undone locally |
| 4c | H left at its default FK setting; clients enable FK | H's `foreign_keys=0`; both pushes succeed, H has child(pid=1) and no parent | Same | Enforcement must be enabled on every H execution connection. `foreign_key_check` returned no rows even for this visibly orphaned state; that probe alone is insufficient here |
| 5 | Initial balance 100 with `CHECK(balance>=0)`; each regional transaction reads 100, approves debit 80, writes balance=20 and unique ledger row | Both approve. H balance 20; ledger `[80,80]` | Same | Lost debit **80**, total authorized 160 from 100 (economic shortfall **60**). SQL CHECK remains satisfied; original read/decision is not re-executed at H |
| 6 | R1 `ALTER TABLE ADD COLUMN extra TEXT DEFAULT 'd'` and sets extra=R1; stale R2 updates old v=R2 | Both pushes/pulls succeed; H and all clients `(x,R2,R1)` | Same | Wire carries actual ALTER plus changed-column UPDATEs. This additive case works |
| 7 | R3 partitioned ≥60s while R1/R2/R3 each insert distinct keys at nominal 10/s; expect eventual convergence after reconnect | See partition evidence below | See below | Distinct keys, no constraints/trigger conflicts; convergence does not imply consistency of conflicting transactions |
| 8 | Push requested after each commit, R3 continuous `pull()` with 5s long-poll timeout; target 100 / 1,000 writes/s at 0 / 70 / 150ms RTT | Three repeats below | Three repeats below | CLI ignores long-poll timeout. High-rate writer saturation is reported explicitly |
| 9 | Concurrent automatic IDs; expect distinct durable identities | AUTOINCREMENT and explicit INTEGER PK both allocate id=1 on both clients; later push overwrites R1 with R2. No-PK table has both rows at H rowids 1,2. UUIDv4 and two distinct ULID-format 26-character keys retain both rows | Same | No-PK local rowid=1 is not stable global identity. ULID test uses two known-distinct format-valid constants, not an entropy/collision-probability benchmark |
| 10 | Same AFTER INSERT trigger locally and at H; one insert should produce one audit event | Local audit has 1 row; after push H and all clients have **2** audit rows | Same | Reproduces [#10147](https://github.com/tursodatabase/turso/issues/10147), still open when fetched. Wire replays audit insert and base-table insert; the latter fires H's trigger again |
| Extra | Transform R2 absolute update into delta addition | H and R3 `v=5` from independent +2/+3 | Same | Hook works, but does not solve global invariant checks or atomic rejects |

### Concrete push/reject evidence

The UNIQUE wire trace on each release contained this one remote transaction (typed args abbreviated):

```text
0 BEGIN IMMEDIATE
1 CREATE TABLE IF NOT EXISTS turso_sync_last_change_id (...)
2 INSERT INTO t(id,email) VALUES('before','before@local') ON CONFLICT(id) DO UPDATE ...
3 INSERT INTO t(id,email) VALUES('R2','same@local') ON CONFLICT(id) DO UPDATE ...
4 INSERT INTO t(id,email) VALUES('after','after@local') ON CONFLICT(id) DO UPDATE ...
5 INSERT INTO turso_sync_last_change_id (...) VALUES(R2-client,0,3) ON CONFLICT ...
6 COMMIT
step_errors = [null,null,null,{message:'UNIQUE constraint failed: t.email',
                              code:'BATCH_STEP_ERROR'},null,null,null]
```

All steps after BEGIN used `{type:'not',cond:{type:'is_autocommit'}}`. H independently returned `[('R1','same@local'),('after','after@local'),('before','before@local')]`. R2 still showed its rejected `('R2','same@local')` locally immediately after rejection; a successful retry and pull replaced it with R1. R2's marker was `(pull_gen=0, change_id=3)`. The retry trace contained a watermark SELECT and an empty BEGIN/bookkeeping/COMMIT batch, not another attempt to insert the losing row.

The trigger trace is equally direct:

```text
local CDC / transform input: INSERT audit(id=1,msg='inserted 1'), INSERT t(id=1,x='a')
push SQL: INSERT audit(...id=1...) ON CONFLICT(id) DO UPDATE ...
          INSERT t(...id=1...) ON CONFLICT(id) DO UPDATE ...
H audit: (1,'inserted 1'), (2,'inserted 1')
```

The trigger compiler also inherits the parent program's CDC configuration: [`core/translate/trigger_exec.rs:577` @ v0.8.2](https://github.com/tursodatabase/turso/blob/5d68fe09c36149d395cbf870bf5c25b2e5970157/core/translate/trigger_exec.rs#L577); [main:586](https://github.com/tursodatabase/turso/blob/3c572612267b923360dfadb64e07fe5150d9ae9a/core/translate/trigger_exec.rs#L586). This tests insert-trigger duplication. It does not test every UPDATE/DELETE trigger, FK action, crash retry, or logical-MVCC configuration.

### Partition proof

- **0.8.2**: offline 60.090s; 601 local inserts per region, total 1803; R3 network override threw `simulated R3 partition`. Reconnect→push R3→pull all→query/hash took **314.7ms**. H/R1/R2/R3 counts were all 1803. All four SHA-256 hashes matched `d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba`.
- **0.8.3**: offline 60.101s; 601 local inserts per region, total 1803; R3 network override threw `simulated R3 partition`. Reconnect→push R3→pull all→query/hash took **502.3ms**. H/R1/R2/R3 counts were all 1803. All four SHA-256 hashes matched `d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba`.

The partition was an application transport partition on R3 (its fetch implementation refused network access), not a whole-host outage. R3 retained 601 rows locally while disconnected. R1/R2 continued to push and periodically pull; R3 continued local commits. No other host/network traffic was changed. The hash covers canonical JSON of `SELECT id,v FROM t ORDER BY id`; this workload's columns are TEXT, so H's typed HTTP rows and client rows were normalized to the same representation.

## Lag: three repeats, local ACK → R3 query visibility

The requested server cannot supply real long polling. Clients were configured with `longPollTimeoutMs:5000`, but empty pulls returned promptly (roughly 7–15ms without netem in the initial runs), and CLI source never uses `req.long_poll_timeout_ms`. The protobuf request does carry the timeout (`database_sync_operations.rs:1905`, main:1942); `cli/sync_server.rs:589` routes directly to an immediate current-WAL response. These measurements therefore use **continuous pulls with long polling requested but ignored**, with a 1ms pause after an empty result. A production long-poll authority is still an unmeasured requirement.

Every local commit immediately requests a push. One in-flight push is allowed per writer; pending requests coalesce into another push. `pushOperationsThreshold` is unset (official default), so a push can collect many committed transactions before sending. R3 pulls and immediately queries newly visible IDs; R2 is connected but idle during lag runs. Thus this measures the R1→H→R3 path with three clients, not simultaneous three-writer throughput.

Each run has one second of warmup and five nominal measured seconds, with 600 total/500 measured rows at 100 rows/s or 6,000 total/5,000 measured rows at 1,000 rows/s. The observation deadline allows drain after the write phase; the high-rate saturated runs take longer than the nominal six seconds to finish commits. p50/p99 are nearest-rank percentiles of per-row monotonic timestamps, local write promise completion → first successful R3 query observation. Start→visibility and local/queued commit timings are retained in the embedded records. No missing observations were excluded: all final runs below observed every measured row. Rows within a ten-row transaction share a commit timestamp and are correlated observations; no statistical confidence interval or significance claim is made.

`unshare -Urn` created a private user/network namespace, brought up only its own loopback, and ran both H and all clients inside it. `tc netem delay 35ms` or `75ms` on that namespace's loopback yields measured ping RTT ≈70ms or ≈150ms; baseline ping was sub-ms. These delays apply to **each client–H leg**, including TCP connection establishment; the CLI closes HTTP connections. No qdisc on the host/serving network was changed. Corrected open-loop and batch runs also recorded netem counters; verify dropped counts in the embedded evidence rather than assuming loss. Delay is not a measured regional topology or an estimate derived from geography.

### Achieved row rates: 100 single-row commits/s and 1,000 rows/s in ten-row commits

A single outstanding official JS write did **not** sustain 1,000 independent one-row commits/s. To measure an actual 1,000 rows/s workload, a separate series uses ten INSERTs per local transaction at 100 commits/s, requesting push after each commit. This transaction-shape difference is explicit; it is not evidence for 1,000 independent transactions/s. The original one-row and queued-arrival results follow separately. Each cell reports **p50, p99 in milliseconds**; slash-separated entries are repeats 1 / 2 / 3, not pooled percentiles. Rate means all local row commits divided by their actual write-phase duration.

| Release | Rows/s target | Rows/commit | Per-leg RTT ms | Repeat 1: p50,p99 | Repeat 2: p50,p99 | Repeat 3: p50,p99 | Achieved rows/s, repeats 1/2/3 |
|---|---:|---:|---:|---:|---:|---:|---|
| 0.8.2 | 100 | 1 | 0 | 47.4, 83.6 | 42.1, 75.6 | 53.0, 93.1 | 100.1 / 100.2 / 100.1 |
| 0.8.2 | 100 | 1 | 70 | 398.6, 596.8 | 406.4, 660.6 | 401.4, 631.2 | 100.1 / 100.2 / 100.1 |
| 0.8.2 | 100 | 1 | 150 | 726.9, 1100.9 | 701.2, 1024.5 | 701.2, 1032.4 | 100.2 / 100.1 / 100.2 |
| 0.8.2 | 1000 | 10 | 0 | 52.4, 84.0 | 44.5, 562.1 | 46.3, 502.5 | 1001.4 / 1001.4 / 1001.7 |
| 0.8.2 | 1000 | 10 | 70 | 652.7, 1052.5 | 706.6, 1061.6 | 668.9, 1073.0 | 1001.6 / 1001.5 / 1001.6 |
| 0.8.2 | 1000 | 10 | 150 | 3275.5, 4565.1 | 3271.5, 4570.5 | 3291.9, 4591.9 | 1001.6 / 1001.5 / 995.0 |
| 0.8.3 | 100 | 1 | 0 | 47.7, 94.6 | 40.7, 94.0 | 44.7, 74.2 | 100.2 / 100.1 / 100.2 |
| 0.8.3 | 100 | 1 | 70 | 401.8, 602.3 | 392.8, 593.6 | 395.9, 590.8 | 100.1 / 100.2 / 100.2 |
| 0.8.3 | 100 | 1 | 150 | 694.2, 1163.5 | 670.3, 986.9 | 736.5, 1296.4 | 100.2 / 100.1 / 100.2 |
| 0.8.3 | 1000 | 10 | 0 | 43.8, 61.7 | 51.9, 1231.6 | 43.5, 74.1 | 1001.6 / 1001.3 / 1001.5 |
| 0.8.3 | 1000 | 10 | 70 | 578.1, 1052.6 | 592.4, 1030.6 | 1229.9, 2454.5 | 1001.5 / 1001.4 / 995.0 |
| 0.8.3 | 1000 | 10 | 150 | 3305.3, 4905.0 | 3112.4, 4403.4 | 3282.3, 4570.8 | 1001.3 / 1001.3 / 1001.4 |

### Single-row transaction saturation diagnostic

The original one-row-commit series paced the next operation after completion. Its nominal 1,000/s target was not achieved, so these are saturation results, not 1,000 completed transactions/s benchmarks. They are essential limits of the tested official-client/default-batch setup. Each run observed 5,000 measured rows after drain. The high-rate runs typically completed only two `push()` calls over the entire write/drain interval; the default path sends the collected change set in one batch while local commits continue. Large CDC batches and client execution queueing are plausible contributors; no profiler run isolates their causal shares. The observation is that fast local acknowledgement did not imply fast remote visibility. Batch thresholds/backpressure are potential mitigations, not proven fixes in this spike.

| Release | RTT ms | Repeat 1: p50,p99 ms | Repeat 2: p50,p99 ms | Repeat 3: p50,p99 ms | Actual one-row commits/s, repeats 1/2/3 |
|---|---:|---:|---:|---:|---|
| 0.8.2 | 0 | 3493.2, 6400.3 | 3569.5, 6570.0 | 4072.9, 7331.4 | 862.9 / 837.8 / 777.7 |
| 0.8.2 | 70 | 5218.5, 7979.1 | 5617.9, 8405.4 | 6126.0, 8956.8 | 907.1 / 898.6 / 871.0 |
| 0.8.2 | 150 | 9428.6, 12687.2 | 9161.3, 12139.0 | 9087.0, 12080.7 | 731.0 / 807.0 / 852.3 |
| 0.8.3 | 0 | 3534.6, 6287.3 | 3499.3, 6276.0 | 3658.8, 6363.2 | 895.8 / 886.0 / 869.3 |
| 0.8.3 | 70 | 6081.1, 8964.6 | 5924.9, 9115.4 | 5416.3, 8551.8 | 841.6 / 810.4 / 823.7 |
| 0.8.3 | 150 | 9142.3, 12491.0 | 9535.5, 12494.8 | 8620.9, 11479.2 | 736.2 / 779.4 / 859.3 |

The additional open-loop attempt queued independent nominal 1,000/s arrivals but serialized execution of the prepared statement. The event loop itself sometimes fell behind, so both actual offered rate and completed rate are reported. This confirms overload/queueing rather than asserting an achieved sustained 1,000-transaction rate. No unchanged retry of the failed concurrent-prepared-statement version was made.

| Release | RTT ms | Offered/s, repeats 1/2/3 | Completed/s, repeats 1/2/3 | Repeat 1: p50,p99 ms | Repeat 2: p50,p99 ms | Repeat 3: p50,p99 ms |
|---|---:|---|---|---:|---:|---:|
| 0.8.2 | 0 | 959.5 / 972.4 / 949.6 | 857.7 / 841.6 / 855.1 | 3580.9, 6423.7 | 3348.4, 5964.7 | 3294.4, 5841.3 |
| 0.8.2 | 70 | 997.4 / 998.7 / 425.6 | 843.1 / 864.5 / 348.9 | 5365.4, 7745.7 | 4125.0, 6392.9 | 15937.4, 18548.8 |
| 0.8.2 | 150 | 896.3 / 936.0 / 947.9 | 872.4 / 881.2 / 862.7 | 5168.3, 7076.5 | 7815.5, 10610.4 | 7306.9, 9705.6 |
| 0.8.3 | 0 | 983.0 / 840.0 / 861.3 | 232.7 / 832.6 / 788.7 | 27668.5, 30471.8 | 3551.3, 6392.8 | 3506.0, 6404.0 |
| 0.8.3 | 70 | 879.0 / 868.2 / 917.7 | 826.9 / 808.3 / 870.7 | 4495.5, 6996.8 | 5108.3, 7150.3 | 5012.0, 6986.2 |
| 0.8.3 | 150 | 902.8 / 845.0 / 913.9 | 814.7 / 786.8 / 880.6 | 8840.4, 11894.3 | 5957.8, 7367.7 | 5929.9, 8721.8 |

```mermaid
xychart-beta
    title "100 single-row commits/s: median of three run p99 values"
    x-axis "RTT per client-home leg" ["0ms", "70ms", "150ms"]
    y-axis "Local ACK to R3 visibility (ms)" 0 --> 1400
    bar [84, 631, 1032]
    bar [94, 594, 1163]
```

First series: 0.8.2; second series: 0.8.3. This is a display summary, not a pooled p99. The table retains every repeat. **The requested under-200ms WAN lag is not established**: even at 100 single-row commits/s, the 70ms and 150ms per-leg setups produced substantially higher p99. A real production authority with long polling, persistent connections and tuned batching needs a new benchmark; these CLI results cannot predict its exact latency.

<details><summary>All final lag run records (including method, rate and netem counters)</summary>

```json
{
  "lag": {
    "082": [
      {
        "ver": "082",
        "rtt": 0,
        "rate": 100,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.040/0.071/0.128/0.040 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.14028888399437,
        "writeDurationMs": 5991.594459,
        "ackToVisibleP50": 47.42665799999986,
        "ackToVisibleP99": 83.59316099999978,
        "startToVisibleP50": 48.99385799999982,
        "startToVisibleP99": 87.21784200000002,
        "localCommitP50": 1.3661889999998493,
        "localCommitP99": 3.7432180000005246,
        "pushes": 261,
        "pulls": 238,
        "pushHttp": 522,
        "waitHttp": 245,
        "emptyPullMs": [
          14.573795999999902,
          10.55314599999997,
          9.177268000000026
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 100,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.033/0.046/0.065/0.013 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15072194583489,
        "writeDurationMs": 5990.970293,
        "ackToVisibleP50": 42.086253999999826,
        "ackToVisibleP99": 75.59834499999852,
        "startToVisibleP50": 43.55608100000063,
        "startToVisibleP99": 76.8622749999995,
        "localCommitP50": 1.3582980000010139,
        "localCommitP99": 4.482754000000568,
        "pushes": 262,
        "pulls": 255,
        "pushHttp": 524,
        "waitHttp": 262,
        "emptyPullMs": [
          13.863146000000597,
          9.509377000000313,
          10.380895999999666
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 100,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.041/0.044/0.047/0.002 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.14629141582658,
        "writeDurationMs": 5991.235337,
        "ackToVisibleP50": 53.019226000000344,
        "ackToVisibleP99": 93.06737700000303,
        "startToVisibleP50": 54.573152000000846,
        "startToVisibleP99": 94.7375060000013,
        "localCommitP50": 1.5653650000022026,
        "localCommitP99": 4.004860999999437,
        "pushes": 256,
        "pulls": 222,
        "pushHttp": 512,
        "waitHttp": 229,
        "emptyPullMs": [
          10.669442000000345,
          10.022608999999647,
          10.320767999999589
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.040/0.049/0.055/0.006 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 862.8734925208017,
        "writeDurationMs": 6953.510627,
        "ackToVisibleP50": 3493.228126000002,
        "ackToVisibleP99": 6400.345603000002,
        "startToVisibleP50": 3494.3111370000006,
        "startToVisibleP99": 6401.373376,
        "localCommitP50": 1.0590049999991606,
        "localCommitP99": 2.3799099999996542,
        "pushes": 2,
        "pulls": 38,
        "pushHttp": 4,
        "waitHttp": 45,
        "emptyPullMs": [
          12.279145000000426,
          10.40586600000097,
          9.986729999996896
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.040/0.044/0.049/0.003 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 837.7743081516157,
        "writeDurationMs": 7161.833373999998,
        "ackToVisibleP50": 3569.4796429999988,
        "ackToVisibleP99": 6569.955864,
        "startToVisibleP50": 3570.7026840000035,
        "startToVisibleP99": 6570.963650999998,
        "localCommitP50": 1.1449780000039027,
        "localCommitP99": 2.643382999995083,
        "pushes": 2,
        "pulls": 37,
        "pushHttp": 4,
        "waitHttp": 44,
        "emptyPullMs": [
          14.105325999997149,
          9.325027999999293,
          10.43248400000084
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.033/0.183/0.474/0.205 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 777.676907451924,
        "writeDurationMs": 7715.286313000004,
        "ackToVisibleP50": 4072.8830739999976,
        "ackToVisibleP99": 7331.373065,
        "startToVisibleP50": 4074.0092189999996,
        "startToVisibleP99": 7332.434570999998,
        "localCommitP50": 1.1936900000000605,
        "localCommitP99": 3.267060999998648,
        "pushes": 2,
        "pulls": 36,
        "pushHttp": 4,
        "waitHttp": 43,
        "emptyPullMs": [
          6.935338000002957,
          12.824786999997741,
          6.44911200000206
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 100,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.095/70.113/70.133/0.015 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.14387272957704,
        "writeDurationMs": 5991.380037999996,
        "ackToVisibleP50": 398.63822100000107,
        "ackToVisibleP99": 596.8428340000028,
        "startToVisibleP50": 399.86603900000046,
        "startToVisibleP99": 598.2197760000054,
        "localCommitP50": 1.2550289999999222,
        "localCommitP99": 3.4764520000026096,
        "pushes": 21,
        "pulls": 39,
        "pushHttp": 42,
        "waitHttp": 46,
        "emptyPullMs": [
          147.60007300000143,
          152.10548500000004,
          149.12867499999993
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 100,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.104/70.125/70.149/0.018 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15945669290643,
        "writeDurationMs": 5990.447829999997,
        "ackToVisibleP50": 406.35500400000456,
        "ackToVisibleP99": 660.5809289999961,
        "startToVisibleP50": 407.53962700000557,
        "startToVisibleP99": 661.9172760000001,
        "localCommitP50": 1.2822850000011385,
        "localCommitP99": 3.204654000001028,
        "pushes": 21,
        "pulls": 38,
        "pushHttp": 42,
        "waitHttp": 45,
        "emptyPullMs": [
          145.27247499999794,
          150.99640699999873,
          151.3454089999941
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 100,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.075/70.085/70.097/0.009 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.14934203117454,
        "writeDurationMs": 5991.052840000004,
        "ackToVisibleP50": 401.44262100000924,
        "ackToVisibleP99": 631.1799030000111,
        "startToVisibleP50": 402.98667700000806,
        "startToVisibleP99": 632.5762329999998,
        "localCommitP50": 1.3615530000097351,
        "localCommitP99": 4.740036999995937,
        "pushes": 21,
        "pulls": 38,
        "pushHttp": 42,
        "waitHttp": 45,
        "emptyPullMs": [
          153.29679300000134,
          151.61808400000155,
          151.93490600000223
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.085/70.092/70.097/0.005 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 907.1377513482615,
        "writeDurationMs": 6614.210456000001,
        "ackToVisibleP50": 5218.456467999989,
        "ackToVisibleP99": 7979.067563999997,
        "startToVisibleP50": 5219.4730439999985,
        "startToVisibleP99": 7980.213478999998,
        "localCommitP50": 1.03629699999874,
        "localCommitP99": 2.3128690000012284,
        "pushes": 2,
        "pulls": 5,
        "pushHttp": 4,
        "waitHttp": 12,
        "emptyPullMs": [
          151.88158099999418,
          150.89648800001305,
          151.9934290000092
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.059/70.081/70.121/0.028 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 898.5608560372195,
        "writeDurationMs": 6677.344065999991,
        "ackToVisibleP50": 5617.865059999996,
        "ackToVisibleP99": 8405.408993000005,
        "startToVisibleP50": 5618.8428970000095,
        "startToVisibleP99": 8406.473922000005,
        "localCommitP50": 1.0247719999897527,
        "localCommitP99": 2.2711160000035306,
        "pushes": 2,
        "pulls": 5,
        "pushHttp": 4,
        "waitHttp": 12,
        "emptyPullMs": [
          145.49681599999894,
          151.61979599999904,
          150.98613599999226
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.068/70.086/70.107/0.016 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 870.9508867460671,
        "writeDurationMs": 6889.022207000002,
        "ackToVisibleP50": 6126.039518000005,
        "ackToVisibleP99": 8956.771682000006,
        "startToVisibleP50": 6127.136283,
        "startToVisibleP99": 8957.756352000011,
        "localCommitP50": 1.0752309999952558,
        "localCommitP99": 2.687290000001667,
        "pushes": 2,
        "pulls": 5,
        "pushHttp": 4,
        "waitHttp": 12,
        "emptyPullMs": [
          153.14559599998756,
          151.7537799999991,
          151.27843700000085
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 100,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.080/150.093/150.104/0.010 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15352844851827,
        "writeDurationMs": 5990.802413999991,
        "ackToVisibleP50": 726.9256299999979,
        "ackToVisibleP99": 1100.8906439999992,
        "startToVisibleP50": 728.0149169999931,
        "startToVisibleP99": 1103.2151729999896,
        "localCommitP50": 1.1456449999968754,
        "localCommitP99": 3.4574739999952726,
        "pushes": 11,
        "pulls": 20,
        "pushHttp": 22,
        "waitHttp": 27,
        "emptyPullMs": [
          307.0954480000073,
          312.32852199999616,
          314.0736869999964
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 100,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.079/150.082/150.088/0.004 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.14258095383902,
        "writeDurationMs": 5991.45732300001,
        "ackToVisibleP50": 701.2368080000015,
        "ackToVisibleP99": 1024.4656390000018,
        "startToVisibleP50": 702.5986550000089,
        "startToVisibleP99": 1026.2122929999896,
        "localCommitP50": 1.3131720000092173,
        "localCommitP99": 2.994339000011678,
        "pushes": 11,
        "pulls": 22,
        "pushHttp": 22,
        "waitHttp": 29,
        "emptyPullMs": [
          311.81028599999263,
          312.4403250000032,
          316.2271419999888
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 100,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.070/150.094/150.106/0.017 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.1548897038518,
        "writeDurationMs": 5990.720990000002,
        "ackToVisibleP50": 701.2133040000044,
        "ackToVisibleP99": 1032.4150920000102,
        "startToVisibleP50": 703.5420779999986,
        "startToVisibleP99": 1034.1100589999987,
        "localCommitP50": 1.2352090000058524,
        "localCommitP99": 2.9746150000137277,
        "pushes": 11,
        "pulls": 20,
        "pushHttp": 22,
        "waitHttp": 27,
        "emptyPullMs": [
          308.69485599998734,
          313.032984999998,
          313.02952599999844
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.110/150.127/150.145/0.014 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 730.9989175220629,
        "writeDurationMs": 8207.94649099998,
        "ackToVisibleP50": 9428.632187999989,
        "ackToVisibleP99": 12687.232449999981,
        "startToVisibleP50": 9430.131079999992,
        "startToVisibleP99": 12688.364727000007,
        "localCommitP50": 1.2000159999879543,
        "localCommitP99": 3.950952999992296,
        "pushes": 2,
        "pulls": 4,
        "pushHttp": 4,
        "waitHttp": 11,
        "emptyPullMs": [
          313.86395800000173,
          314.3071429999836,
          313.4608639999933
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.064/150.071/150.082/0.007 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 806.9933982254753,
        "writeDurationMs": 7435.0050610000035,
        "ackToVisibleP50": 9161.273446999985,
        "ackToVisibleP99": 12138.973310000001,
        "startToVisibleP50": 9162.508931999997,
        "startToVisibleP99": 12139.929099,
        "localCommitP50": 1.1577010000182781,
        "localCommitP99": 2.9883689999987837,
        "pushes": 2,
        "pulls": 4,
        "pushHttp": 4,
        "waitHttp": 11,
        "emptyPullMs": [
          316.530070000008,
          312.80458799999906,
          312.4183989999874
        ],
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.066/150.077/150.098/0.014 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 852.2500585106955,
        "writeDurationMs": 7040.187254999997,
        "ackToVisibleP50": 9086.950821999984,
        "ackToVisibleP99": 12080.684638999985,
        "startToVisibleP50": 9088.094454999984,
        "startToVisibleP99": 12081.706032999995,
        "localCommitP50": 1.0868680000130553,
        "localCommitP99": 2.5894370000169147,
        "pushes": 2,
        "pulls": 4,
        "pushHttp": 4,
        "waitHttp": 11,
        "emptyPullMs": [
          306.4589520000154,
          313.3727619999845,
          311.7282280000218
        ],
        "error": null
      }
    ],
    "083": [
      {
        "ver": "083",
        "rtt": 0,
        "rate": 100,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.029/0.032/0.037/0.003 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15177572627879,
        "writeDurationMs": 5990.907257,
        "ackToVisibleP50": 47.684299999999894,
        "ackToVisibleP99": 94.63791399999991,
        "startToVisibleP50": 49.17721900000015,
        "startToVisibleP99": 95.84477900000002,
        "localCommitP50": 1.3807820000001811,
        "localCommitP99": 5.106559000000743,
        "pushes": 263,
        "pulls": 239,
        "pushHttp": 526,
        "waitHttp": 246,
        "emptyPullMs": [
          13.65299600000003,
          10.063283999999953,
          10.940803999999957
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 100,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.027/0.034/0.044/0.007 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.14444883703405,
        "writeDurationMs": 5991.345570999999,
        "ackToVisibleP50": 40.65784799999892,
        "ackToVisibleP99": 94.04919299999892,
        "startToVisibleP50": 42.262964999999895,
        "startToVisibleP99": 104.44106699999975,
        "localCommitP50": 1.349964999999429,
        "localCommitP99": 5.912263000000166,
        "pushes": 254,
        "pulls": 250,
        "pushHttp": 508,
        "waitHttp": 257,
        "emptyPullMs": [
          10.578790000000481,
          10.271682999999939,
          10.108902999999373
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 100,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.036/0.040/0.046/0.004 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15992137344676,
        "writeDurationMs": 5990.420038,
        "ackToVisibleP50": 44.74785200000042,
        "ackToVisibleP99": 74.24931399999696,
        "startToVisibleP50": 46.1123660000012,
        "startToVisibleP99": 75.84599099999832,
        "localCommitP50": 1.3027789999978268,
        "localCommitP99": 3.6028820000010455,
        "pushes": 264,
        "pulls": 261,
        "pushHttp": 528,
        "waitHttp": 268,
        "emptyPullMs": [
          10.455684999998994,
          9.79801100000077,
          10.100010000000111
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.032/0.033/0.035/0.001 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 895.7611978613558,
        "writeDurationMs": 6698.213780999999,
        "ackToVisibleP50": 3534.642337000001,
        "ackToVisibleP99": 6287.290363,
        "startToVisibleP50": 3535.6313980000014,
        "startToVisibleP99": 6288.337524999999,
        "localCommitP50": 1.0560550000009243,
        "localCommitP99": 2.421814000001177,
        "pushes": 2,
        "pulls": 39,
        "pushHttp": 4,
        "waitHttp": 46,
        "emptyPullMs": [
          11.830137000000832,
          10.099099999999453,
          10.05496199999834
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.041/0.054/0.080/0.018 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 886.032966917152,
        "writeDurationMs": 6771.757060999997,
        "ackToVisibleP50": 3499.3385909999997,
        "ackToVisibleP99": 6275.950438,
        "startToVisibleP50": 3500.7056329999978,
        "startToVisibleP99": 6277.001946,
        "localCommitP50": 1.0701719999997295,
        "localCommitP99": 2.6312330000000657,
        "pushes": 2,
        "pulls": 39,
        "pushHttp": 4,
        "waitHttp": 46,
        "emptyPullMs": [
          10.737562000002072,
          10.081561000002694,
          10.159395999999106
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.033/0.036/0.044/0.005 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 869.329796330987,
        "writeDurationMs": 6901.868571999999,
        "ackToVisibleP50": 3658.8227169999955,
        "ackToVisibleP99": 6363.150788999999,
        "startToVisibleP50": 3659.836608999998,
        "startToVisibleP99": 6364.154490000001,
        "localCommitP50": 1.063255000000936,
        "localCommitP99": 2.7805410000000848,
        "pushes": 2,
        "pulls": 37,
        "pushHttp": 4,
        "waitHttp": 44,
        "emptyPullMs": [
          3.9797790000011446,
          10.215690000004543,
          10.00923899999907
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 100,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.079/70.082/70.086/0.003 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.13219579322738,
        "writeDurationMs": 5992.078723999999,
        "ackToVisibleP50": 401.78392700000404,
        "ackToVisibleP99": 602.2929989999975,
        "startToVisibleP50": 403.1584920000023,
        "startToVisibleP99": 603.9079379999966,
        "localCommitP50": 1.3488340000039898,
        "localCommitP99": 3.717018999996071,
        "pushes": 21,
        "pulls": 39,
        "pushHttp": 42,
        "waitHttp": 46,
        "emptyPullMs": [
          145.3085990000036,
          151.48193300000275,
          151.26102600000013
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 100,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.076/70.090/70.103/0.011 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.16154354227122,
        "writeDurationMs": 5990.323020000003,
        "ackToVisibleP50": 392.7752069999988,
        "ackToVisibleP99": 593.5673309999984,
        "startToVisibleP50": 393.91470700000355,
        "startToVisibleP99": 594.8780229999975,
        "localCommitP50": 1.1878900000010617,
        "localCommitP99": 2.4375729999956093,
        "pushes": 21,
        "pulls": 41,
        "pushHttp": 42,
        "waitHttp": 48,
        "emptyPullMs": [
          145.49967499999912,
          151.6410079999987,
          151.99666499999876
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 100,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.066/70.074/70.080/0.006 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15928158610527,
        "writeDurationMs": 5990.458303000007,
        "ackToVisibleP50": 395.85042200000316,
        "ackToVisibleP99": 590.7643439999956,
        "startToVisibleP50": 397.41539600000397,
        "startToVisibleP99": 591.9062600000034,
        "localCommitP50": 1.2199899999977788,
        "localCommitP99": 2.8664019999996526,
        "pushes": 21,
        "pulls": 41,
        "pushHttp": 42,
        "waitHttp": 48,
        "emptyPullMs": [
          144.72373599999992,
          151.37927499999932,
          150.99602700000105
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.067/70.072/70.077/0.004 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 841.5880194994654,
        "writeDurationMs": 7129.379055999991,
        "ackToVisibleP50": 6081.080990000002,
        "ackToVisibleP99": 8964.561113000003,
        "startToVisibleP50": 6082.119150999992,
        "startToVisibleP99": 8965.639955000006,
        "localCommitP50": 1.0874079999921378,
        "localCommitP99": 2.994200000001001,
        "pushes": 2,
        "pulls": 5,
        "pushHttp": 4,
        "waitHttp": 12,
        "emptyPullMs": [
          144.4597250000079,
          151.51996099999815,
          151.4609819999896
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.076/70.088/70.112/0.017 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 810.3559483803198,
        "writeDurationMs": 7404.153707999998,
        "ackToVisibleP50": 5924.915915000005,
        "ackToVisibleP99": 9115.394885999995,
        "startToVisibleP50": 5926.001850999994,
        "startToVisibleP99": 9116.727834000005,
        "localCommitP50": 1.1275509999977658,
        "localCommitP99": 3.126657000000705,
        "pushes": 2,
        "pulls": 5,
        "pushHttp": 4,
        "waitHttp": 12,
        "emptyPullMs": [
          144.83669199999713,
          151.77333799999906,
          151.9310409999889
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.063/70.074/70.093/0.013 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 823.6821458691138,
        "writeDurationMs": 7284.363307000007,
        "ackToVisibleP50": 5416.2809699999925,
        "ackToVisibleP99": 8551.750151,
        "startToVisibleP50": 5417.373884999994,
        "startToVisibleP99": 8552.968947999994,
        "localCommitP50": 1.1296020000008866,
        "localCommitP99": 2.9851650000055088,
        "pushes": 2,
        "pulls": 5,
        "pushHttp": 4,
        "waitHttp": 12,
        "emptyPullMs": [
          153.7207839999901,
          152.18724199999997,
          151.16601600000286
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 100,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.067/150.071/150.081/0.006 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15604941813193,
        "writeDurationMs": 5990.651622999998,
        "ackToVisibleP50": 694.2276500000007,
        "ackToVisibleP99": 1163.498780000009,
        "startToVisibleP50": 695.5480990000069,
        "startToVisibleP99": 1164.6553010000061,
        "localCommitP50": 1.3311370000010356,
        "localCommitP99": 3.46281799999997,
        "pushes": 11,
        "pulls": 22,
        "pushHttp": 22,
        "waitHttp": 29,
        "emptyPullMs": [
          315.2196810000023,
          311.5497639999958,
          313.7558090000093
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 100,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.077/150.085/150.094/0.007 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.1356690615673,
        "writeDurationMs": 5991.870884999997,
        "ackToVisibleP50": 670.2905529999989,
        "ackToVisibleP99": 986.9006579999987,
        "startToVisibleP50": 672.3172839999897,
        "startToVisibleP99": 988.6991989999951,
        "localCommitP50": 1.4533320000045933,
        "localCommitP99": 3.9671269999962533,
        "pushes": 11,
        "pulls": 20,
        "pushHttp": 22,
        "waitHttp": 27,
        "emptyPullMs": [
          304.77355500000704,
          313.02710799999477,
          313.6703090000083
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 100,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.066/150.106/150.186/0.056 ms",
        "committed": 600,
        "measured": 500,
        "missing": 0,
        "actualRate": 100.15585750426965,
        "writeDurationMs": 5990.66310200002,
        "ackToVisibleP50": 736.4693979999865,
        "ackToVisibleP99": 1296.4339779999864,
        "startToVisibleP50": 737.4877770000021,
        "startToVisibleP99": 1297.6586630000093,
        "localCommitP50": 1.314699999988079,
        "localCommitP99": 5.462981000018772,
        "pushes": 11,
        "pulls": 20,
        "pushHttp": 22,
        "waitHttp": 27,
        "emptyPullMs": [
          306.1114599999855,
          314.16336900001625,
          313.31477299999096
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.052/150.065/150.076/0.010 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 736.2218720600772,
        "writeDurationMs": 8149.717126999982,
        "ackToVisibleP50": 9142.293930999993,
        "ackToVisibleP99": 12491.019277999992,
        "startToVisibleP50": 9143.445367000008,
        "startToVisibleP99": 12492.046753000002,
        "localCommitP50": 1.1856759999936912,
        "localCommitP99": 4.404661999986274,
        "pushes": 2,
        "pulls": 4,
        "pushHttp": 4,
        "waitHttp": 11,
        "emptyPullMs": [
          307.6920509999909,
          314.0140819999797,
          312.9184869999881
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.061/150.099/150.123/0.027 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 779.406551987105,
        "writeDurationMs": 7698.164692999999,
        "ackToVisibleP50": 9535.54827,
        "ackToVisibleP99": 12494.81905000002,
        "startToVisibleP50": 9537.183589000022,
        "startToVisibleP99": 12495.707621000009,
        "localCommitP50": 1.1615530000126455,
        "localCommitP99": 3.140869000024395,
        "pushes": 2,
        "pulls": 4,
        "pushHttp": 4,
        "waitHttp": 11,
        "emptyPullMs": [
          311.1428620000079,
          313.2554999999993,
          313.61184599998523
        ],
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.052/150.060/150.066/0.006 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "actualRate": 859.3162914662126,
        "writeDurationMs": 6982.295179999986,
        "ackToVisibleP50": 8620.856881000014,
        "ackToVisibleP99": 11479.248145999998,
        "startToVisibleP50": 8622.365611000016,
        "startToVisibleP99": 11485.165108999994,
        "localCommitP50": 1.0768059999973048,
        "localCommitP99": 2.8379640000057407,
        "pushes": 2,
        "pulls": 4,
        "pushHttp": 4,
        "waitHttp": 11,
        "emptyPullMs": [
          307.7995229999942,
          312.18627900001593,
          312.49468199998955
        ],
        "error": null
      }
    ]
  },
  "lag-open": {
    "082": [
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.036/0.067/0.118/0.035 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 959.4937150814901,
        "actualRate": 857.7287417483723,
        "writeDurationMs": 6995.218543999999,
        "ackToVisibleP50": 3580.9459699999998,
        "ackToVisibleP99": 6423.655991,
        "startToVisibleP50": 3693.138508,
        "startToVisibleP99": 6433.428559,
        "localCommitP50": 185.61612400000013,
        "localCommitP99": 809.6658109999998,
        "pushes": 4,
        "pulls": 39,
        "pushHttp": 8,
        "waitHttp": 46,
        "emptyPullMs": [
          12.466597999999976,
          9.349386999999979,
          10.016259999999988
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.037/0.038/0.040/0.001 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 972.3714127179037,
        "actualRate": 841.6478968068914,
        "writeDurationMs": 7128.871851,
        "ackToVisibleP50": 3348.421379999998,
        "ackToVisibleP99": 5964.677149000001,
        "startToVisibleP50": 3650.824494999999,
        "startToVisibleP99": 6046.017988000001,
        "localCommitP50": 206.68929800000114,
        "localCommitP99": 927.2189890000009,
        "pushes": 4,
        "pulls": 21,
        "pushHttp": 8,
        "waitHttp": 28,
        "emptyPullMs": [
          3.8845350000010512,
          10.09913400000005,
          9.932272999998531
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.040/0.041/0.042/0.000 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 949.5776545977589,
        "actualRate": 855.0699862214192,
        "writeDurationMs": 7016.969484000001,
        "ackToVisibleP50": 3294.4480680000015,
        "ackToVisibleP99": 5841.346787999999,
        "startToVisibleP50": 3537.3558620000003,
        "startToVisibleP99": 5855.629491,
        "localCommitP50": 192.31945899999846,
        "localCommitP99": 874.1303079999998,
        "pushes": 4,
        "pulls": 23,
        "pushHttp": 8,
        "waitHttp": 30,
        "emptyPullMs": [
          3.5455559999973048,
          10.101636999999755,
          10.281965999998647
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.072/70.108/70.145/0.029 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 997.356313935242,
        "actualRate": 843.1300218465574,
        "writeDurationMs": 7116.340118999997,
        "ackToVisibleP50": 5365.431876000002,
        "ackToVisibleP99": 7745.698830000001,
        "startToVisibleP50": 5558.465949000005,
        "startToVisibleP99": 7809.012207,
        "localCommitP50": 221.51604299999963,
        "localCommitP99": 1034.6183759999985,
        "pushes": 3,
        "pulls": 7,
        "pushHttp": 6,
        "waitHttp": 14,
        "emptyPullMs": [
          153.7820819999979,
          151.08534099999815,
          151.59190800000215
        ],
        "netemStats": "qdisc netem 8004: root refcnt 2 limit 1000 delay 35ms seed 7599436541367507246\n Sent 3337658 bytes 365 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.077/70.086/70.094/0.007 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 998.7296147648347,
        "actualRate": 864.492997796835,
        "writeDurationMs": 6940.484208999995,
        "ackToVisibleP50": 4125.003585000006,
        "ackToVisibleP99": 6392.900623000001,
        "startToVisibleP50": 4321.4244739999995,
        "startToVisibleP99": 6550.09216,
        "localCommitP50": 205.8775039999964,
        "localCommitP99": 869.1242960000018,
        "pushes": 3,
        "pulls": 8,
        "pushHttp": 6,
        "waitHttp": 15,
        "emptyPullMs": [
          153.70398299999943,
          151.08702599999378,
          151.49102299999504
        ],
        "netemStats": "qdisc netem 8004: root refcnt 2 limit 1000 delay 35ms seed 7599436541367507246\n Sent 6676300 bytes 737 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.090/70.097/70.109/0.008 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 425.6150406805355,
        "actualRate": 348.92652349709806,
        "writeDurationMs": 17195.597342,
        "ackToVisibleP50": 15937.370365999996,
        "ackToVisibleP99": 18548.759106999998,
        "startToVisibleP50": 15982.680770999992,
        "startToVisibleP99": 18603.846018999997,
        "localCommitP50": 133.60633100000268,
        "localCommitP99": 8585.013187000004,
        "pushes": 4,
        "pulls": 7,
        "pushHttp": 8,
        "waitHttp": 14,
        "emptyPullMs": [
          145.05643599999894,
          150.8434139999954,
          151.5537170000025
        ],
        "netemStats": "qdisc netem 8004: root refcnt 2 limit 1000 delay 35ms seed 7599436541367507246\n Sent 10018095 bytes 1118 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.075/150.095/150.108/0.014 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 896.2598322549226,
        "actualRate": 872.3650944019811,
        "writeDurationMs": 6877.854282,
        "ackToVisibleP50": 5168.264068000004,
        "ackToVisibleP99": 7076.524848999994,
        "startToVisibleP50": 5338.486518999998,
        "startToVisibleP99": 7135.281063999995,
        "localCommitP50": 126.98906799999531,
        "localCommitP99": 762.485302000001,
        "pushes": 3,
        "pulls": 7,
        "pushHttp": 6,
        "waitHttp": 14,
        "emptyPullMs": [
          306.1987150000059,
          312.42298299999675,
          312.5432320000109
        ],
        "netemStats": "qdisc netem 8004: root refcnt 2 limit 1000 delay 75ms seed 7599436541367507246\n Sent 13355686 bytes 1482 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.063/150.079/150.101/0.016 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 936.0103833503849,
        "actualRate": 881.1873035013259,
        "writeDurationMs": 6808.9950640000025,
        "ackToVisibleP50": 7815.459808999993,
        "ackToVisibleP99": 10610.427979999993,
        "startToVisibleP50": 8208.566988000006,
        "startToVisibleP99": 10787.832137000005,
        "localCommitP50": 182.0475410000072,
        "localCommitP99": 716.6154260000039,
        "pushes": 3,
        "pulls": 6,
        "pushHttp": 6,
        "waitHttp": 13,
        "emptyPullMs": [
          304.66553500000737,
          312.4215300000069,
          312.4800189999951
        ],
        "netemStats": "qdisc netem 8004: root refcnt 2 limit 1000 delay 75ms seed 7599436541367507246\n Sent 16691900 bytes 1833 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.060/150.068/150.075/0.006 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 947.9046136744178,
        "actualRate": 862.659710548939,
        "writeDurationMs": 6955.233826999989,
        "ackToVisibleP50": 7306.92128200001,
        "ackToVisibleP99": 9705.608087,
        "startToVisibleP50": 7754.781904000003,
        "startToVisibleP99": 9706.676525999996,
        "localCommitP50": 160.98165000000154,
        "localCommitP99": 869.9182040000014,
        "pushes": 3,
        "pulls": 8,
        "pushHttp": 6,
        "waitHttp": 15,
        "emptyPullMs": [
          306.7701340000058,
          312.9444220000005,
          312.4316720000061
        ],
        "netemStats": "qdisc netem 8004: root refcnt 2 limit 1000 delay 75ms seed 7599436541367507246\n Sent 20030739 bytes 2208 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      }
    ],
    "083": [
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.032/0.039/0.048/0.006 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 982.9960006737264,
        "actualRate": 232.67824524933508,
        "writeDurationMs": 25786.68235,
        "ackToVisibleP50": 27668.488674,
        "ackToVisibleP99": 30471.807409999998,
        "startToVisibleP50": 27818.342737,
        "startToVisibleP99": 30652.684724,
        "localCommitP50": 202.798366,
        "localCommitP99": 19619.544889,
        "pushes": 4,
        "pulls": 37,
        "pushHttp": 8,
        "waitHttp": 44,
        "emptyPullMs": [
          9.76520800000003,
          9.227158999999915,
          11.02614600000004
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.038/0.185/0.476/0.205 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 840.0484877331204,
        "actualRate": 832.6429214349342,
        "writeDurationMs": 7205.970105,
        "ackToVisibleP50": 3551.2969190000003,
        "ackToVisibleP99": 6392.782473000007,
        "startToVisibleP50": 3701.2390150000065,
        "startToVisibleP99": 6734.040122000006,
        "localCommitP50": 275.46172300000035,
        "localCommitP99": 1124.5251659999994,
        "pushes": 5,
        "pulls": 38,
        "pushHttp": 10,
        "waitHttp": 45,
        "emptyPullMs": [
          14.023844999996072,
          9.81379300000117,
          9.599400000006426
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.033/0.040/0.046/0.005 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 861.2887422366613,
        "actualRate": 788.7168162981632,
        "writeDurationMs": 7607.293106999998,
        "ackToVisibleP50": 3505.9574470000007,
        "ackToVisibleP99": 6404.006162000005,
        "startToVisibleP50": 3808.356359999998,
        "startToVisibleP99": 6476.743144,
        "localCommitP50": 273.3007080000025,
        "localCommitP99": 1429.3338399999993,
        "pushes": 4,
        "pulls": 24,
        "pushHttp": 8,
        "waitHttp": 31,
        "emptyPullMs": [
          4.4306740000029095,
          9.958613000002515,
          11.628923999996914
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.069/70.088/70.117/0.020 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 878.9600708967902,
        "actualRate": 826.8731477622887,
        "writeDurationMs": 7256.252081999999,
        "ackToVisibleP50": 4495.531083000002,
        "ackToVisibleP99": 6996.768046000005,
        "startToVisibleP50": 4991.804239000005,
        "startToVisibleP99": 7077.528743000003,
        "localCommitP50": 274.4966640000057,
        "localCommitP99": 1103.4305019999956,
        "pushes": 3,
        "pulls": 8,
        "pushHttp": 6,
        "waitHttp": 15,
        "emptyPullMs": [
          154.15918400000373,
          151.62982499999634,
          151.8868300000031
        ],
        "netemStats": "qdisc netem 8005: root refcnt 2 limit 1000 delay 35ms seed 9236581073621943661\n Sent 3338180 bytes 365 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.085/70.088/70.091/0.002 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 868.156860618851,
        "actualRate": 808.2619777443396,
        "writeDurationMs": 7423.335707000006,
        "ackToVisibleP50": 5108.269908000002,
        "ackToVisibleP99": 7150.289550999994,
        "startToVisibleP50": 5323.898019999993,
        "startToVisibleP99": 7218.046894999992,
        "localCommitP50": 373.0164250000089,
        "localCommitP99": 1256.6615140000067,
        "pushes": 3,
        "pulls": 7,
        "pushHttp": 6,
        "waitHttp": 14,
        "emptyPullMs": [
          146.11145900000702,
          150.91453999999794,
          151.6303740000003
        ],
        "netemStats": "qdisc netem 8005: root refcnt 2 limit 1000 delay 35ms seed 9236581073621943661\n Sent 6675376 bytes 723 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.085/70.091/70.099/0.005 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 917.6559842803066,
        "actualRate": 870.7220237169422,
        "writeDurationMs": 6890.832936999999,
        "ackToVisibleP50": 5011.992576999997,
        "ackToVisibleP99": 6986.1585170000035,
        "startToVisibleP50": 5140.5250779999915,
        "startToVisibleP99": 7046.134793999998,
        "localCommitP50": 145.8633339999942,
        "localCommitP99": 728.951801999996,
        "pushes": 3,
        "pulls": 7,
        "pushHttp": 6,
        "waitHttp": 14,
        "emptyPullMs": [
          144.81469500000821,
          150.93396499998926,
          151.60569199999736
        ],
        "netemStats": "qdisc netem 8005: root refcnt 2 limit 1000 delay 35ms seed 9236581073621943661\n Sent 10013166 bytes 1090 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.095/150.340/150.728/0.277 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 902.7795727209048,
        "actualRate": 814.669913862373,
        "writeDurationMs": 7364.946093999999,
        "ackToVisibleP50": 8840.375581999993,
        "ackToVisibleP99": 11894.276169000004,
        "startToVisibleP50": 8925.078135000003,
        "startToVisibleP99": 12011.716012999997,
        "localCommitP50": 318.0453109999944,
        "localCommitP99": 1188.925866999998,
        "pushes": 3,
        "pulls": 6,
        "pushHttp": 6,
        "waitHttp": 13,
        "emptyPullMs": [
          305.06018899999617,
          305.8766209999885,
          314.1505690000049
        ],
        "netemStats": "qdisc netem 8005: root refcnt 2 limit 1000 delay 75ms seed 9236581073621943661\n Sent 13336559 bytes 1443 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.063/150.090/150.139/0.034 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 844.9814946595184,
        "actualRate": 786.8327492461389,
        "writeDurationMs": 7625.508732000002,
        "ackToVisibleP50": 5957.842408000011,
        "ackToVisibleP99": 7367.675747000001,
        "startToVisibleP50": 6104.201090000002,
        "startToVisibleP99": 7415.217493000004,
        "localCommitP50": 175.24930999999924,
        "localCommitP99": 1484.9185750000033,
        "pushes": 3,
        "pulls": 8,
        "pushHttp": 6,
        "waitHttp": 15,
        "emptyPullMs": [
          305.8023569999932,
          312.2817619999987,
          312.6394089999958
        ],
        "netemStats": "qdisc netem 8005: root refcnt 2 limit 1000 delay 75ms seed 9236581073621943661\n Sent 16675200 bytes 1815 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.078/150.087/150.093/0.006 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "offeredRate": 913.8867730819244,
        "actualRate": 880.6424466886727,
        "writeDurationMs": 6813.207815000016,
        "ackToVisibleP50": 5929.895023999998,
        "ackToVisibleP99": 8721.847790999993,
        "startToVisibleP50": 5950.070309000002,
        "startToVisibleP99": 8779.988192999997,
        "localCommitP50": 83.79853299999377,
        "localCommitP99": 718.4450399999914,
        "pushes": 3,
        "pulls": 7,
        "pushHttp": 6,
        "waitHttp": 14,
        "emptyPullMs": [
          308.6072270000004,
          304.4641430000047,
          313.3170539999992
        ],
        "netemStats": "qdisc netem 8005: root refcnt 2 limit 1000 delay 75ms seed 9236581073621943661\n Sent 20012857 bytes 2180 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      }
    ]
  },
  "lag-batch": {
    "082": [
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.035/0.174/0.449/0.194 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.3998500074265,
        "writeDurationMs": 5991.612641,
        "ackToVisibleP50": 52.385050999999294,
        "ackToVisibleP99": 84.01970900000015,
        "startToVisibleP50": 54.20620000000008,
        "startToVisibleP99": 86.50406000000021,
        "localCommitP50": 1.723823999999695,
        "localCommitP99": 4.64104800000041,
        "pushes": 255,
        "pulls": 227,
        "pushHttp": 510,
        "waitHttp": 234,
        "emptyPullMs": [
          13.441624000000047,
          10.276652000000013,
          9.951653000000078
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.033/0.034/0.036/0.001 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.4327832641089,
        "writeDurationMs": 5991.415599999999,
        "ackToVisibleP50": 44.46197100000063,
        "ackToVisibleP99": 562.1199930000002,
        "startToVisibleP50": 46.061641000000236,
        "startToVisibleP99": 571.9652600000009,
        "localCommitP50": 1.635870000000068,
        "localCommitP99": 4.220393999999942,
        "pushes": 231,
        "pulls": 249,
        "pushHttp": 462,
        "waitHttp": 256,
        "emptyPullMs": [
          5.016112999999677,
          11.663630000000012,
          8.503002999999808
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 0,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.033/0.038/0.044/0.004 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.669633195036,
        "writeDurationMs": 5989.998899,
        "ackToVisibleP50": 46.348354000001564,
        "ackToVisibleP99": 502.4609840000012,
        "startToVisibleP50": 48.03973000000042,
        "startToVisibleP99": 504.7301690000022,
        "localCommitP50": 1.6985899999999674,
        "localCommitP99": 27.134743000002345,
        "pushes": 236,
        "pulls": 251,
        "pushHttp": 472,
        "waitHttp": 258,
        "emptyPullMs": [
          4.961128000000826,
          10.279563000000053,
          10.30072300000029
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.066/70.071/70.082/0.007 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.5812091084451,
        "writeDurationMs": 5990.527722999999,
        "ackToVisibleP50": 652.702150000001,
        "ackToVisibleP99": 1052.485654,
        "startToVisibleP50": 654.2208290000017,
        "startToVisibleP99": 1054.1686459999983,
        "localCommitP50": 1.571682999998302,
        "localCommitP99": 3.3375969999979134,
        "pushes": 13,
        "pulls": 36,
        "pushHttp": 26,
        "waitHttp": 43,
        "emptyPullMs": [
          145.57124599999952,
          151.70092699999805,
          151.6903110000021
        ],
        "netemStats": "qdisc netem 8006: root refcnt 2 limit 1000 delay 35ms seed 14378734852720783302\n Sent 3585114 bytes 835 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.083/70.086/70.091/0.003 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.5059658561989,
        "writeDurationMs": 5990.9777920000015,
        "ackToVisibleP50": 706.6430369999944,
        "ackToVisibleP99": 1061.6071319999974,
        "startToVisibleP50": 709.1525500000025,
        "startToVisibleP99": 1063.230263999998,
        "localCommitP50": 1.5531620000037947,
        "localCommitP99": 2.9893469999988156,
        "pushes": 12,
        "pulls": 34,
        "pushHttp": 24,
        "waitHttp": 41,
        "emptyPullMs": [
          145.9611960000002,
          149.99989199999982,
          151.39886299999853
        ],
        "netemStats": "qdisc netem 8006: root refcnt 2 limit 1000 delay 35ms seed 14378734852720783302\n Sent 7146611 bytes 1633 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 70,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.066/70.080/70.098/0.013 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.6275957633637,
        "writeDurationMs": 5990.250293999998,
        "ackToVisibleP50": 668.8861150000012,
        "ackToVisibleP99": 1072.972627999996,
        "startToVisibleP50": 672.1064330000008,
        "startToVisibleP99": 1076.195725000005,
        "localCommitP50": 1.5066790000055335,
        "localCommitP99": 3.830752999994729,
        "pushes": 13,
        "pulls": 36,
        "pushHttp": 26,
        "waitHttp": 43,
        "emptyPullMs": [
          145.6436459999968,
          151.5120459999962,
          151.48083400000178
        ],
        "netemStats": "qdisc netem 8006: root refcnt 2 limit 1000 delay 35ms seed 14378734852720783302\n Sent 10723785 bytes 2472 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.084/150.090/150.094/0.004 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.6078655816965,
        "writeDurationMs": 5990.3682929999995,
        "ackToVisibleP50": 3275.502704999999,
        "ackToVisibleP99": 4565.078125,
        "startToVisibleP50": 3277.0503829999943,
        "startToVisibleP99": 4566.580525999998,
        "localCommitP50": 1.5728989999988698,
        "localCommitP99": 3.4098120000053314,
        "pushes": 5,
        "pulls": 16,
        "pushHttp": 10,
        "waitHttp": 23,
        "emptyPullMs": [
          314.2083280000006,
          314.99711899999966,
          305.7700509999995
        ],
        "netemStats": "qdisc netem 8006: root refcnt 2 limit 1000 delay 75ms seed 14378734852720783302\n Sent 14114650 bytes 2962 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.083/150.107/150.133/0.020 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.4577994189046,
        "writeDurationMs": 5991.265935999996,
        "ackToVisibleP50": 3271.4574799999973,
        "ackToVisibleP99": 4570.5468980000005,
        "startToVisibleP50": 3273.306276999996,
        "startToVisibleP99": 4572.858684999999,
        "localCommitP50": 1.6064180000103079,
        "localCommitP99": 3.3928460000024643,
        "pushes": 5,
        "pulls": 16,
        "pushHttp": 10,
        "waitHttp": 23,
        "emptyPullMs": [
          307.4065660000051,
          305.5772219999999,
          313.12224699999933
        ],
        "netemStats": "qdisc netem 8006: root refcnt 2 limit 1000 delay 75ms seed 14378734852720783302\n Sent 17505581 bytes 3453 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "082",
        "rtt": 150,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.133/150.148/150.172/0.017 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 994.9964317595511,
        "writeDurationMs": 6030.172378999996,
        "ackToVisibleP50": 3291.8845989999973,
        "ackToVisibleP99": 4591.938812000008,
        "startToVisibleP50": 3293.460988000006,
        "startToVisibleP99": 4593.670596000011,
        "localCommitP50": 1.5781549999956042,
        "localCommitP99": 21.396710000000894,
        "pushes": 5,
        "pulls": 16,
        "pushHttp": 10,
        "waitHttp": 23,
        "emptyPullMs": [
          303.91375599999446,
          313.0223149999947,
          313.2468700000027
        ],
        "netemStats": "qdisc netem 8006: root refcnt 2 limit 1000 delay 75ms seed 14378734852720783302\n Sent 20896512 bytes 3944 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      }
    ],
    "083": [
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 0.028/0.067/0.132/0.046 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.598131114575,
        "writeDurationMs": 5990.426512999999,
        "ackToVisibleP50": 43.774651000000176,
        "ackToVisibleP99": 61.66871500000025,
        "startToVisibleP50": 45.42730500000016,
        "startToVisibleP99": 63.290841,
        "localCommitP50": 1.6316579999997884,
        "localCommitP99": 3.512109999999666,
        "pushes": 258,
        "pulls": 278,
        "pushHttp": 516,
        "waitHttp": 285,
        "emptyPullMs": [
          13.447040000000015,
          9.963737000000037,
          9.71297299999992
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 0.042/0.048/0.061/0.009 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.3118999933305,
        "writeDurationMs": 5992.138913,
        "ackToVisibleP50": 51.88826500000141,
        "ackToVisibleP99": 1231.564330000001,
        "startToVisibleP50": 54.273605000000316,
        "startToVisibleP99": 1236.8551009999992,
        "localCommitP50": 1.7098810000006779,
        "localCommitP99": 24.54008099999919,
        "pushes": 193,
        "pulls": 213,
        "pushHttp": 386,
        "waitHttp": 220,
        "emptyPullMs": [
          9.675344999999652,
          9.738876999999775,
          10.314973000000464
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 0,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 0.042/0.052/0.068/0.011 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.4839043761895,
        "writeDurationMs": 5991.109766000001,
        "ackToVisibleP50": 43.54960800000117,
        "ackToVisibleP99": 74.08262800000011,
        "startToVisibleP50": 45.36950700000125,
        "startToVisibleP99": 156.60267199999907,
        "localCommitP50": 1.6474019999986922,
        "localCommitP99": 4.312642999999298,
        "pushes": 252,
        "pulls": 280,
        "pushHttp": 504,
        "waitHttp": 287,
        "emptyPullMs": [
          5.098751999999877,
          10.273301999999603,
          10.138103999999657
        ],
        "netemStats": "qdisc noqueue 0: root refcnt 2 \n Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 0b 0p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 70.079/70.099/70.136/0.025 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.4712600929072,
        "writeDurationMs": 5991.185408000001,
        "ackToVisibleP50": 578.0970620000007,
        "ackToVisibleP99": 1052.5646300000008,
        "startToVisibleP50": 579.7324770000014,
        "startToVisibleP99": 1055.4669439999998,
        "localCommitP50": 1.6152790000014647,
        "localCommitP99": 5.252147999999579,
        "pushes": 15,
        "pulls": 37,
        "pushHttp": 30,
        "waitHttp": 44,
        "emptyPullMs": [
          149.82464800000162,
          150.3840569999993,
          151.24414799999795
        ],
        "netemStats": "qdisc netem 8007: root refcnt 2 limit 1000 delay 35ms seed 3736827517724524212\n Sent 3612083 bytes 884 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 70.052/70.083/70.105/0.022 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.4294323603159,
        "writeDurationMs": 5991.435647999999,
        "ackToVisibleP50": 592.4461650000012,
        "ackToVisibleP99": 1030.5626200000042,
        "startToVisibleP50": 594.2446580000033,
        "startToVisibleP99": 1032.5330930000055,
        "localCommitP50": 1.605583000000479,
        "localCommitP99": 3.283058000000892,
        "pushes": 14,
        "pulls": 37,
        "pushHttp": 28,
        "waitHttp": 44,
        "emptyPullMs": [
          152.85342200000014,
          151.65624600000228,
          151.323253999999
        ],
        "netemStats": "qdisc netem 8007: root refcnt 2 limit 1000 delay 35ms seed 3736827517724524212\n Sent 7219830 bytes 1749 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 70,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 70.079/70.089/70.100/0.008 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 994.9928046771955,
        "writeDurationMs": 6030.194361000002,
        "ackToVisibleP50": 1229.944653999999,
        "ackToVisibleP99": 2454.538247000004,
        "startToVisibleP50": 1231.4723079999967,
        "startToVisibleP99": 2456.3665640000036,
        "localCommitP50": 1.6229380000004312,
        "localCommitP99": 27.78803300000436,
        "pushes": 11,
        "pulls": 26,
        "pushHttp": 22,
        "waitHttp": 33,
        "emptyPullMs": [
          146.6729919999998,
          149.68806700000277,
          151.04357100000198
        ],
        "netemStats": "qdisc netem 8007: root refcnt 2 limit 1000 delay 35ms seed 3736827517724524212\n Sent 10733771 bytes 2453 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 1,
        "ping": "rtt min/avg/max/mdev = 150.098/150.103/150.109/0.004 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.3109028832428,
        "writeDurationMs": 5992.14488,
        "ackToVisibleP50": 3305.2894319999978,
        "ackToVisibleP99": 4904.988001999998,
        "startToVisibleP50": 3307.597124,
        "startToVisibleP99": 4907.228461999999,
        "localCommitP50": 2.015006000001449,
        "localCommitP99": 21.967886999998882,
        "pushes": 5,
        "pulls": 16,
        "pushHttp": 10,
        "waitHttp": 23,
        "emptyPullMs": [
          331.9954330000037,
          309.24828100000013,
          309.9954910000015
        ],
        "netemStats": "qdisc netem 8007: root refcnt 2 limit 1000 delay 75ms seed 3736827517724524212\n Sent 14124768 bytes 2945 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 2,
        "ping": "rtt min/avg/max/mdev = 150.087/150.103/150.124/0.015 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.3488292229318,
        "writeDurationMs": 5991.917926000002,
        "ackToVisibleP50": 3112.4281069999997,
        "ackToVisibleP99": 4403.375469999999,
        "startToVisibleP50": 3113.929845000006,
        "startToVisibleP99": 4404.907751000006,
        "localCommitP50": 1.604922999998962,
        "localCommitP99": 3.371986999998626,
        "pushes": 5,
        "pulls": 16,
        "pushHttp": 10,
        "waitHttp": 23,
        "emptyPullMs": [
          307.05369000000064,
          314.5856619999977,
          312.121742000003
        ],
        "netemStats": "qdisc netem 8007: root refcnt 2 limit 1000 delay 75ms seed 3736827517724524212\n Sent 17515567 bytes 3434 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      },
      {
        "ver": "083",
        "rtt": 150,
        "rate": 1000,
        "repeat": 3,
        "ping": "rtt min/avg/max/mdev = 150.075/150.096/150.137/0.029 ms",
        "committed": 6000,
        "measured": 5000,
        "missing": 0,
        "batchSize": 10,
        "actualRate": 1001.4381549861816,
        "writeDurationMs": 5991.383461999998,
        "ackToVisibleP50": 3282.253666000004,
        "ackToVisibleP99": 4570.821930999999,
        "startToVisibleP50": 3283.882580000005,
        "startToVisibleP99": 4572.342023000005,
        "localCommitP50": 1.8334109999996144,
        "localCommitP99": 12.508084000000963,
        "pushes": 5,
        "pulls": 16,
        "pushHttp": 10,
        "waitHttp": 23,
        "emptyPullMs": [
          314.9425809999957,
          311.79470800000126,
          313.15960499999346
        ],
        "netemStats": "qdisc netem 8007: root refcnt 2 limit 1000 delay 75ms seed 3736827517724524212\n Sent 20906498 bytes 3925 pkt (dropped 0, overlimits 0 requeues 0) \n backlog 66b 1p requeues 0\n",
        "error": null
      }
    ]
  }
}
```

</details>


## What TerraBase would need to add

| Failure mode | Required addition | What does not suffice |
|---|---|---|
| UNIQUE/FK reject after local ACK, partial push | Home execution must atomically accept/reject the **whole original transaction**; rollback on every non-benign error; advance durable deduplication/ack state only together with committed accepted changes. Define reject/compensate/retry semantics and retain the original operation until an explicit terminal outcome | Retrying the stock CLI push; its high-water mark can already cover the failed row |
| Lost local intent on pull / failed replay | Durable per-operation/transaction conflict log and status API at R and H, correlation IDs, rejected payload/reason, operator/client-visible reconciliation, bounded retry policy, and a supported skip/rewrite/discard action. Preserve transaction dependencies | A transport error string or `cdcOperations=0`; neither proves all business operations committed |
| Stale same-column overwrite | If product wants edit-time LWW, store HLC + stable node/operation tie-breaker and compare at H per row/column through conditional SQL or an authority protocol. Log losing versions. Reconnecting regions must not blindly overwrite a newer stored clock | Sorting only one client's outgoing batch; H must arbitrate clocks across clients. HLC LWW still loses concurrent intent and does not enforce SQL invariants |
| Different-column edits | Preserve the default changed-column UPDATE path; for stronger merge rules use a tested transform + authority-side metadata. Add the missing SDK-kit/C/.NET callback bridge before relying on it from TerraBase | A custom whole-row UPSERT would regress the disjoint-column behavior already proven |
| Balance/stock/quota/read-before-write invariants | Route the decision transaction to H, or design explicit per-region escrow/reservations/commutative operations with reconciliation. Distinguish provisional local admission from final authorization | Column merge, HLC ordering, UUID PKs, or a delta transform alone. Delta debits can expose overdraft instead of hiding it; rejecting at H cannot retract an external side effect already promised locally |
| Rowid/AUTOINCREMENT collisions | Enforce explicit globally unique application keys (UUID/ULID with sound generation, or approved disjoint allocation), including every referenced FK; avoid exposing implicit rowid as global identity | SQLite AUTOINCREMENT; it protects one replica's local history, not the region set |
| DDL race / swallowed ADD COLUMN error | A single home migration owner, schema versions and compatibility windows; validate the actual resulting schema. Narrow any ignored error to a verified identical migration. Rehearse destructive changes separately | Assuming `IF NOT EXISTS` / ignored ADD COLUMN errors validate equivalent schemas |
| Trigger double effects | Fix upstream/direct-indirect CDC semantics or disallow locally fired replicated triggers until a proven replay policy exists. Decide whether to reproduce derived changes or execute triggers, then do it exactly once; include FK-derived actions in tests | Blindly stripping audit-table changes; that is schema-specific and can discard real direct writes. A C# wrapper cannot identify trigger origin absent a supported marker |
| Partition backlog, unbounded push lag | Bounded push batches, backpressure/admission controls, durable outbox metrics, per-database lag/status, and measured reconnect limits. Guarantee supported load through a sustained benchmark on the selected runtime | Local ACK latency or a successful small partition hash test as proof of a WAN convergence SLO |
| Home production service | Authenticated/TLS authority, parallel request handling, real long polling, observability, backup/recovery and a single-authority failover design | Shipping the development CLI server as the home service; source processes accepted connections sequentially and has no authentication check in its HTTP route handling |

HLC, transforms and a conflict log are separate features. None makes arbitrary offline SQL transactions globally serializable. A constraint-reject policy must also say what happens to an application action that already received a local ACK. An explicit “local accepted / home committed / rejected” distinction is part of the API contract, not merely telemetry.

## Verdict

| Mode | Verdict | Reason |
|---|---|---|
| (a) Default SQL database, every region writes locally and receives final success | **No** | Local constraint checks and transactions do not protect global invariants; committed local intent can later be overwritten/dropped. Current CLI authority also violates all-or-nothing push expectations |
| (b) Explicit opt-in local-writes mode | **Conditionally useful; do not ship the tested stack unchanged** | Suitable for conflict-tolerant append records with global keys, or carefully designed commutative state. ACK must be provisional with durable conflict visibility. Block triggers/concurrent DDL/unsupported constraints until fixed; keep invariant-sensitive transactions at H. Implement .NET hook support if that policy relies on transforms |
| (c) Not useful at all | **Too strong** | Disjoint-column UPDATEs, globally keyed inserts, additive schema evolution and a bounded distinct-key partition converged in these tests. That is useful for a restricted offline/local-first workload |

DECISION: Prefer a home-authoritative SQL transaction path as the baseline and keep any local-writes mode as a separately specified consistency contract. Reason: the missing pieces are authority rejection semantics, application-visible reconciliation and invariant policy, not merely replication transport. The source evidence improves the original note in two ways: there is already column-level UPDATE merging and a real JS transform hook, but that hook is currently absent from the .NET SDK-kit route.

## Limits and cleanup

Runtime proof is restricted to the exact released CLIs and JS packages listed above, default WAL mode, one shared Linux host and synthetic data. No cloud authority, deployed WAN, failover, crash durability, MVCC runtime, sustained capacity SLO, or custom TerraBase C# runtime performance is proven. The observed 70/150ms results emulate symmetric per-leg RTTs, not measured gru/sjc/fra links. Long-poll server behavior remains unproven because the required CLI does not implement it. The lag benchmark's five-second measurement windows are a spike signal, not a soak test.

Cleanup completed: removed **only `/home/mariogk/spikes/turso-mw-20261029`** on mariogk-dev (experiment host) and delta (harness/evidence copy). Stopped the two remaining loopback test servers from the abandoned concurrent-statement harness attempt. All netem changes lived inside private namespaces; no host qdisc was modified. The report embeds the final harnesses and all final lag records so evidence survives scratch deletion. No PRs, OCI changes or secret operations occurred.

## Reproduction harness and measured evidence

The following embedded harnesses preserve reproduction after scratch cleanup. The run requires the release CLI archives extracted under `bin0.8.2`/`bin0.8.3`, plus `npm install --save-exact @tursodatabase/sync@<version> @tursodatabase/sync-common@<version> @tursodatabase/database-common@<version>` under `js082`/`js083`. No auth token is needed for loopback `--sync-server`.

```bash
node cases.mjs 082
node cases.mjs 083
node supplemental.mjs
node supplemental-run.mjs 082 pullConflict,fkDefault,fkReverse
node supplemental-run.mjs 083 pullConflict,fkDefault,fkReverse
# Netem affects only the new private namespace, including spawned H and clients:
unshare -Urn bash -c 'ip link set lo up; node lag.mjs 082'
unshare -Urn bash -c 'ip link set lo up; node lag.mjs 083'
unshare -Urn bash -c 'ip link set lo up; node lag-open.mjs 082'
unshare -Urn bash -c 'ip link set lo up; node lag-open.mjs 083'
unshare -Urn bash -c 'ip link set lo up; node lag-batch.mjs 082'
unshare -Urn bash -c 'ip link set lo up; node lag-batch.mjs 083'
```

<details><summary>cases.mjs</summary>

```javascript
import {spawn} from 'node:child_process';
import {mkdir, open, writeFile} from 'node:fs/promises';
import net from 'node:net';
import {createHash,randomUUID} from 'node:crypto';
import {performance} from 'node:perf_hooks';
const root='/home/mariogk/spikes/turso-mw-20261029';
const ver=process.argv[2]??'082';
const {connect}=await import(`${root}/js${ver}/node_modules/@tursodatabase/sync/dist/promise.js`);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const out=[];
const norm=x=>x===undefined?null:JSON.parse(JSON.stringify(x,(_,v)=>typeof v==='bigint'?Number(v):v));
async function attempt(f){try{return {ok:true,value:norm(await f())}}catch(e){return {ok:false,error:String(e)}}}
async function setup(name){
 const dir=`${root}/run${ver}/${name}-${Date.now()}`;await mkdir(dir,{recursive:true});
 const port=await new Promise(r=>{let s=net.createServer();s.listen(0,'127.0.0.1',()=>{let p=s.address().port;s.close(()=>r(p))})});
 const url=`http://127.0.0.1:${port}`;
 const log=await open(`${dir}/server.log`,'w');
 const server=spawn(`${root}/bin0.8.${ver.slice(-1)}/turso_cli-x86_64-unknown-linux-gnu/tursodb`,[`${dir}/H.db`,'--sync-server',`127.0.0.1:${port}`],{stdio:['ignore',log.fd,log.fd]});
 let ready=false; for(let i=0;i<100;i++){try{await fetch(url);ready=true;break}catch{await sleep(20)}}if(!ready)throw Error('server not ready');
 const wire=[];const mutations=[];const clients=[];const states=[];
 async function home(sql,args=[]){let j=await (await fetch(url+'/v2/pipeline',{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql,args:args.map(value=>({type:typeof value==='number'?'integer':'text',value})),want_rows:true}}]})})).json();let x=j.results[0];if(x.type==='error')throw Error(JSON.stringify(x));return norm(x.response.result);}
 async function client(i,extra={}) {const state={online:true};states[i]=state;let db=await connect({path:`${dir}/R${i}.db`,url,clientName:`${name}-R${i}`,transform:m=>{mutations.push(norm({region:i,...m}));return null},fetch:async(u,init)=>{if(!state.online)throw Error('simulated R3 partition');let res=await fetch(u,init);if(u.endsWith('/v2/pipeline'))wire.push({region:i,request:JSON.parse(Buffer.from(init.body).toString()),response:await res.clone().json()});return res},...extra});clients[i]=db;return db;}
 async function finish(){for(let c of clients.filter(Boolean))await attempt(()=>c.close());server.kill('SIGINT');await Promise.race([new Promise(r=>server.once('exit',r)),sleep(1000)]);if(server.exitCode===null)server.kill('SIGKILL');await log.close();await writeFile(`${dir}/wire.json`,JSON.stringify({wire,mutations},null,2));}
 return {home,client,finish,states,clients,wire,mutations};
}
async function rows(db,sql){return norm(await (await db.prepare(sql)).all())}
async function run(name,f){let s;let t=performance.now();try{s=await setup(name);let result=await f(s);let x={version:ver,case:name,ms:performance.now()-t,result};out.push(x);console.log(JSON.stringify(x));}catch(e){let x={version:ver,case:name,error:String(e),stack:e.stack};out.push(x);console.log(JSON.stringify(x));}finally{if(s)await s.finish();await writeFile(`${root}/cases${ver}.json`,JSON.stringify(out,null,2))}}
const filter=process.argv[3];
const cases={
 async columns(s){await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,a TEXT,b TEXT)');await s.home("INSERT INTO t VALUES('x','a0','b0')");let a=await s.client(1),b=await s.client(2),c=await s.client(3);await a.exec("UPDATE t SET a='a1' WHERE id='x'");await b.exec("UPDATE t SET b='b2' WHERE id='x'");await a.push();await b.push();await Promise.all([a.pull(),b.pull(),c.pull()]);return {home:await s.home('SELECT * FROM t'),replicas:await Promise.all([a,b,c].map(d=>rows(d,'SELECT * FROM t'))),mutations:s.mutations};},
 async stale(s){await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,v TEXT)');await s.home("INSERT INTO t VALUES('x','base')");let a=await s.client(1),b=await s.client(2),c=await s.client(3);await b.exec("UPDATE t SET v='older-edit-R2' WHERE id='x'");await sleep(30);await a.exec("UPDATE t SET v='newer-edit-R1' WHERE id='x'");await a.push();let afterFirst=await s.home('SELECT * FROM t');await b.push();await Promise.all([a.pull(),b.pull(),c.pull()]);return {afterFirst,afterStalePush:await s.home('SELECT * FROM t'),replicas:await Promise.all([a,b,c].map(d=>rows(d,'SELECT * FROM t')))};},
 async unique(s){await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,email TEXT UNIQUE)');let a=await s.client(1),b=await s.client(2),c=await s.client(3);await a.exec("INSERT INTO t VALUES('R1','same@local')");await b.exec("BEGIN; INSERT INTO t VALUES('before','before@local'); INSERT INTO t VALUES('R2','same@local'); INSERT INTO t VALUES('after','after@local'); COMMIT;");let localBefore=await rows(b,'SELECT * FROM t ORDER BY id');await a.push();let firstPush=await attempt(()=>b.push());let localAfterReject=await rows(b,'SELECT * FROM t ORDER BY id'),statsAfterReject=await b.stats(),homeAfterReject=await s.home('SELECT * FROM t ORDER BY id');let retry=await attempt(()=>b.push());let pull=await attempt(()=>b.pull());return {localBefore,firstPush,localAfterReject,statsAfterReject,homeAfterReject,retry,pull,localAfterPull:await rows(b,'SELECT * FROM t ORDER BY id'),statsAfterPull:await b.stats(),homeWatermark:await s.home('SELECT * FROM turso_sync_last_change_id')};},
 async fk(s){await s.home('PRAGMA foreign_keys=ON');await s.home('CREATE TABLE p(id INTEGER PRIMARY KEY)');await s.home('CREATE TABLE c(id TEXT PRIMARY KEY,pid INTEGER REFERENCES p(id))');await s.home('INSERT INTO p VALUES(1)');let a=await s.client(1),b=await s.client(2),c=await s.client(3);for(let d of [a,b,c])await d.exec('PRAGMA foreign_keys=ON');await a.exec('DELETE FROM p WHERE id=1');await b.exec("INSERT INTO c VALUES('child',1)");await a.push();let push=await attempt(()=>b.push()),local=await rows(b,'SELECT * FROM c'),retry=await attempt(()=>b.push()),pull=await attempt(()=>b.pull());return {push,local,retry,pull,homeFk:await s.home('PRAGMA foreign_keys'),homeParent:await s.home('SELECT * FROM p'),homeChild:await s.home('SELECT * FROM c'),finalLocal:await rows(b,'SELECT * FROM c'),foreignKeyCheck:await s.home('PRAGMA foreign_key_check')};},
 async balance(s){await s.home('CREATE TABLE account(id TEXT PRIMARY KEY,balance INTEGER CHECK(balance>=0))');await s.home('CREATE TABLE ledger(id TEXT PRIMARY KEY,amount INTEGER)');await s.home("INSERT INTO account VALUES('x',100)");let ds=await Promise.all([1,2,3].map(i=>s.client(i)));let approvals=await Promise.all(ds.slice(0,2).map(async(d,i)=>{await d.exec('BEGIN IMMEDIATE');let balance=(await rows(d,'SELECT balance FROM account'))[0].balance;if(balance>=80){await d.exec(`UPDATE account SET balance=${balance-80} WHERE id='x'`);await d.exec(`INSERT INTO ledger VALUES('R${i+1}',80)`);}await d.exec('COMMIT');return balance>=80}));await ds[0].push();await ds[1].push();await ds[2].pull();return {approvals,balance:await s.home('SELECT * FROM account'),ledger:await s.home('SELECT * FROM ledger'),charged:160,initial:100,lostDebit:80,impliedOverdraft:60};},
 async ddl(s){await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,v TEXT)');await s.home("INSERT INTO t VALUES('x','base')");let a=await s.client(1),b=await s.client(2),c=await s.client(3);await a.exec('ALTER TABLE t ADD COLUMN extra TEXT DEFAULT \'d\'');await a.exec("UPDATE t SET extra='R1' WHERE id='x'");await b.exec("UPDATE t SET v='R2' WHERE id='x'");let pushA=await attempt(()=>a.push()),pushB=await attempt(()=>b.push());let pulls=await Promise.all([a,b,c].map(d=>attempt(()=>d.pull())));return {pushA,pushB,pulls,home:await s.home('SELECT * FROM t'),replicas:await Promise.all([a,b,c].map(d=>rows(d,'SELECT * FROM t')))};},
 async keys(s){for(let sql of ['CREATE TABLE ai(id INTEGER PRIMARY KEY AUTOINCREMENT,v TEXT)','CREATE TABLE ri(id INTEGER PRIMARY KEY,v TEXT)','CREATE TABLE implicit(v TEXT)','CREATE TABLE uu(id TEXT PRIMARY KEY,v TEXT)','CREATE TABLE ul(id TEXT PRIMARY KEY,v TEXT)'])await s.home(sql);let a=await s.client(1),b=await s.client(2),c=await s.client(3);for(let [i,d] of [[1,a],[2,b]]){await d.exec(`INSERT INTO ai(v) VALUES('R${i}'); INSERT INTO ri(v) VALUES('R${i}'); INSERT INTO implicit(v) VALUES('R${i}'); INSERT INTO uu VALUES('${randomUUID()}','R${i}'); INSERT INTO ul VALUES('01JB${String(i).padStart(22,'0')}','R${i}')`)}let local=await Promise.all([a,b].map(async d=>({ai:await rows(d,'SELECT * FROM ai'),ri:await rows(d,'SELECT * FROM ri'),implicit:await rows(d,'SELECT rowid,* FROM implicit')})));await a.push();await b.push();let pulls=await Promise.all([a,b,c].map(d=>attempt(()=>d.pull())));return {local,pulls,home:await Promise.all(['ai','ri','implicit','uu','ul'].map(async t=>({table:t,data:await s.home(`SELECT rowid,* FROM ${t}`)})))};},
 async triggers(s){await s.home('CREATE TABLE t(id INTEGER PRIMARY KEY,x TEXT)');await s.home('CREATE TABLE audit(id INTEGER PRIMARY KEY,msg TEXT)');await s.home("CREATE TRIGGER t_ai AFTER INSERT ON t BEGIN INSERT INTO audit(msg) VALUES ('inserted ' || new.id); END");let a=await s.client(1),b=await s.client(2),c=await s.client(3);await a.exec("INSERT INTO t VALUES(1,'a')");let localBefore=await rows(a,'SELECT * FROM audit');let push=await attempt(()=>a.push());let homeAfter=await s.home('SELECT * FROM audit ORDER BY id');let pulls=await Promise.all([a,b,c].map(d=>attempt(()=>d.pull())));return {localBefore,push,homeAfter,pulls,localAfter:await Promise.all([a,b,c].map(d=>rows(d,'SELECT * FROM audit ORDER BY id'))),mutations:s.mutations};},
 async transform(s){await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,v INTEGER)');await s.home("INSERT INTO t VALUES('x',0)");let a=await s.client(1),seen=[];let b=await s.client(2,{transform:m=>{seen.push(norm(m));if(m.tableName==='t'&&m.changeType==='update')return {operation:'rewrite',stmt:{sql:'UPDATE t SET v=v+? WHERE id=?',values:[m.after.v-m.before.v,m.before.id]}};return null}});let c=await s.client(3);await a.exec("UPDATE t SET v=v+2 WHERE id='x'");await b.exec("UPDATE t SET v=v+3 WHERE id='x'");await a.push();await b.push();await c.pull();return {seen,home:await s.home('SELECT * FROM t'),R3:await rows(c,'SELECT * FROM t')};},
 async partition(s){await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,v TEXT)');let ds=await Promise.all([1,2,3].map(i=>s.client(i)));s.states[3].online=false;let reject=await attempt(()=>ds[2].push()); // empty push still fetches watermark
 let start=performance.now(),count=0;while(performance.now()-start<60000){let scheduled=start+count*100; if(scheduled>performance.now())await sleep(scheduled-performance.now());await Promise.all(ds.map((d,i)=>d.exec(`INSERT INTO t VALUES('R${i+1}-${count}','v${count}')`)));await ds[0].push();await ds[1].push();if(count%10===0){await ds[0].pull();await ds[1].pull()}count++;}
 let offlineMs=performance.now()-start,localOffline=await rows(ds[2],'SELECT count(*) AS n FROM t');let t=performance.now();s.states[3].online=true;await ds[2].push();await Promise.all(ds.map(d=>d.pull()));let snapshots=await Promise.all(ds.map(d=>rows(d,'SELECT * FROM t ORDER BY id')));let hr=await s.home('SELECT * FROM t ORDER BY id');let homeRows=hr.rows.map(r=>Object.fromEntries(hr.cols.map((c,i)=>[c.name,r[i].value])));let hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');return {rejectedOfflinePush:reject,offlineMs,writesEach:count,localOffline,convergenceMs:performance.now()-t,counts:snapshots.map(x=>x.length),homeCount:homeRows.length,hashes:snapshots.map(hash),homeHash:hash(homeRows),equal:snapshots.every(x=>hash(x)===hash(homeRows))};}
};
for(let [name,f] of Object.entries(cases))if(!filter||filter.split(',').includes(name))await run(name,f);

```

</details>

<details><summary>supplemental.mjs</summary>

```javascript
import {readFile,writeFile} from 'node:fs/promises';
let s=await readFile('cases.mjs','utf8');
s=s.replace('const cases={',`const cases={
 async pullConflict(s){
  await s.home('CREATE TABLE t(id TEXT PRIMARY KEY,email TEXT UNIQUE)');
  let a=await s.client(1),skip=false,calls=[];
  let b=await s.client(2,{transform:m=>{calls.push({...m,skipped:skip}); return skip&&m.tableName==='t'?{operation:'skip'}:null}});
  let c=await s.client(3);
  await a.exec("INSERT INTO t VALUES('R1','same@local')");await b.exec("INSERT INTO t VALUES('R2','same@local')");await a.push();
  let firstPull=await attempt(()=>b.pull());let localAfterError=await attempt(()=>rows(b,'SELECT * FROM t'));
  skip=true;let policyPull=await attempt(()=>b.pull());let localAfterPolicy=await attempt(()=>rows(b,'SELECT * FROM t'));
  return {firstPull,localAfterError,policyPull,localAfterPolicy,calls,home:await s.home('SELECT * FROM t')};
 },
 async fkDefault(s){
  let defaultFk=await s.home('PRAGMA foreign_keys');await s.home('CREATE TABLE p(id INTEGER PRIMARY KEY)');await s.home('CREATE TABLE c(id TEXT PRIMARY KEY,pid INTEGER REFERENCES p(id))');await s.home('INSERT INTO p VALUES(1)');let a=await s.client(1),b=await s.client(2),c=await s.client(3);for(let d of [a,b,c])await d.exec('PRAGMA foreign_keys=ON');await a.exec('DELETE FROM p WHERE id=1');await b.exec("INSERT INTO c VALUES('child',1)");await a.push();let push=await attempt(()=>b.push());return {defaultFk,push,homeParent:await s.home('SELECT * FROM p'),homeChild:await s.home('SELECT * FROM c'),check:await s.home('PRAGMA foreign_key_check')};
 },
 async fkReverse(s){
  await s.home('PRAGMA foreign_keys=ON');await s.home('CREATE TABLE p(id INTEGER PRIMARY KEY)');await s.home('CREATE TABLE c(id TEXT PRIMARY KEY,pid INTEGER REFERENCES p(id))');await s.home('INSERT INTO p VALUES(1)');let a=await s.client(1),b=await s.client(2),c=await s.client(3);for(let d of [a,b,c])await d.exec('PRAGMA foreign_keys=ON');await a.exec('DELETE FROM p WHERE id=1');await b.exec("INSERT INTO c VALUES('child',1)");await b.push();let push=await attempt(()=>a.push()),retry=await attempt(()=>a.push()),pull=await attempt(()=>a.pull());return {push,retry,pull,homeParent:await s.home('SELECT * FROM p'),homeChild:await s.home('SELECT * FROM c'),localParent:await rows(a,'SELECT * FROM p')};
 },
`);
s=s.replace('cases'+ '${ver}' + '.json','supplemental'+ '${ver}' + '.json');
await writeFile('supplemental-run.mjs',s);

```

</details>

<details><summary>lag.mjs</summary>

```javascript
import {spawn,spawnSync} from 'node:child_process';
import {mkdir,open,writeFile,readFile} from 'node:fs/promises';
import net from 'node:net';
import {performance} from 'node:perf_hooks';
const root='/home/mariogk/spikes/turso-mw-20261029',ver=process.argv[2]??'082';
const {connect}=await import(`${root}/js${ver}/node_modules/@tursodatabase/sync/dist/promise.js`);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const records=[];
const only=process.argv[3];
async function run(rtt,rate,repeat){
 // Change only this private user+network namespace's loopback qdisc.
 const tc=rtt?spawnSync('tc',['qdisc','replace','dev','lo','root','netem','delay',`${rtt/2}ms`]):spawnSync('tc',['qdisc','del','dev','lo','root']);
 if(rtt&&tc.status)throw Error(tc.stderr.toString());
 const ping=spawnSync('ping',['-n','-c','3','-i','0.2','127.0.0.1']).stdout.toString().trim().split('\n').slice(-1)[0];
 const dir=`${root}/lag${ver}/${rtt}-${rate}-${repeat}-${Date.now()}`;await mkdir(dir,{recursive:true});
 const port=await new Promise(r=>{let s=net.createServer();s.listen(0,'127.0.0.1',()=>{let p=s.address().port;s.close(()=>r(p))})});
 const log=await open(`${dir}/server.log`,'w');
 const server=spawn(`${root}/bin0.8.${ver.slice(-1)}/turso_cli-x86_64-unknown-linux-gnu/tursodb`,[`${dir}/H.db`,'--sync-server',`127.0.0.1:${port}`],{stdio:['ignore',log.fd,log.fd]});
 const url=`http://127.0.0.1:${port}`;
 let a,b,c,pushTask,pullTask;
 let stopped=false,writerDone=false,pushDirty=false,pushes=0,pulls=0,pushHttp=0,waitHttp=0;
 let error=null;const requestMs=[],emptyPullMs=[],ackTimes=[],startTimes=[],observed=[],localDur=[];
 try{
  for(let i=0;i<100;i++){try{await fetch(url);break}catch{await sleep(10)}}
  await fetch(url+'/v2/pipeline',{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql:'CREATE TABLE t(id INTEGER PRIMARY KEY,v TEXT)',want_rows:false}}]})});
  const options=i=>({path:`${dir}/R${i}.db`,url,clientName:`lag-R${i}`,longPollTimeoutMs:5000,fetch:async(u,init)=>{let t=performance.now();let res=await fetch(u,init);if(u.endsWith('/pull-updates')){waitHttp++;requestMs.push(performance.now()-t)}if(i===1&&u.endsWith('/v2/pipeline'))pushHttp++;return res}});
  a=await connect(options(1));b=await connect(options(2));c=await connect(options(3));
  for(let i=0;i<3;i++){let t=performance.now();let changed=await c.pull();if(!changed)emptyPullMs.push(performance.now()-t)}
  const ins=await a.prepare('INSERT INTO t VALUES(?,?)'),sel=await c.prepare('SELECT id FROM t WHERE id>? ORDER BY id');
  let pushActive=false;
  function requestPush(){pushDirty=true;if(!pushActive){pushActive=true;pushTask=(async()=>{try{while(pushDirty){pushDirty=false;await a.push();pushes++}}catch(e){error='push: '+e;stopped=true}finally{pushActive=false}})()}}
  let seen=-1;
  const begin=performance.now();
  pullTask=(async()=>{try{while(!stopped){await c.pull();pulls++;let rs=await sel.all(seen);let now=performance.now();for(let row of rs){observed[row.id]=now;seen=Math.max(seen,row.id)}if(writerDone&&seen===ackTimes.length-1)break;if(rs.length===0)await sleep(1)}}catch(e){error='pull: '+e;stopped=true}})();
  // One second warmup, then five measured seconds. Each local commit immediately
  // requests a push; concurrent requests coalesce while one push is in flight.
  const n=6*rate;
  for(let id=0;id<n&&!stopped;id++){
   const due=begin+id*1000/rate;const dt=due-performance.now();if(dt>0)await sleep(dt);
   startTimes[id]=performance.now();await ins.run(id,`v${id}`);ackTimes[id]=performance.now();localDur.push(ackTimes[id]-startTimes[id]);requestPush();
  }
  const writeEnd=performance.now();writerDone=true;
  await pushTask;
  // Bound convergence; do not hide incomplete samples from the result.
  let limit;await Promise.race([pullTask,new Promise((_,reject)=>limit=setTimeout(()=>reject(Error('30s convergence deadline')),30000))]);clearTimeout(limit);stopped=true;
  await b.pull();
  let lags=[],total=[];for(let i=rate;i<ackTimes.length;i++){if(observed[i]!==undefined){lags.push(Math.max(0,observed[i]-ackTimes[i]));total.push(observed[i]-startTimes[i])}}
  const p=(xs,q)=>{xs=xs.slice().sort((a,b)=>a-b);return xs.length?xs[Math.ceil(q*xs.length)-1]:null};
  let record={ver,rtt,rate,repeat,ping,committed:ackTimes.length,measured:lags.length,missing:Math.max(0,ackTimes.length-rate-lags.length),actualRate:ackTimes.length/((writeEnd-begin)/1000),writeDurationMs:writeEnd-begin,ackToVisibleP50:p(lags,.5),ackToVisibleP99:p(lags,.99),startToVisibleP50:p(total,.5),startToVisibleP99:p(total,.99),localCommitP50:p(localDur,.5),localCommitP99:p(localDur,.99),pushes,pulls,pushHttp,waitHttp,emptyPullMs,error};
  await writeFile(`${dir}/samples.json`,JSON.stringify({record,ackTimes,startTimes,observed}));return record;
 }finally{stopped=true;for(let d of [a,b,c])if(d)try{await d.close()}catch{}server.kill('SIGINT');await Promise.race([new Promise(r=>server.once('exit',r)),sleep(500)]);if(server.exitCode===null)server.kill('SIGKILL');await log.close()}
}
for(let rtt of [0,70,150])for(let rate of [100,1000])for(let repeat=1;repeat<=3;repeat++){
 if(only&&!`${rtt}-${rate}-${repeat}`.startsWith(only))continue;
 try{let x=await run(rtt,rate,repeat);records.push(x);console.log(JSON.stringify(x))}catch(e){let x={ver,rtt,rate,repeat,error:String(e),stack:e.stack};records.push(x);console.log(JSON.stringify(x))}
 await writeFile(`${root}/lag${ver}.json`,JSON.stringify(records,null,2));
}

```

</details>

<details><summary>lag-open.mjs</summary>

```javascript
import {spawn,spawnSync} from 'node:child_process';
import {mkdir,open,writeFile,readFile} from 'node:fs/promises';
import net from 'node:net';
import {performance} from 'node:perf_hooks';
const root='/home/mariogk/spikes/turso-mw-20261029',ver=process.argv[2]??'082';
const {connect}=await import(`${root}/js${ver}/node_modules/@tursodatabase/sync/dist/promise.js`);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const records=[];
const only=process.argv[3];
async function run(rtt,rate,repeat){
 // Change only this private user+network namespace's loopback qdisc.
 const tc=rtt?spawnSync('tc',['qdisc','replace','dev','lo','root','netem','delay',`${rtt/2}ms`]):spawnSync('tc',['qdisc','del','dev','lo','root']);
 if(rtt&&tc.status)throw Error(tc.stderr.toString());
 const ping=spawnSync('ping',['-n','-c','3','-i','0.2','127.0.0.1']).stdout.toString().trim().split('\n').slice(-1)[0];
 const dir=`${root}/lag${ver}/${rtt}-${rate}-${repeat}-${Date.now()}`;await mkdir(dir,{recursive:true});
 const port=await new Promise(r=>{let s=net.createServer();s.listen(0,'127.0.0.1',()=>{let p=s.address().port;s.close(()=>r(p))})});
 const log=await open(`${dir}/server.log`,'w');
 const server=spawn(`${root}/bin0.8.${ver.slice(-1)}/turso_cli-x86_64-unknown-linux-gnu/tursodb`,[`${dir}/H.db`,'--sync-server',`127.0.0.1:${port}`],{stdio:['ignore',log.fd,log.fd]});
 const url=`http://127.0.0.1:${port}`;
 let a,b,c,pushTask,pullTask;
 let stopped=false,writerDone=false,pushDirty=false,pushes=0,pulls=0,pushHttp=0,waitHttp=0;
 let error=null;const requestMs=[],emptyPullMs=[],ackTimes=[],startTimes=[],observed=[],localDur=[];
 try{
  for(let i=0;i<100;i++){try{await fetch(url);break}catch{await sleep(10)}}
  await fetch(url+'/v2/pipeline',{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql:'CREATE TABLE t(id INTEGER PRIMARY KEY,v TEXT)',want_rows:false}}]})});
  const options=i=>({path:`${dir}/R${i}.db`,url,clientName:`lag-R${i}`,longPollTimeoutMs:5000,fetch:async(u,init)=>{let t=performance.now();let res=await fetch(u,init);if(u.endsWith('/pull-updates')){waitHttp++;requestMs.push(performance.now()-t)}if(i===1&&u.endsWith('/v2/pipeline'))pushHttp++;return res}});
  a=await connect(options(1));b=await connect(options(2));c=await connect(options(3));
  for(let i=0;i<3;i++){let t=performance.now();let changed=await c.pull();if(!changed)emptyPullMs.push(performance.now()-t)}
  const ins=await a.prepare('INSERT INTO t VALUES(?,?)'),sel=await c.prepare('SELECT id FROM t WHERE id>? ORDER BY id');
  let pushActive=false;
  function requestPush(){pushDirty=true;if(!pushActive){pushActive=true;pushTask=(async()=>{try{while(pushDirty){pushDirty=false;await a.push();pushes++}}catch(e){error='push: '+e;stopped=true}finally{pushActive=false}})()}}
  let seen=-1;
  const begin=performance.now();
  pullTask=(async()=>{try{while(!stopped){await c.pull();pulls++;let rs=await sel.all(seen);let now=performance.now();for(let row of rs){observed[row.id]=now;seen=Math.max(seen,row.id)}if(writerDone&&seen===ackTimes.length-1)break;if(rs.length===0)await sleep(1)}}catch(e){error='pull: '+e;stopped=true}})();
  // One second warmup, then five measured seconds. Each local commit immediately
  // requests a push; concurrent requests coalesce while one push is in flight.
  const n=6*rate;
  // Open-loop arrivals: enqueue 100/1000 commits per second even when the
  // official client's execution queue cannot keep up. Measure queueing too.
  const commits=[];let localChain=Promise.resolve();
  for(let id=0;id<n&&!stopped;){
   const due=begin+id*1000/rate;const dt=due-performance.now();if(dt>0)await sleep(Math.min(10,dt));
   const target=Math.min(n,Math.floor((performance.now()-begin)*rate/1000)+1);
   while(id<target&&!stopped){const seq=id++;startTimes[seq]=performance.now();
    localChain=localChain.then(async()=>{await ins.run(seq,`v${seq}`);ackTimes[seq]=performance.now();localDur.push(ackTimes[seq]-startTimes[seq]);requestPush()});commits.push(localChain);
   }
  }
  const arrivalEnd=performance.now();await Promise.all(commits);
  const writeEnd=performance.now();writerDone=true;
  await pushTask;
  // Bound convergence; do not hide incomplete samples from the result.
  let limit;await Promise.race([pullTask,new Promise((_,reject)=>limit=setTimeout(()=>reject(Error('30s convergence deadline')),30000))]);clearTimeout(limit);stopped=true;
  await b.pull();
  let lags=[],total=[];for(let i=rate;i<ackTimes.length;i++){if(observed[i]!==undefined){lags.push(Math.max(0,observed[i]-ackTimes[i]));total.push(observed[i]-startTimes[i])}}
  const p=(xs,q)=>{xs=xs.slice().sort((a,b)=>a-b);return xs.length?xs[Math.ceil(q*xs.length)-1]:null};
  let record={ver,rtt,rate,repeat,ping,committed:ackTimes.length,measured:lags.length,missing:Math.max(0,ackTimes.length-rate-lags.length),offeredRate:ackTimes.length/((arrivalEnd-begin)/1000),actualRate:ackTimes.length/((writeEnd-begin)/1000),writeDurationMs:writeEnd-begin,ackToVisibleP50:p(lags,.5),ackToVisibleP99:p(lags,.99),startToVisibleP50:p(total,.5),startToVisibleP99:p(total,.99),localCommitP50:p(localDur,.5),localCommitP99:p(localDur,.99),pushes,pulls,pushHttp,waitHttp,emptyPullMs,netemStats:spawnSync('tc',['-s','qdisc','show','dev','lo']).stdout.toString(),error};
  await writeFile(`${dir}/samples.json`,JSON.stringify({record,ackTimes,startTimes,observed}));return record;
 }finally{stopped=true;for(let d of [a,b,c])if(d)try{await d.close()}catch{}server.kill('SIGINT');await Promise.race([new Promise(r=>server.once('exit',r)),sleep(500)]);if(server.exitCode===null)server.kill('SIGKILL');await log.close()}
}
for(let rtt of [0,70,150])for(let rate of [1000])for(let repeat=1;repeat<=3;repeat++){
 if(only&&!`${rtt}-${rate}-${repeat}`.startsWith(only))continue;
 try{let x=await run(rtt,rate,repeat);records.push(x);console.log(JSON.stringify(x))}catch(e){let x={ver,rtt,rate,repeat,error:String(e),stack:e.stack};records.push(x);console.log(JSON.stringify(x))}
 await writeFile(`${root}/lag-open${ver}.json`,JSON.stringify(records,null,2));
}

```

</details>

<details><summary>lag-batch.mjs</summary>

```javascript
import {spawn,spawnSync} from 'node:child_process';
import {mkdir,open,writeFile,readFile} from 'node:fs/promises';
import net from 'node:net';
import {performance} from 'node:perf_hooks';
const root='/home/mariogk/spikes/turso-mw-20261029',ver=process.argv[2]??'082';
const {connect}=await import(`${root}/js${ver}/node_modules/@tursodatabase/sync/dist/promise.js`);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const records=[];
const only=process.argv[3];
async function run(rtt,rate,repeat){
 // Change only this private user+network namespace's loopback qdisc.
 const tc=rtt?spawnSync('tc',['qdisc','replace','dev','lo','root','netem','delay',`${rtt/2}ms`]):spawnSync('tc',['qdisc','del','dev','lo','root']);
 if(rtt&&tc.status)throw Error(tc.stderr.toString());
 const ping=spawnSync('ping',['-n','-c','3','-i','0.2','127.0.0.1']).stdout.toString().trim().split('\n').slice(-1)[0];
 const dir=`${root}/lag${ver}/${rtt}-${rate}-${repeat}-${Date.now()}`;await mkdir(dir,{recursive:true});
 const port=await new Promise(r=>{let s=net.createServer();s.listen(0,'127.0.0.1',()=>{let p=s.address().port;s.close(()=>r(p))})});
 const log=await open(`${dir}/server.log`,'w');
 const server=spawn(`${root}/bin0.8.${ver.slice(-1)}/turso_cli-x86_64-unknown-linux-gnu/tursodb`,[`${dir}/H.db`,'--sync-server',`127.0.0.1:${port}`],{stdio:['ignore',log.fd,log.fd]});
 const url=`http://127.0.0.1:${port}`;
 let a,b,c,pushTask,pullTask;
 let stopped=false,writerDone=false,pushDirty=false,pushes=0,pulls=0,pushHttp=0,waitHttp=0;
 let error=null;const requestMs=[],emptyPullMs=[],ackTimes=[],startTimes=[],observed=[],localDur=[];
 try{
  for(let i=0;i<100;i++){try{await fetch(url);break}catch{await sleep(10)}}
  await fetch(url+'/v2/pipeline',{method:'POST',body:JSON.stringify({requests:[{type:'execute',stmt:{sql:'CREATE TABLE t(id INTEGER PRIMARY KEY,v TEXT)',want_rows:false}}]})});
  const options=i=>({path:`${dir}/R${i}.db`,url,clientName:`lag-R${i}`,longPollTimeoutMs:5000,fetch:async(u,init)=>{let t=performance.now();let res=await fetch(u,init);if(u.endsWith('/pull-updates')){waitHttp++;requestMs.push(performance.now()-t)}if(i===1&&u.endsWith('/v2/pipeline'))pushHttp++;return res}});
  a=await connect(options(1));b=await connect(options(2));c=await connect(options(3));
  for(let i=0;i<3;i++){let t=performance.now();let changed=await c.pull();if(!changed)emptyPullMs.push(performance.now()-t)}
  const ins=await a.prepare('INSERT INTO t VALUES(?,?)'),sel=await c.prepare('SELECT id FROM t WHERE id>? ORDER BY id');
  let pushActive=false;
  function requestPush(){pushDirty=true;if(!pushActive){pushActive=true;pushTask=(async()=>{try{while(pushDirty){pushDirty=false;await a.push();pushes++}}catch(e){error='push: '+e;stopped=true}finally{pushActive=false}})()}}
  let seen=-1;
  const begin=performance.now();
  pullTask=(async()=>{try{while(!stopped){await c.pull();pulls++;let rs=await sel.all(seen);let now=performance.now();for(let row of rs){observed[row.id]=now;seen=Math.max(seen,row.id)}if(writerDone&&seen===ackTimes.length-1)break;if(rs.length===0)await sleep(1)}}catch(e){error='pull: '+e;stopped=true}})();
  // One second warmup, then five measured seconds. Each local commit immediately
  // requests a push; concurrent requests coalesce while one push is in flight.
  const n=6*rate;
  for(let id=0;id<n&&!stopped;id+=10){
   const due=begin+id*1000/rate;const dt=due-performance.now();if(dt>0)await sleep(dt);
   const before=performance.now();let stmts=['BEGIN IMMEDIATE'];
   for(let k=id;k<id+10;k++){startTimes[k]=before;stmts.push(`INSERT INTO t VALUES(${k},'v${k}')`)}
   stmts.push('COMMIT');await a.exec(stmts.join(';'));const ack=performance.now();
   for(let k=id;k<id+10;k++)ackTimes[k]=ack;
   localDur.push(ack-before);requestPush();
  }
  const writeEnd=performance.now();writerDone=true;
  await pushTask;
  // Bound convergence; do not hide incomplete samples from the result.
  let limit;await Promise.race([pullTask,new Promise((_,reject)=>limit=setTimeout(()=>reject(Error('30s convergence deadline')),30000))]);clearTimeout(limit);stopped=true;
  await b.pull();
  let lags=[],total=[];for(let i=rate;i<ackTimes.length;i++){if(observed[i]!==undefined){lags.push(Math.max(0,observed[i]-ackTimes[i]));total.push(observed[i]-startTimes[i])}}
  const p=(xs,q)=>{xs=xs.slice().sort((a,b)=>a-b);return xs.length?xs[Math.ceil(q*xs.length)-1]:null};
  let record={ver,rtt,rate,repeat,ping,committed:ackTimes.length,measured:lags.length,missing:Math.max(0,ackTimes.length-rate-lags.length),batchSize:10,actualRate:ackTimes.length/((writeEnd-begin)/1000),writeDurationMs:writeEnd-begin,ackToVisibleP50:p(lags,.5),ackToVisibleP99:p(lags,.99),startToVisibleP50:p(total,.5),startToVisibleP99:p(total,.99),localCommitP50:p(localDur,.5),localCommitP99:p(localDur,.99),pushes,pulls,pushHttp,waitHttp,emptyPullMs,netemStats:spawnSync('tc',['-s','qdisc','show','dev','lo']).stdout.toString(),error};
  await writeFile(`${dir}/samples.json`,JSON.stringify({record,ackTimes,startTimes,observed}));return record;
 }finally{stopped=true;for(let d of [a,b,c])if(d)try{await d.close()}catch{}server.kill('SIGINT');await Promise.race([new Promise(r=>server.once('exit',r)),sleep(500)]);if(server.exitCode===null)server.kill('SIGKILL');await log.close()}
}
for(let rtt of [0,70,150])for(let rate of [1000])for(let repeat=1;repeat<=3;repeat++){
 if(only&&!`${rtt}-${rate}-${repeat}`.startsWith(only))continue;
 try{let x=await run(rtt,rate,repeat);records.push(x);console.log(JSON.stringify(x))}catch(e){let x={ver,rtt,rate,repeat,error:String(e),stack:e.stack};records.push(x);console.log(JSON.stringify(x))}
 await writeFile(`${root}/lag-batch${ver}.json`,JSON.stringify(records,null,2));
}

```

</details>

<details><summary>Corrected semantic outcomes (normalized query rows)</summary>

```json
{
  "082": [
    {
      "version": "082",
      "case": "columns",
      "ms": 382.06126,
      "result": {
        "home": {
          "columns": [
            "id",
            "a",
            "b"
          ],
          "rows": [
            [
              "x",
              "a1",
              "b2"
            ]
          ]
        },
        "replicas": [
          [
            {
              "id": "x",
              "a": "a1",
              "b": "b2"
            }
          ],
          [
            {
              "id": "x",
              "a": "a1",
              "b": "b2"
            }
          ],
          [
            {
              "id": "x",
              "a": "a1",
              "b": "b2"
            }
          ]
        ],
        "mutations": [
          {
            "region": 1,
            "changeTime": 1793274227,
            "tableName": "t",
            "id": 1,
            "changeType": "update",
            "before": {
              "id": "x",
              "a": "a0",
              "b": "b0"
            },
            "after": {
              "b": "b0",
              "id": "x",
              "a": "a1"
            },
            "updates": {
              "a": "a1"
            }
          },
          {
            "region": 2,
            "changeTime": 1793274227,
            "tableName": "t",
            "id": 1,
            "changeType": "update",
            "before": {
              "a": "a0",
              "id": "x",
              "b": "b0"
            },
            "after": {
              "b": "b2",
              "id": "x",
              "a": "a0"
            },
            "updates": {
              "b": "b2"
            }
          }
        ]
      }
    },
    {
      "version": "082",
      "case": "stale",
      "ms": 286.69865400000003,
      "result": {
        "afterFirst": {
          "columns": [
            "id",
            "v"
          ],
          "rows": [
            [
              "x",
              "newer-edit-R1"
            ]
          ]
        },
        "afterStalePush": {
          "columns": [
            "id",
            "v"
          ],
          "rows": [
            [
              "x",
              "older-edit-R2"
            ]
          ]
        },
        "replicas": [
          [
            {
              "id": "x",
              "v": "older-edit-R2"
            }
          ],
          [
            {
              "id": "x",
              "v": "older-edit-R2"
            }
          ],
          [
            {
              "id": "x",
              "v": "older-edit-R2"
            }
          ]
        ]
      }
    },
    {
      "version": "082",
      "case": "unique",
      "ms": 279.33890099999996,
      "result": {
        "localBefore": [
          {
            "id": "R2",
            "email": "same@local"
          },
          {
            "id": "after",
            "email": "after@local"
          },
          {
            "id": "before",
            "email": "before@local"
          }
        ],
        "firstPush": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"UNIQUE constraint failed: t.email\", code: \"BATCH_STEP_ERROR\" }"
        },
        "localAfterReject": [
          {
            "id": "R2",
            "email": "same@local"
          },
          {
            "id": "after",
            "email": "after@local"
          },
          {
            "id": "before",
            "email": "before@local"
          }
        ],
        "statsAfterReject": {
          "cdcOperations": 3,
          "lastPullUnixTime": 1793274228,
          "revision": "4"
        },
        "homeAfterReject": {
          "columns": [
            "id",
            "email"
          ],
          "rows": [
            [
              "R1",
              "same@local"
            ],
            [
              "after",
              "after@local"
            ],
            [
              "before",
              "before@local"
            ]
          ]
        },
        "retry": {
          "ok": true,
          "value": null
        },
        "pull": {
          "ok": true,
          "value": true
        },
        "localAfterPull": [
          {
            "id": "R1",
            "email": "same@local"
          },
          {
            "id": "after",
            "email": "after@local"
          },
          {
            "id": "before",
            "email": "before@local"
          }
        ],
        "statsAfterPull": {
          "cdcOperations": 0,
          "lastPullUnixTime": 1793274228,
          "lastPushUnixTime": 1793274228,
          "revision": "15"
        },
        "homeWatermark": {
          "columns": [
            "client_id",
            "pull_gen",
            "change_id"
          ],
          "rows": [
            [
              "unique-R1-fc39db21-048d-4692-bcbc-ccc3fd3c936b",
              "0",
              "1"
            ],
            [
              "unique-R2-e775779b-c5ae-4d6a-8529-d915c83c8ec7",
              "0",
              "3"
            ]
          ]
        }
      }
    },
    {
      "version": "082",
      "case": "fk",
      "ms": 358.988572,
      "result": {
        "push": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"FOREIGN KEY constraint failed\", code: \"BATCH_STEP_ERROR\" }"
        },
        "local": [
          {
            "id": "child",
            "pid": 1
          }
        ],
        "retry": {
          "ok": true,
          "value": null
        },
        "pull": {
          "ok": true,
          "value": true
        },
        "homeFk": {
          "columns": [
            "foreign_keys"
          ],
          "rows": [
            [
              "1"
            ]
          ]
        },
        "homeParent": {
          "columns": [
            "id"
          ],
          "rows": []
        },
        "homeChild": {
          "columns": [
            "id",
            "pid"
          ],
          "rows": []
        },
        "finalLocal": [],
        "foreignKeyCheck": {
          "columns": [],
          "rows": []
        }
      }
    },
    {
      "version": "082",
      "case": "balance",
      "ms": 272.3543830000001,
      "result": {
        "approvals": [
          true,
          true
        ],
        "balance": {
          "columns": [
            "id",
            "balance"
          ],
          "rows": [
            [
              "x",
              "20"
            ]
          ]
        },
        "ledger": {
          "columns": [
            "id",
            "amount"
          ],
          "rows": [
            [
              "R1",
              "80"
            ],
            [
              "R2",
              "80"
            ]
          ]
        },
        "charged": 160,
        "initial": 100,
        "lostDebit": 80,
        "impliedOverdraft": 60
      }
    },
    {
      "version": "082",
      "case": "ddl",
      "ms": 251.04370900000004,
      "result": {
        "pushA": {
          "ok": true,
          "value": null
        },
        "pushB": {
          "ok": true,
          "value": null
        },
        "pulls": [
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          }
        ],
        "home": {
          "columns": [
            "id",
            "v",
            "extra"
          ],
          "rows": [
            [
              "x",
              "R2",
              "R1"
            ]
          ]
        },
        "replicas": [
          [
            {
              "id": "x",
              "v": "R2",
              "extra": "R1"
            }
          ],
          [
            {
              "id": "x",
              "v": "R2",
              "extra": "R1"
            }
          ],
          [
            {
              "id": "x",
              "v": "R2",
              "extra": "R1"
            }
          ]
        ]
      }
    },
    {
      "version": "082",
      "case": "keys",
      "ms": 343.75205400000004,
      "result": {
        "local": [
          {
            "ai": [
              {
                "id": 1,
                "v": "R1"
              }
            ],
            "ri": [
              {
                "id": 1,
                "v": "R1"
              }
            ],
            "implicit": [
              {
                "rowid": 1,
                "v": "R1"
              }
            ]
          },
          {
            "ai": [
              {
                "id": 1,
                "v": "R2"
              }
            ],
            "ri": [
              {
                "id": 1,
                "v": "R2"
              }
            ],
            "implicit": [
              {
                "rowid": 1,
                "v": "R2"
              }
            ]
          }
        ],
        "pulls": [
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          }
        ],
        "home": [
          {
            "table": "ai",
            "data": {
              "columns": [
                "id",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "1",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "ri",
            "data": {
              "columns": [
                "id",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "1",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "implicit",
            "data": {
              "columns": [
                "rowid",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "R1"
                ],
                [
                  "2",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "uu",
            "data": {
              "columns": [
                "rowid",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "26a1f14a-1738-4597-ac34-b793a47b22b4",
                  "R1"
                ],
                [
                  "2",
                  "b6d57aad-d2da-46cc-ac52-70e291e18c67",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "ul",
            "data": {
              "columns": [
                "rowid",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "01JB0000000000000000000001",
                  "R1"
                ],
                [
                  "2",
                  "01JB0000000000000000000002",
                  "R2"
                ]
              ]
            }
          }
        ]
      }
    },
    {
      "version": "082",
      "case": "triggers",
      "ms": 266.6083870000002,
      "result": {
        "localBefore": [
          {
            "id": 1,
            "msg": "inserted 1"
          }
        ],
        "push": {
          "ok": true,
          "value": null
        },
        "homeAfter": {
          "columns": [
            "id",
            "msg"
          ],
          "rows": [
            [
              "1",
              "inserted 1"
            ],
            [
              "2",
              "inserted 1"
            ]
          ]
        },
        "pulls": [
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          }
        ],
        "localAfter": [
          [
            {
              "id": 1,
              "msg": "inserted 1"
            },
            {
              "id": 2,
              "msg": "inserted 1"
            }
          ],
          [
            {
              "id": 1,
              "msg": "inserted 1"
            },
            {
              "id": 2,
              "msg": "inserted 1"
            }
          ],
          [
            {
              "id": 1,
              "msg": "inserted 1"
            },
            {
              "id": 2,
              "msg": "inserted 1"
            }
          ]
        ],
        "mutations": [
          {
            "region": 1,
            "changeTime": 1793274230,
            "tableName": "audit",
            "id": 1,
            "changeType": "insert",
            "after": {
              "msg": "inserted 1",
              "id": 1
            }
          },
          {
            "region": 1,
            "changeTime": 1793274230,
            "tableName": "t",
            "id": 1,
            "changeType": "insert",
            "after": {
              "id": 1,
              "x": "a"
            }
          }
        ]
      }
    },
    {
      "version": "082",
      "case": "transform",
      "ms": 222.8152030000001,
      "result": {
        "seen": [
          {
            "changeTime": 1793274230,
            "tableName": "t",
            "id": 1,
            "changeType": "update",
            "before": {
              "id": "x",
              "v": 0
            },
            "after": {
              "v": 3,
              "id": "x"
            },
            "updates": {
              "v": 3
            }
          }
        ],
        "home": {
          "columns": [
            "id",
            "v"
          ],
          "rows": [
            [
              "x",
              "5"
            ]
          ]
        },
        "R3": [
          {
            "id": "x",
            "v": 5
          }
        ]
      }
    },
    {
      "version": "082",
      "case": "partition",
      "ms": 60506.067704,
      "result": {
        "rejectedOfflinePush": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: fetch error: Error: simulated R3 partition"
        },
        "offlineMs": 60089.72268200001,
        "writesEach": 601,
        "localOffline": [
          {
            "n": 601
          }
        ],
        "convergenceMs": 314.7148379999999,
        "counts": [
          1803,
          1803,
          1803
        ],
        "homeCount": 1803,
        "hashes": [
          "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba",
          "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba",
          "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba"
        ],
        "homeHash": "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba",
        "equal": true
      }
    },
    {
      "version": "082",
      "case": "pullConflict",
      "ms": 343.574593,
      "result": {
        "firstPull": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to replay local change after remote apply: database error: UNIQUE constraint failed: t.email"
        },
        "localAfterError": {
          "ok": true,
          "value": [
            {
              "id": "R2",
              "email": "same@local"
            }
          ]
        },
        "policyPull": {
          "ok": true,
          "value": true
        },
        "localAfterPolicy": {
          "ok": true,
          "value": [
            {
              "id": "R1",
              "email": "same@local"
            }
          ]
        },
        "calls": [
          {
            "changeTime": 1793274340,
            "tableName": "t",
            "id": 1,
            "changeType": "insert",
            "after": {
              "id": "R2",
              "email": "same@local"
            },
            "skipped": false
          },
          {
            "changeTime": 1793274340,
            "tableName": "t",
            "id": 1,
            "changeType": "insert",
            "after": {
              "id": "R2",
              "email": "same@local"
            },
            "skipped": true
          }
        ],
        "home": {
          "columns": [
            "id",
            "email"
          ],
          "rows": [
            [
              "R1",
              "same@local"
            ]
          ]
        }
      }
    },
    {
      "version": "082",
      "case": "fkDefault",
      "ms": 237.03670899999997,
      "result": {
        "defaultFk": {
          "columns": [
            "foreign_keys"
          ],
          "rows": [
            [
              "0"
            ]
          ]
        },
        "push": {
          "ok": true,
          "value": null
        },
        "homeParent": {
          "columns": [
            "id"
          ],
          "rows": []
        },
        "homeChild": {
          "columns": [
            "id",
            "pid"
          ],
          "rows": [
            [
              "child",
              "1"
            ]
          ]
        },
        "check": {
          "columns": [],
          "rows": []
        }
      }
    },
    {
      "version": "082",
      "case": "fkReverse",
      "ms": 273.64414899999997,
      "result": {
        "push": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"FOREIGN KEY constraint failed\", code: \"BATCH_STEP_ERROR\" }"
        },
        "retry": {
          "ok": true,
          "value": null
        },
        "pull": {
          "ok": true,
          "value": true
        },
        "homeParent": {
          "columns": [
            "id"
          ],
          "rows": [
            [
              "1"
            ]
          ]
        },
        "homeChild": {
          "columns": [
            "id",
            "pid"
          ],
          "rows": [
            [
              "child",
              "1"
            ]
          ]
        },
        "localParent": [
          {
            "id": 1
          }
        ]
      }
    }
  ],
  "083": [
    {
      "version": "083",
      "case": "columns",
      "ms": 364.33872700000006,
      "result": {
        "home": {
          "columns": [
            "id",
            "a",
            "b"
          ],
          "rows": [
            [
              "x",
              "a1",
              "b2"
            ]
          ]
        },
        "replicas": [
          [
            {
              "id": "x",
              "a": "a1",
              "b": "b2"
            }
          ],
          [
            {
              "id": "x",
              "a": "a1",
              "b": "b2"
            }
          ],
          [
            {
              "id": "x",
              "a": "a1",
              "b": "b2"
            }
          ]
        ],
        "mutations": [
          {
            "region": 1,
            "changeTime": 1793274189,
            "tableName": "t",
            "id": 1,
            "changeType": "update",
            "before": {
              "b": "b0",
              "id": "x",
              "a": "a0"
            },
            "after": {
              "b": "b0",
              "id": "x",
              "a": "a1"
            },
            "updates": {
              "a": "a1"
            }
          },
          {
            "region": 2,
            "changeTime": 1793274189,
            "tableName": "t",
            "id": 1,
            "changeType": "update",
            "before": {
              "a": "a0",
              "id": "x",
              "b": "b0"
            },
            "after": {
              "b": "b2",
              "id": "x",
              "a": "a0"
            },
            "updates": {
              "b": "b2"
            }
          }
        ]
      }
    },
    {
      "version": "083",
      "case": "stale",
      "ms": 317.33105400000005,
      "result": {
        "afterFirst": {
          "columns": [
            "id",
            "v"
          ],
          "rows": [
            [
              "x",
              "newer-edit-R1"
            ]
          ]
        },
        "afterStalePush": {
          "columns": [
            "id",
            "v"
          ],
          "rows": [
            [
              "x",
              "older-edit-R2"
            ]
          ]
        },
        "replicas": [
          [
            {
              "id": "x",
              "v": "older-edit-R2"
            }
          ],
          [
            {
              "id": "x",
              "v": "older-edit-R2"
            }
          ],
          [
            {
              "id": "x",
              "v": "older-edit-R2"
            }
          ]
        ]
      }
    },
    {
      "version": "083",
      "case": "unique",
      "ms": 324.824442,
      "result": {
        "localBefore": [
          {
            "id": "R2",
            "email": "same@local"
          },
          {
            "id": "after",
            "email": "after@local"
          },
          {
            "id": "before",
            "email": "before@local"
          }
        ],
        "firstPush": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"UNIQUE constraint failed: t.email\", code: \"BATCH_STEP_ERROR\" }"
        },
        "localAfterReject": [
          {
            "id": "R2",
            "email": "same@local"
          },
          {
            "id": "after",
            "email": "after@local"
          },
          {
            "id": "before",
            "email": "before@local"
          }
        ],
        "statsAfterReject": {
          "cdcOperations": 3,
          "lastPullUnixTime": 1793274190,
          "revision": "4"
        },
        "homeAfterReject": {
          "columns": [
            "id",
            "email"
          ],
          "rows": [
            [
              "R1",
              "same@local"
            ],
            [
              "after",
              "after@local"
            ],
            [
              "before",
              "before@local"
            ]
          ]
        },
        "retry": {
          "ok": true,
          "value": null
        },
        "pull": {
          "ok": true,
          "value": true
        },
        "localAfterPull": [
          {
            "id": "R1",
            "email": "same@local"
          },
          {
            "id": "after",
            "email": "after@local"
          },
          {
            "id": "before",
            "email": "before@local"
          }
        ],
        "statsAfterPull": {
          "cdcOperations": 0,
          "lastPullUnixTime": 1793274190,
          "lastPushUnixTime": 1793274190,
          "revision": "15"
        },
        "homeWatermark": {
          "columns": [
            "client_id",
            "pull_gen",
            "change_id"
          ],
          "rows": [
            [
              "unique-R1-cbbf8e83-0445-4e6e-ab54-370c46f2d0cf",
              "0",
              "1"
            ],
            [
              "unique-R2-61c2ba4b-4ba7-459e-96d2-70d6d750b9cc",
              "0",
              "3"
            ]
          ]
        }
      }
    },
    {
      "version": "083",
      "case": "fk",
      "ms": 370.89362200000005,
      "result": {
        "push": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"FOREIGN KEY constraint failed\", code: \"BATCH_STEP_ERROR\" }"
        },
        "local": [
          {
            "id": "child",
            "pid": 1
          }
        ],
        "retry": {
          "ok": true,
          "value": null
        },
        "pull": {
          "ok": true,
          "value": true
        },
        "homeFk": {
          "columns": [
            "foreign_keys"
          ],
          "rows": [
            [
              "1"
            ]
          ]
        },
        "homeParent": {
          "columns": [
            "id"
          ],
          "rows": []
        },
        "homeChild": {
          "columns": [
            "id",
            "pid"
          ],
          "rows": []
        },
        "finalLocal": [],
        "foreignKeyCheck": {
          "columns": [],
          "rows": []
        }
      }
    },
    {
      "version": "083",
      "case": "balance",
      "ms": 260.78289599999994,
      "result": {
        "approvals": [
          true,
          true
        ],
        "balance": {
          "columns": [
            "id",
            "balance"
          ],
          "rows": [
            [
              "x",
              "20"
            ]
          ]
        },
        "ledger": {
          "columns": [
            "id",
            "amount"
          ],
          "rows": [
            [
              "R1",
              "80"
            ],
            [
              "R2",
              "80"
            ]
          ]
        },
        "charged": 160,
        "initial": 100,
        "lostDebit": 80,
        "impliedOverdraft": 60
      }
    },
    {
      "version": "083",
      "case": "ddl",
      "ms": 290.29962,
      "result": {
        "pushA": {
          "ok": true,
          "value": null
        },
        "pushB": {
          "ok": true,
          "value": null
        },
        "pulls": [
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          }
        ],
        "home": {
          "columns": [
            "id",
            "v",
            "extra"
          ],
          "rows": [
            [
              "x",
              "R2",
              "R1"
            ]
          ]
        },
        "replicas": [
          [
            {
              "id": "x",
              "v": "R2",
              "extra": "R1"
            }
          ],
          [
            {
              "id": "x",
              "v": "R2",
              "extra": "R1"
            }
          ],
          [
            {
              "id": "x",
              "v": "R2",
              "extra": "R1"
            }
          ]
        ]
      }
    },
    {
      "version": "083",
      "case": "keys",
      "ms": 331.27508000000034,
      "result": {
        "local": [
          {
            "ai": [
              {
                "id": 1,
                "v": "R1"
              }
            ],
            "ri": [
              {
                "id": 1,
                "v": "R1"
              }
            ],
            "implicit": [
              {
                "rowid": 1,
                "v": "R1"
              }
            ]
          },
          {
            "ai": [
              {
                "id": 1,
                "v": "R2"
              }
            ],
            "ri": [
              {
                "id": 1,
                "v": "R2"
              }
            ],
            "implicit": [
              {
                "rowid": 1,
                "v": "R2"
              }
            ]
          }
        ],
        "pulls": [
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          }
        ],
        "home": [
          {
            "table": "ai",
            "data": {
              "columns": [
                "id",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "1",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "ri",
            "data": {
              "columns": [
                "id",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "1",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "implicit",
            "data": {
              "columns": [
                "rowid",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "R1"
                ],
                [
                  "2",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "uu",
            "data": {
              "columns": [
                "rowid",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "7186e534-c74f-412c-886c-c60e2c3c816f",
                  "R1"
                ],
                [
                  "2",
                  "2dd351f7-b019-471c-af6d-fbe9dc6e4795",
                  "R2"
                ]
              ]
            }
          },
          {
            "table": "ul",
            "data": {
              "columns": [
                "rowid",
                "id",
                "v"
              ],
              "rows": [
                [
                  "1",
                  "01JB0000000000000000000001",
                  "R1"
                ],
                [
                  "2",
                  "01JB0000000000000000000002",
                  "R2"
                ]
              ]
            }
          }
        ]
      }
    },
    {
      "version": "083",
      "case": "triggers",
      "ms": 293.0814839999998,
      "result": {
        "localBefore": [
          {
            "id": 1,
            "msg": "inserted 1"
          }
        ],
        "push": {
          "ok": true,
          "value": null
        },
        "homeAfter": {
          "columns": [
            "id",
            "msg"
          ],
          "rows": [
            [
              "1",
              "inserted 1"
            ],
            [
              "2",
              "inserted 1"
            ]
          ]
        },
        "pulls": [
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          },
          {
            "ok": true,
            "value": true
          }
        ],
        "localAfter": [
          [
            {
              "id": 1,
              "msg": "inserted 1"
            },
            {
              "id": 2,
              "msg": "inserted 1"
            }
          ],
          [
            {
              "id": 1,
              "msg": "inserted 1"
            },
            {
              "id": 2,
              "msg": "inserted 1"
            }
          ],
          [
            {
              "id": 1,
              "msg": "inserted 1"
            },
            {
              "id": 2,
              "msg": "inserted 1"
            }
          ]
        ],
        "mutations": [
          {
            "region": 1,
            "changeTime": 1793274192,
            "tableName": "audit",
            "id": 1,
            "changeType": "insert",
            "after": {
              "id": 1,
              "msg": "inserted 1"
            }
          },
          {
            "region": 1,
            "changeTime": 1793274192,
            "tableName": "t",
            "id": 1,
            "changeType": "insert",
            "after": {
              "x": "a",
              "id": 1
            }
          }
        ]
      }
    },
    {
      "version": "083",
      "case": "transform",
      "ms": 333.3972090000002,
      "result": {
        "seen": [
          {
            "changeTime": 1793274192,
            "tableName": "t",
            "id": 1,
            "changeType": "update",
            "before": {
              "v": 0,
              "id": "x"
            },
            "after": {
              "id": "x",
              "v": 3
            },
            "updates": {
              "v": 3
            }
          }
        ],
        "home": {
          "columns": [
            "id",
            "v"
          ],
          "rows": [
            [
              "x",
              "5"
            ]
          ]
        },
        "R3": [
          {
            "id": "x",
            "v": 5
          }
        ]
      }
    },
    {
      "version": "083",
      "case": "partition",
      "ms": 60734.639966,
      "result": {
        "rejectedOfflinePush": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: fetch error: Error: simulated R3 partition"
        },
        "offlineMs": 60101.154421,
        "writesEach": 601,
        "localOffline": [
          {
            "n": 601
          }
        ],
        "convergenceMs": 502.3398610000004,
        "counts": [
          1803,
          1803,
          1803
        ],
        "homeCount": 1803,
        "hashes": [
          "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba",
          "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba",
          "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba"
        ],
        "homeHash": "d09a476489992efc944ce5853148a30625b5c0410ac02f6155dbd6531daa5cba",
        "equal": true
      }
    },
    {
      "version": "083",
      "case": "pullConflict",
      "ms": 354.31099299999994,
      "result": {
        "firstPull": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to replay local change after remote apply: database error: UNIQUE constraint failed: t.email"
        },
        "localAfterError": {
          "ok": true,
          "value": [
            {
              "id": "R2",
              "email": "same@local"
            }
          ]
        },
        "policyPull": {
          "ok": true,
          "value": true
        },
        "localAfterPolicy": {
          "ok": true,
          "value": [
            {
              "id": "R1",
              "email": "same@local"
            }
          ]
        },
        "calls": [
          {
            "changeTime": 1793274342,
            "tableName": "t",
            "id": 1,
            "changeType": "insert",
            "after": {
              "id": "R2",
              "email": "same@local"
            },
            "skipped": false
          },
          {
            "changeTime": 1793274342,
            "tableName": "t",
            "id": 1,
            "changeType": "insert",
            "after": {
              "id": "R2",
              "email": "same@local"
            },
            "skipped": true
          }
        ],
        "home": {
          "columns": [
            "id",
            "email"
          ],
          "rows": [
            [
              "R1",
              "same@local"
            ]
          ]
        }
      }
    },
    {
      "version": "083",
      "case": "fkDefault",
      "ms": 276.066565,
      "result": {
        "defaultFk": {
          "columns": [
            "foreign_keys"
          ],
          "rows": [
            [
              "0"
            ]
          ]
        },
        "push": {
          "ok": true,
          "value": null
        },
        "homeParent": {
          "columns": [
            "id"
          ],
          "rows": []
        },
        "homeChild": {
          "columns": [
            "id",
            "pid"
          ],
          "rows": [
            [
              "child",
              "1"
            ]
          ]
        },
        "check": {
          "columns": [],
          "rows": []
        }
      }
    },
    {
      "version": "083",
      "case": "fkReverse",
      "ms": 265.784953,
      "result": {
        "push": {
          "ok": false,
          "error": "Error: sync engine operation failed: database sync engine error: failed to execute sql: Error { message: \"FOREIGN KEY constraint failed\", code: \"BATCH_STEP_ERROR\" }"
        },
        "retry": {
          "ok": true,
          "value": null
        },
        "pull": {
          "ok": true,
          "value": true
        },
        "homeParent": {
          "columns": [
            "id"
          ],
          "rows": [
            [
              "1"
            ]
          ]
        },
        "homeChild": {
          "columns": [
            "id",
            "pid"
          ],
          "rows": [
            [
              "child",
              "1"
            ]
          ]
        },
        "localParent": [
          {
            "id": 1
          }
        ]
      }
    }
  ]
}
```

</details>

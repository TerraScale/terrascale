import { createInterface } from 'node:readline';
import { performance } from 'node:perf_hooks';
const [modulePath, file] = process.argv.slice(2);
const { connect } = await import(modulePath);
const db = await connect(file);
const sql = async (q, args = []) => (await db.prepare(q)).all(...args);
for await (const line of createInterface({ input: process.stdin })) {
  try {
    const request = JSON.parse(line);
    let result;
    if (request.grow) {
      const insert = await db.prepare('INSERT INTO items VALUES(?,?,?)');
      const start = performance.now();
      let maxLate = 0;
      for (let i = 0; i < request.rate * 30; i++) {
        const due = start + i * 1000 / request.rate;
        while (performance.now() < due) await new Promise(r => setTimeout(r, Math.max(1, due - performance.now())));
        maxLate = Math.max(maxLate, performance.now() - due);
        await insert.run(i.toString(32).toUpperCase().padStart(26, '0'), 'x'.repeat(1024), Buffer.alloc(32, 165));
      }
      while (performance.now() < start + 30000) await new Promise(r => setTimeout(r, Math.max(1, start + 30000 - performance.now())));
      result = { elapsed: (performance.now() - start) / 1000, maxLateMs: maxLate };
    } else result = await sql(request.sql, request.args);
    process.stdout.write(JSON.stringify({ ok: true, result }, (_, v) => typeof v === 'bigint' ? Number(v) : v) + '\n');
  } catch (error) {
    process.stdout.write(JSON.stringify({ ok: false, error: String(error) }) + '\n');
  }
}
await db.close();
